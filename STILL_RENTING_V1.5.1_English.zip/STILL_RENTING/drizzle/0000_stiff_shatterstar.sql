CREATE TABLE `rentals` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_key` text NOT NULL,
	`create_request_id` text NOT NULL,
	`creation_digest` text NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL,
	`record_json` text NOT NULL,
	`receipt_id` text,
	`verification_code` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `rentals_owner_create_unique` ON `rentals` (`owner_key`,`create_request_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `rentals_receipt_unique` ON `rentals` (`receipt_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `rentals_verify_unique` ON `rentals` (`verification_code`);--> statement-breakpoint
CREATE INDEX `rentals_owner_created` ON `rentals` (`owner_key`,`created_at`);