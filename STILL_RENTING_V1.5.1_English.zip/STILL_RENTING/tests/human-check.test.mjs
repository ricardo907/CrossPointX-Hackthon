import assert from 'node:assert/strict';
import test from 'node:test';
import { createHumanChallenge, matchesHumanChallenge, publicHumanChallenge } from '../server/human-check.mjs';

const imagePrefix = 'data:image/svg+xml;base64,';

test('human checks use unpredictable identifiers and preserve six-digit strings', () => {
  const challenges = Array.from({ length: 12 }, () => createHumanChallenge());
  for (const challenge of challenges) {
    assert.match(challenge.id, /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i);
    assert.match(challenge.answer, /^\d{6}$/);
    assert.equal(matchesHumanChallenge(challenge, challenge.answer), true);
  }
  assert.equal(new Set(challenges.map(challenge => challenge.id)).size, challenges.length);
});

test('public human check images are stable path shapes and omit the answer from metadata', () => {
  const challenge = { id: '5740704d-00d8-4ce2-a8c3-83401979899a', answer: '405172' };
  const exposed = publicHumanChallenge(challenge);
  assert.deepEqual(Object.keys(exposed).sort(), ['id', 'image']);
  assert.equal(exposed.id, challenge.id);
  assert.ok(exposed.image.startsWith(imagePrefix));
  const svg = atob(exposed.image.slice(imagePrefix.length));
  assert.match(svg, /^<svg[^>]+viewBox="0 0 252 78">[\s\S]*<\/svg>$/);
  assert.equal((svg.match(/<path\b/g) ?? []).length, 9);
  assert.doesNotMatch(svg, /<(?:text|title|desc|metadata|script|foreignObject)\b|405172|NaN|undefined/i);
  assert.deepEqual(publicHumanChallenge({ ...challenge }), exposed);

  const reissued = publicHumanChallenge({ ...challenge, id: '1fcee3e0-6fa6-4c8d-8edc-b716f6d93fb8' });
  assert.notEqual(reissued.image, exposed.image);
  assert.notEqual(publicHumanChallenge({ ...challenge, answer: '305172' }).image, exposed.image);
});

test('human checks reject mistyped codes and require leading zeroes', () => {
  const challenge = { answer: '000057' };
  assert.equal(matchesHumanChallenge(challenge, '000057'), true);
  for (const badCode of [57, null, undefined, '', '57', '000058', ' 000057', '000057\n', '００００５７']) {
    assert.equal(matchesHumanChallenge(challenge, badCode), false);
  }
  assert.equal(matchesHumanChallenge(null, '000057'), false);
});
