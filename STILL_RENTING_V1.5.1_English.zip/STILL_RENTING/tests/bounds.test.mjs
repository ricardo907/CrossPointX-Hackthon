import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { createDatabase } from '../portable/sqlite.mjs';
import { handleApi, ORDINARY_RECORD_LIMIT_BYTES, COMPLETION_RECORD_LIMIT_BYTES } from '../server/service.mjs';

async function setup(t) {
  const db = createDatabase(':memory:');
  t.after(() => db.close());
  const session = randomUUID();
  const h = { db, rental: null };
  h.call = async (path, body, method = 'POST') => {
    const res = await handleApi(new Request(`http://localhost${path}`, {
      method: body ? method : 'GET',
      headers: { 'Content-Type': 'application/json', 'X-Demo-Session': session },
      ...(body ? { body: JSON.stringify(body) } : {}),
    }), { db, owner: 'qa-capacity', now: () => Date.parse('2026-11-21T10:10:00Z') });
    return { status: res.status, data: await res.json() };
  };
  h.accept = result => {
    assert.equal(result.status, 200, JSON.stringify(result.data));
    assert.equal(result.data.ok, true);
    if (result.data.rental) h.rental = result.data.rental;
    return result.data;
  };
  h.body = fields => ({ requestId: randomUUID(), expectedStateVersion: h.rental.stateVersion, ...fields });
  h.command = (type, body, method = 'POST') => h.call(`/api/rentals/${h.rental.id}/${type}`, body, method);
  h.readStored = async () => {
    const row = await db.prepare('SELECT record_json FROM rentals WHERE id = ?').bind(h.rental.id).first();
    return { bytes: Buffer.byteLength(row.record_json, 'utf8'), record: JSON.parse(row.record_json) };
  };
  h.accept(await h.call('/api/rentals', { requestId: randomUUID(), scenarioId: 'CAMERA_RETURN', seed: 'capacity-qa' }));
  for (const action of ['PLACE_BODY', 'PLACE_CAP', 'PLACE_BATTERY', 'LOCK_DOOR']) {
    h.accept(await h.command('device-events', h.body({ eventId: randomUUID(), action })));
  }
  h.help = async () => h.accept(await h.command('help', h.body({ reasonCode: 'SHOOT_COMPLETE', adopt: true })));
  h.preview = async () => h.accept(await h.command('close-preview', h.body({})));
  h.closeBody = () => h.body({ operationId: randomUUID(), snapshotId: h.rental.closeSnapshot.id, snapshotHash: h.rental.closeSnapshot.hash, confirmClose: true });
  return h;
}

function limitError(result) {
  assert.equal(result.status, 409, JSON.stringify(result.data));
  assert.equal(result.data.error.code, 'DEMO_HISTORY_LIMIT');
}

test('33: 24 chat turns are preserved; the 25th is bounded without blocking completion', async t => {
  const h = await setup(t);
  let lastBody, lastResult;
  for (let i = 0; i < 24; i++) {
    lastBody = h.body({ action: 'MESSAGE', message: `The equipment is back. Why am I still waiting? Request ${i + 1}.` });
    lastResult = await h.command('support', lastBody);
    h.accept(lastResult);
  }
  const before = await h.readStored();
  assert.equal(before.record.support.turnSeq, 24);
  assert.equal(before.record.support.messages.filter(m => m.role === 'user').length, 24);
  assert.ok(h.rental.support.messages.length <= 12);
  limitError(await h.command('support', h.body({ action: 'MESSAGE', message: 'The twenty-fifth request should not extend the conversation limit.' })));
  const after = await h.readStored();
  assert.equal(after.bytes, before.bytes);
  assert.equal(after.record.support.turnSeq, 24);
  const replay = await h.command('support', { ...lastBody, expectedStateVersion: 1 });
  assert.equal(replay.status, 200);
  assert.deepEqual(replay.data, lastResult.data);
  await h.help(); await h.preview();
  const closed = h.accept(await h.command('close', h.closeBody()));
  assert.equal(closed.rental.state, 'CLOSED');
  assert.equal(closed.receipt.finalMinor, 600);
  assert.ok((await h.readStored()).bytes < COMPLETION_RECORD_LIMIT_BYTES);
});

test('34: real repeated writes hit a soft cap but retain reserved help, preview, and close capacity', async t => {
  const h = await setup(t);
  let capped = false, accepted = 0, lastBody, lastResponse;
  // Fresh command IDs intentionally reproduce normal retry-history growth.
  // No database rows are manually enlarged or changed by this test.
  for (let i = 0; i < 500; i++) {
    const body = h.body({ fields: { enteredAssetId: 'CAM-042' } });
    const result = await h.command('proof', body, 'PATCH');
    if (result.status === 409 && result.data.error.code === 'DEMO_HISTORY_LIMIT') {
      capped = true; break;
    }
    h.accept(result); accepted++; lastBody = body; lastResponse = result;
  }
  assert.equal(capped, true, `soft capacity should be reached by real writes, accepted=${accepted}`);
  assert.ok(accepted > 1);
  const atCap = await h.readStored();
  assert.ok(atCap.bytes <= ORDINARY_RECORD_LIMIT_BYTES);
  const replay = await h.command('proof', { ...lastBody, expectedStateVersion: 1 }, 'PATCH');
  assert.equal(replay.status, 200);
  assert.deepEqual(replay.data, lastResponse.data);

  await h.help();
  const helped = await h.readStored();
  assert.ok(helped.bytes > ORDINARY_RECORD_LIMIT_BYTES, `completion reserve should actually be exercised: ${helped.bytes}`);
  assert.ok(helped.bytes < COMPLETION_RECORD_LIMIT_BYTES);
  limitError(await h.command('help', h.body({ reasonCode: 'SHOOT_COMPLETE', adopt: true })));
  assert.equal((await h.readStored()).bytes, helped.bytes);

  await h.preview();
  const previewed = await h.readStored();
  limitError(await h.command('close-preview', h.body({})));
  assert.equal((await h.readStored()).bytes, previewed.bytes);

  const closeBody = h.closeBody();
  const closed = h.accept(await h.command('close', closeBody));
  assert.equal(closed.rental.state, 'CLOSED');
  const final = await h.readStored();
  assert.ok(final.bytes < COMPLETION_RECORD_LIMIT_BYTES);
  assert.equal(Object.keys(final.record.operations).length, 1);
  assert.equal(final.record.receipt.id, closed.receipt.id);

  // New operations cannot consume reserved space once closure is final.
  limitError(await h.command('close', { ...closeBody, requestId: randomUUID(), operationId: randomUUID(), expectedStateVersion: h.rental.stateVersion }));
  assert.equal((await h.readStored()).bytes, final.bytes);
  const originalRetry = await h.command('close', { ...closeBody, requestId: randomUUID(), expectedStateVersion: 1 });
  assert.equal(originalRetry.status, 200);
  assert.equal(originalRetry.data.receipt.id, closed.receipt.id);
  assert.equal((await h.readStored()).bytes, final.bytes);
  t.diagnostic(`Reached ordinary cap after ${accepted} repeated writes; before help=${atCap.bytes} bytes, closed=${final.bytes} bytes.`);
});
