import assert from 'node:assert/strict';
import test from 'node:test';
import { configuredReasonReviewMode, createReasonReviewer, reviewLocalReason } from '../server/reason-review.mjs';

const example = {
  reason: 'The shoot is complete. I returned the camera to locker B-07 and locked the door.',
  reasonCode: 'SHOOT_COMPLETE',
  assetId: 'demo-asset',
  slotId: 'B-07',
  manifestCount: 3,
};

test('local review requires both the selected reason and a return detail', async () => {
  assert.equal(reviewLocalReason(example).sufficient, true);
  assert.equal(reviewLocalReason({ ...example, reason: 'The shoot is complete.' }).sufficient, false);
  assert.equal(reviewLocalReason({ ...example, reasonCode: 'PLAN_CANCELLED' }).sufficient, false);
  assert.equal(configuredReasonReviewMode(), 'LOCAL');
  const review = createReasonReviewer({}, () => assert.fail('An unconfigured review must stay local'));
  assert.deepEqual(await review(example), reviewLocalReason(example));
});

test('online reviewer accepts a valid structured verdict and sends only reason data', async () => {
  const config = { OPENAI_API_KEY: 'mock-only-key' };
  assert.equal(configuredReasonReviewMode(config), 'OPENAI');
  const review = createReasonReviewer(config, async (url, request) => {
    assert.equal(url, 'https://api.openai.com/v1/responses');
    assert.equal(request.method, 'POST');
    assert.equal(request.headers.Authorization, 'Bearer mock-only-key');
    assert.equal(request.redirect, 'error');
    assert.ok(request.signal instanceof AbortSignal);
    const payload = JSON.parse(request.body);
    assert.equal(payload.model, 'gpt-4.1-mini');
    assert.equal(payload.store, false);
    assert.equal(payload.text.format.type, 'json_schema');
    assert.equal(payload.text.format.strict, true);
    assert.deepEqual(JSON.parse(payload.input), {
      selectedReason: example.reasonCode,
      statement: example.reason,
    });
    return Response.json({
      status: 'completed',
      output: [{ type: 'message', role: 'assistant', content: [{
        type: 'output_text',
        text: JSON.stringify({ sufficient: false, feedback: 'Describe how you returned the camera and secured the locker.' }),
      }] }],
    });
  });
  assert.deepEqual(await review(example), {
    sufficient: false,
    feedback: 'Describe how you returned the camera and secured the locker.',
    source: 'OPENAI',
  });
});

test('provider failures and refusals use the actual local result', async () => {
  const config = { OPENAI_API_KEY: 'mock-only-key', STILL_RENTING_AI_MODEL: 'custom-model' };
  let requestedModel;
  const refusal = createReasonReviewer(config, async (_url, request) => {
    requestedModel = JSON.parse(request.body).model;
    return Response.json({
      status: 'completed',
      output: [{ type: 'message', role: 'assistant', content: [{ type: 'refusal' }] }],
    });
  });
  const failed = createReasonReviewer(config, async () => new Response(null, { status: 503 }));
  const timedOut = createReasonReviewer(config, async () => { throw new DOMException('Timeout', 'TimeoutError'); });
  for (const review of [refusal, failed, timedOut]) {
    assert.deepEqual(await review(example), reviewLocalReason(example));
  }
  assert.equal(requestedModel, 'custom-model');
});
