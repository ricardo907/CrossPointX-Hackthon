#!/usr/bin/env node
/** Run only against a fresh extracted delivery directory, never an existing user database. */
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { DatabaseSync } from 'node:sqlite';
import { access, lstat, realpath } from 'node:fs/promises';
import path from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';

const report = { ok: false, checks: [] };
let child, childOutput = '', origin, rental, port;
const session = crypto.randomUUID();
function passed(name) { report.checks.push({ name, passed: true }); }
async function stop() {
  if (!child || child.exitCode !== null || child.signalCode !== null) { child = null; return; }
  const current = child;
  const exited = new Promise(resolve => current.once('exit', resolve));
  current.kill('SIGTERM');
  const timer = setTimeout(() => current.kill('SIGKILL'), 5000);
  await exited; clearTimeout(timer); child = null;
}
process.once('SIGINT', async () => { await stop(); process.exit(130); });
process.once('SIGTERM', async () => { await stop(); process.exit(143); });
async function start(directory) {
  childOutput = '';
  child = spawn(process.execPath, [path.join(directory, 'portable', 'server.mjs')], {
    cwd: directory, env: { ...process.env, STILL_RENTING_PORT: String(port), OPENAI_API_KEY: "" }, stdio: ['ignore', 'pipe', 'pipe'],
  });
  child.stdout.on('data', data => { childOutput = (childOutput + data).slice(-4000); });
  child.stderr.on('data', data => { childOutput = (childOutput + data).slice(-4000); });
  let startupError; child.once('error', error => { startupError = error; });
  for (let attempt = 0; attempt < 80; attempt++) {
    if (startupError) throw startupError;
    if (child.exitCode !== null) throw new Error(`Portable server exited during start: ${childOutput}`);
    try {
      const response = await fetch(`${origin}/api/health`, { signal: AbortSignal.timeout(600) });
      const health = await response.json();
      if (response.status === 200 && health.ok && health.service === 'still-renting') return;
    } catch { /* Wait briefly for the loopback listener. */ }
    await delay(100);
  }
  throw new Error(`Portable server did not become healthy: ${childOutput}`);
}
async function api(route, body, method = 'POST', sessionId = session) {
  const response = await fetch(origin + route, {
    method: body ? method : 'GET', signal: AbortSignal.timeout(6000),
    headers: { 'X-Demo-Session': sessionId, ...(body ? { 'Content-Type': 'application/json' } : {}) },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  return { response, data: await response.json() };
}
function accept(result) {
  assert.equal(result.response.status, 200, JSON.stringify(result.data));
  assert.equal(result.data.ok, true);
  if (result.data.rental) rental = result.data.rental;
  return result.data;
}
async function command(type, fields = {}, method = 'POST') {
  return accept(await api(`/api/rentals/${rental.id}/${type}`, { requestId: crypto.randomUUID(), expectedStateVersion: rental.stateVersion, ...fields }, method));
}

try {
  assert.ok(Number(process.versions.node.split('.')[0]) >= 24, 'Node.js 24 or newer is required.');
  assert.ok(process.argv[2], 'Usage: node tests/runtime-smoke.mjs /absolute/path/to/fresh/STILL_RENTING');
  const directory = await realpath(path.resolve(process.argv[2]));
  report.deliveryPath = directory;
  await access(path.join(directory, 'portable', 'server.mjs'));
  await access(path.join(directory, 'portable', 'public', 'index.html'));
  const dataDir = path.join(directory, 'data');
  const existingData = await lstat(dataDir).catch(error => { if (error.code === 'ENOENT') return null; throw error; });
  assert.equal(existingData, null, 'Refusing to use an existing data directory. Extract a fresh delivery ZIP first.');
  const probe = createServer();
  await new Promise((resolve, reject) => { probe.once('error', reject); probe.listen(0, '127.0.0.1', resolve); });
  port = probe.address().port;
  await new Promise(resolve => probe.close(resolve));
  origin = `http://127.0.0.1:${port}`; report.origin = origin;
  await start(directory); passed('portable server starts with Node only; health endpoint returns ready');

  const index = await fetch(origin, { signal: AbortSignal.timeout(6000) });
  assert.equal(index.status, 200); assert.match(index.headers.get('content-type'), /text\/html/i);
  const html = await index.text();
  const assets = [...new Set([...html.matchAll(/(?:src|href)=["']([^"']+\.(?:js|css)(?:\?[^"']*)?)["']/g)].map(match => match[1]))];
  assert.ok(assets.some(asset => /\.js(?:\?|$)/.test(asset)), 'Index must reference built JavaScript.');
  assert.ok(assets.some(asset => /\.css(?:\?|$)/.test(asset)), 'Index must reference built CSS.');
  for (const asset of assets) {
    const url = new URL(asset, origin); assert.equal(url.origin, origin, 'Portable assets must be local.');
    const response = await fetch(url, { signal: AbortSignal.timeout(6000) });
    assert.equal(response.status, 200, asset);
    assert.match(response.headers.get('content-type') || '', /\.css(?:\?|$)/.test(asset) ? /text\/css/i : /(?:java|ecma)script/i);
    assert.ok((await response.arrayBuffer()).byteLength > 0, asset);
  }
  report.assets = assets; passed('static index, built JavaScript and CSS load with correct MIME types');
  const missing = await fetch(`${origin}/assets/definitely-missing-smoke-file.js`); assert.equal(missing.status, 404); await missing.text(); passed('unknown static asset returns 404');

  accept(await api('/api/rentals', { requestId: crypto.randomUUID(), scenarioId: 'CAMERA_RETURN', seed: 'packaged-runtime-smoke' }));
  for (const action of ['PLACE_BODY', 'PLACE_CAP', 'PLACE_BATTERY', 'LOCK_DOOR']) await command('device-events', { eventId: crypto.randomUUID(), action });
  assert.equal(rental.state, 'RETURN_PENDING'); passed('HTTP create and all four simulated device actions persist physical return');
  await command('proof', {
    fields: {
      enteredAssetId: rental.assetId, enteredSlotId: rental.slotId, enteredReturnState: 'RETURNED',
      enteredReturnedAt: new Date(rental.returnedAt).toISOString(), enteredManifestCount: '3',
    },
  }, 'PATCH');
  assert.equal(rental.selfProofComplete, true);
  const physicalChecks = ['CAP_CONFIRM', 'BATTERY_CONFIRM', 'BODY_CONFIRM', 'DOOR_CONFIRM'];
  for (const checkId of physicalChecks) {
    await command('checks', { action: 'REVEAL' });
    await command('checks', { action: 'CONFIRM', checkId });
  }
  await command('checks', { action: 'REVEAL' });
  await command('proof', { fields: { reasonCode: 'SHOOT_COMPLETE' } }, 'PATCH');
  assert.deepEqual(rental.checks.filter(c => c.status === 'EXPIRED').map(c => c.id), physicalChecks);
  for (const checkId of physicalChecks) await command('checks', { action: 'CONFIRM', checkId });
  await command('checks', { action: 'CONFIRM', checkId: 'REASON_SPECIFIC' });
  assert.equal(rental.planVersion, '6'); assert.equal(rental.stage, 'FILING');
  assert.equal(rental.budget.allocated, 15);
  passed('all five proof fields, five ordered checks and four reopenings run over HTTP');
  for (const role of ['BILLING', 'REVIEW', 'BILLING', 'REVIEW']) {
    await command('support', { action: 'TRANSFER' });
    assert.equal(rental.support.role, role);
  }
  assert.equal(rental.budget.limit, 31); assert.equal(rental.budget.allocated, 19);
  assert.ok(rental.support.allowedActions.includes('OPEN_MERGED_REVIEW'));
  passed('four support handoffs still offer merged review');

  const rentalPath = `/api/rentals/${rental.id}`;
  const docsPath = `${rentalPath}/filing-documents`;
  const initialDocuments = accept(await api(docsPath)).filingDocuments;
  assert.ok(initialDocuments.receiptCode); assert.equal('certificateCode' in initialDocuments, false);
  const premature = await api(`${rentalPath}/close-preview`, { requestId: crypto.randomUUID(), expectedStateVersion: rental.stateVersion });
  assert.equal(premature.response.status, 409); assert.equal(premature.data.error.code, 'FILING_INCOMPLETE');
  const firstFiling = { requestId: crypto.randomUUID(), expectedStateVersion: rental.stateVersion, receiptCode: initialDocuments.receiptCode };
  const returnedApplication = accept(await api(`${rentalPath}/filing`, firstFiling));
  assert.equal(rental.filing.status, 'NEEDS_CERTIFICATE');
  assert.equal(rental.budget.allocated, 20);
  passed('carrying the device slip creates the single deliberate application return');

  await stop(); await start(directory);
  accept(await api(rentalPath));
  assert.equal(rental.filing.status, 'NEEDS_CERTIFICATE');
  assert.deepEqual((await api(`${rentalPath}/filing`, firstFiling)).data, returnedApplication);
  const completeDocuments = accept(await api(docsPath)).filingDocuments;
  assert.equal(completeDocuments.receiptCode, initialDocuments.receiptCode);
  assert.ok(completeDocuments.certificateCode);
  await command('filing', { receiptCode: completeDocuments.receiptCode, certificateCode: completeDocuments.certificateCode });
  assert.equal(rental.filing.status, 'RECALL_REQUIRED');
  assert.equal(rental.budget.allocated, 21);
  passed('returned application survives restart and accepts the archived completion certificate before reopening');

  const reviewSteps = [
    ['RECALL', 'certificateCode', 'REISSUE_REQUIRED'],
    ['REISSUE', 'withdrawalCode', 'REGISTRY_REQUIRED'],
    ['REGISTER', 'registryCode', 'ACK_REQUIRED'],
    ['ACKNOWLEDGE', 'acknowledgmentCode', 'APPROVED'],
  ];
  const reviewCodes = new Set([completeDocuments.receiptCode]);
  for (const [action, field, nextStatus] of reviewSteps) {
    const documents = accept(await api(docsPath)).filingDocuments;
    const code = documents[field];
    assert.ok(code, field); assert.ok(!reviewCodes.has(code), field);
    reviewCodes.add(code);
    const early = await api(`${rentalPath}/close-preview`, { requestId: crypto.randomUUID(), expectedStateVersion: rental.stateVersion });
    assert.equal(early.response.status, 409); assert.equal(early.data.error.code, 'FILING_INCOMPLETE');
    await command('filing-review', { action, code });
    assert.equal(rental.filing.status, nextStatus);
    if (action === 'REISSUE') {
      const priorCode = accept(await api(docsPath)).filingDocuments.registryCode;
      await stop(); await start(directory);
      accept(await api(rentalPath));
      assert.equal(rental.filing.status, 'REGISTRY_REQUIRED');
      assert.equal(accept(await api(docsPath)).filingDocuments.registryCode, priorCode);
    }
  }
  assert.equal(rental.budget.allocated, 25);
  passed('all four reopened-application steps issue distinct documents and resume after restart');
  const finalizationSteps = [
    ['FINISH_SYNC', {}, 'REASON_REQUIRED'],
    ['REVIEW_REASON', { reason: 'The shoot is complete. I returned the camera to locker B-07 and locked the door.' }, 'REASON_PROGRESS'],
    ['FINISH_REVIEW', {}, 'CERTIFY_REQUIRED'],
    ['CERTIFY', { code: '3/B-07' }, 'FINAL_PROGRESS'],
    ['FINISH_FINAL', {}, 'HUMAN_REQUIRED'],
    ['VERIFY_HUMAN', {}, 'RELEASE_REQUIRED'],
    ['RELEASE', {}, 'APPROVED'],
  ];
  assert.equal(rental.stage, 'FINALIZATION');
  assert.equal(rental.finalization.status, 'SYNC_PROGRESS');
  for (const [action, fields, status] of finalizationSteps) {
    const early = await api(`${rentalPath}/close-preview`, { requestId: crypto.randomUUID(), expectedStateVersion: rental.stateVersion });
    assert.equal(early.response.status, 409);
    if (action === 'VERIFY_HUMAN') {
      const image = accept(await api(`${rentalPath}/human-challenge`)).humanChallenge;
      assert.match(image.image, /^data:image\/svg\+xml;base64,/);
      const fixtureDatabase = new DatabaseSync(path.join(directory, 'data', 'still-renting.sqlite'), { readOnly: true });
      try {
        const fixtureRow = fixtureDatabase.prepare('SELECT record_json FROM rentals WHERE id = ?').get(rental.id);
        const fixtureChallenge = JSON.parse(fixtureRow.record_json).finalization.human.challenge;
        assert.equal(image.id, fixtureChallenge.id);
        fields.challengeId = fixtureChallenge.id;
        fields.code = fixtureChallenge.answer;
      } finally { fixtureDatabase.close(); }
    }
    await command('finalization', { action, ...fields });
    assert.equal(rental.finalization.status, status);
    assert.equal(rental.state, 'RETURN_PENDING');
    if (action === 'FINISH_REVIEW') {
      await stop(); await start(directory);
      accept(await api(rentalPath));
      assert.equal(rental.finalization.status, 'CERTIFY_REQUIRED');
    }
  }
  assert.equal(rental.budget.allocated, 31);
  passed('reason review, timed stages and a server-generated human challenge precede real settlement');
  await command('close-preview');
  const closed = await command('close', { operationId: crypto.randomUUID(), snapshotId: rental.closeSnapshot.id, snapshotHash: rental.closeSnapshot.hash, confirmClose: true });
  const receipt = closed.receipt;
  assert.equal(rental.state, 'CLOSED'); assert.equal(receipt.finalMinor, receipt.baseMinor); assert.equal(receipt.stats.extraTasks, 31);
  passed('final review and explicit close after the longest path produce a settled receipt');
  const downloaded = await api(`/api/receipts/${receipt.id}?format=json`);
  assert.match(downloaded.response.headers.get('content-disposition') || '', /attachment/i);
  assert.deepEqual(accept(downloaded).receipt, receipt); passed('JSON receipt download matches the committed result');
  const verification = accept(await api(`/api/verify/${receipt.verificationCode}`)).verification;
  assert.equal(verification.valid, true); assert.equal(verification.receiptId, receipt.id); assert.equal(verification.finalMinor, receipt.finalMinor); passed('receipt verification resolves the same immutable result');
  const other = await api(`/api/receipts/${receipt.id}`, undefined, 'GET', crypto.randomUUID());
  assert.ok([403, 404].includes(other.response.status)); passed('a different demo session cannot read the receipt');

  await stop(); await start(directory);
  const restored = accept(await api(`/api/receipts/${receipt.id}`)).receipt;
  assert.deepEqual(restored, receipt);
  const restoredRental = accept(await api(`/api/rentals/${receipt.rentalId}`)).rental;
  assert.equal(restoredRental.state, 'CLOSED'); assert.equal(restoredRental.receiptId, receipt.id); passed('process restart preserves the same receipt and CLOSED rental in SQLite');
  report.receiptId = receipt.id; report.verificationCode = receipt.verificationCode;
  report.database = path.join(directory, 'data', 'still-renting.sqlite'); report.ok = true;
} catch (error) {
  report.error = error?.message || String(error); if (childOutput) report.serverOutput = childOutput;
  process.exitCode = 1;
} finally {
  await stop();
  console.log(JSON.stringify(report, null, 2));
}
