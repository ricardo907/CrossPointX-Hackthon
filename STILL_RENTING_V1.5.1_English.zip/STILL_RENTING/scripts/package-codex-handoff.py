#!/usr/bin/env python3
"""Export a complete project handoff, including local build assets, without runtime state.

Run the relevant tests/builds first. Python 3 standard library only; never deletes
runtime data and never writes to an online deployment.
"""
import argparse
from pathlib import Path
import hashlib
import json
import zipfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent.parent
EXCLUDE_DIRS = {'.git', 'node_modules', 'data', '.wrangler', '.sites-runtime', '.vinext', '.next', '.codex', '.agents', '.pnp', '.yarn', 'dist', 'out', 'outputs', 'exports', 'work', 'coverage', '__pycache__', '.pytest_cache'}
EXCLUDE_SUFFIXES = {'.zip', '.tar', '.gz', '.sqlite', '.sqlite-wal', '.sqlite-shm', '.db', '.db-wal', '.db-shm', '.pem', '.p12', '.pfx', '.key', '.pyc', '.tsbuildinfo', '.log'}
EXCLUDE_NAMES = {'HANDOFF_MANIFEST.json', 'HANDOFF_PACKAGE.sha256', '.DS_Store', 'Thumbs.db', 'next-env.d.ts'}

HISTORICAL_EXPORTS = set(['STILL_RENTING_PRD_revision_v1.1.docx', 'STILL_RENTING_PRD_text.txt', 'STILL_RENTING_PRD_v1.0.docx', 'STILL_RENTING_PRD_v1.0.pdf', 'handoff-build-check.json', 'handoff-runtime-smoke.json', 'handoff-tests.tap', 'runtime-smoke.json', 'test-results.tap'])

def eligible(p):
    relative = p.relative_to(ROOT)
    if p.is_symlink() or any(part in EXCLUDE_DIRS for part in relative.parts):
        return False
    if relative.parts[0] == 'docs' and p.name in HISTORICAL_EXPORTS:
        return False
    if p.name in EXCLUDE_NAMES or p.suffix.lower() in EXCLUDE_SUFFIXES:
        return False
    if p.name.startswith(('.env', '.dev.vars')) and not p.name.endswith('.example'):
        return False
    if relative.parts[:2] == ('public', 'downloads'):
        return False
    return p.is_file()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, help='Destination ZIP path')
    args = parser.parse_args()
    output = Path(args.output).expanduser().resolve()
    if output.suffix.lower() != '.zip':
        raise SystemExit('Output must end in .zip')
    required = ['AGENTS.md', 'CODEX_HANDOFF.md', 'CODEX_FIRST_MESSAGE.md', 'START_HERE.md', 'package.json', 'package-lock.json', 'server/service.mjs', 'portable/server.mjs', 'portable/public/index.html', 'scripts/verify-handoff.mjs']
    for name in required:
        if not (ROOT / name).is_file():
            raise SystemExit('Required file missing: ' + name)
    files = sorted(p for p in ROOT.rglob('*') if eligible(p) and p.resolve() != output)
    manifest = {
        'format': 'still-renting-codex-handoff/1',
        'handoffVersion': '1.5.1',
        'generatedAt': datetime.now(timezone.utc).isoformat(),
        'applicationVersion': json.loads((ROOT / 'package.json').read_text())['version'],
        'sourceBaselineCommit': 'f612ce6f46dd7068bad130af390d934183ba9e77',
        'baselineNote': 'Original application baseline; later changes must be recorded in docs/OPTIMIZATION_LOG.md. This manifest is file integrity evidence, not a test result.',
        'files': [{'path': p.relative_to(ROOT).as_posix(), 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
    }
    manifest_file = ROOT / 'HANDOFF_MANIFEST.json'
    manifest_file.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for p in files + [manifest_file]:
            archive.write(p, 'STILL_RENTING/' + p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(output) as archive:
        invalid = archive.testzip()
        if invalid:
            raise SystemExit('Archive CRC failure: ' + invalid)
    checksum = hashlib.sha256(output.read_bytes()).hexdigest()
    output.with_suffix('.zip.sha256').write_text(checksum + '  ' + output.name + '\n', encoding='ascii')
    print(json.dumps({'archive': str(output), 'files': len(files) + 1, 'bytes': output.stat().st_size, 'sha256': checksum}, ensure_ascii=False))

if __name__ == '__main__':
    main()
