#!/usr/bin/env node
/** Verify the unmodified export. This does not replace application tests. */
import { readFileSync, lstatSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.resolve(fileURLToPath(new URL('..', import.meta.url)));
const manifest = JSON.parse(readFileSync(path.join(root, 'HANDOFF_MANIFEST.json'), 'utf8'));
const problems = [];
let checked = 0;
for (const item of manifest.files) {
  const target = path.resolve(root, item.path);
  if (!target.startsWith(root + path.sep) || item.path.includes('\\') || item.path.startsWith('/')) {
    problems.push({ path: item.path, issue: 'unsafe path' }); continue;
  }
  try {
    if (!lstatSync(target).isFile()) throw new Error('not a regular file');
    const bytes = readFileSync(target);
    const digest = createHash('sha256').update(bytes).digest('hex');
    if (bytes.length !== item.bytes || digest !== item.sha256) problems.push({ path: item.path, issue: 'content differs from export' });
    checked++;
  } catch (error) { problems.push({ path: item.path, issue: error.code === 'ENOENT' ? 'missing' : 'unreadable or not regular' }); }
}
console.log(JSON.stringify({ ok: problems.length === 0, handoffVersion: manifest.handoffVersion, checkedFiles: checked, totalExpected: manifest.files.length, problems }, null, 2));
if (problems.length) process.exitCode = 1;
