import { sqliteTable, text, integer, uniqueIndex, index } from "drizzle-orm/sqlite-core";

// A rental is the transaction boundary. The JSON aggregate and unique receipt
// indexes are changed by one conditional UPDATE, including retry results.
export const rentals = sqliteTable("rentals", {
  id: text("id").primaryKey().notNull(),
  ownerKey: text("owner_key").notNull(),
  createRequestId: text("create_request_id").notNull(),
  creationDigest: text("creation_digest").notNull(),
  revision: integer("revision").notNull().default(0),
  recordJson: text("record_json").notNull(),
  receiptId: text("receipt_id"),
  verificationCode: text("verification_code"),
  createdAt: integer("created_at").notNull(),
  updatedAt: integer("updated_at").notNull(),
}, (table) => [
  uniqueIndex("rentals_owner_create_unique").on(table.ownerKey, table.createRequestId),
  uniqueIndex("rentals_receipt_unique").on(table.receiptId),
  uniqueIndex("rentals_verify_unique").on(table.verificationCode),
  index("rentals_owner_created").on(table.ownerKey, table.createdAt),
]);
