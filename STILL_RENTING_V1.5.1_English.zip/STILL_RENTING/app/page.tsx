"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import { Aperture, ArrowUpRight, Battery, Box, Check, CheckCircle2, ChevronDown, ChevronRight, CircleHelp, ClipboardCheck, Clock3, Copy, Download, Eye, FileCheck2, FileText, Headphones, History, Info, Layers3, LockKeyhole, Menu, MessageSquare, PackageCheck, Plus, Printer, RefreshCw, ScanLine, Send, ShieldCheck, SlidersHorizontal, Sparkles, Unplug, X } from "lucide-react";

type CheckItem = { id: string; label: string; status: string; visible: boolean; taskId?: string; reworkTaskId?: string; confirmation?: unknown };
type ChatMessage = { id: string; role: string; speaker: string; text: string; source: string; at: number };
type ProofInputs = {
  enteredAssetId: string;
  enteredSlotId: string;
  enteredReturnState: string;
  enteredReturnedAt: string;
  enteredManifestCount: string;
};
type FilingReviewStatus = "RECALL_REQUIRED" | "REISSUE_REQUIRED" | "REGISTRY_REQUIRED" | "ACK_REQUIRED";
type FilingStatus = "NOT_STARTED" | "NEEDS_CERTIFICATE" | FilingReviewStatus | "APPROVED" | "WAIVED";
type FilingCodes = { receiptCode: string; certificateCode?: string; withdrawalCode?: string; registryCode?: string; acknowledgmentCode?: string };
type FilingErrorField = "receiptCode" | "certificateCode" | "code";
type FilingReviewStep = {
  status: FilingReviewStatus;
  action: "RECALL" | "REISSUE" | "REGISTER" | "ACKNOWLEDGE";
  task: string;
  name: string;
  title: string;
  instruction: string;
  submit: string;
  archiveHash: string;
  archiveTitle: string;
  documentTitle: string;
  field: keyof FilingCodes;
  codeLabel: string;
};
type FinalizationProgressStatus = "SYNC_PROGRESS" | "REASON_PROGRESS" | "FINAL_PROGRESS";
type FinalizationStatus = "NOT_STARTED" | FinalizationProgressStatus | "REASON_REQUIRED" | "CERTIFY_REQUIRED" | "HUMAN_REQUIRED" | "RELEASE_REQUIRED" | "APPROVED" | "WAIVED";
type FinalizationAction = "FINISH_SYNC" | "REVIEW_REASON" | "FINISH_REVIEW" | "CERTIFY" | "FINISH_FINAL" | "VERIFY_HUMAN" | "REFRESH_HUMAN" | "EXPIRE" | "RELEASE";
type ReasonReviewSource = "OPENAI" | "LOCAL";
type HumanChallenge = { id: string; image: string };
type FinalizationRecord = {
  status: FinalizationStatus;
  enteredAt: number | null;
  deadlineAt?: number | null;
  human?: { id: string; attempts: number };
  review?: { attempts: number; decision: "SUFFICIENT" | "INSUFFICIENT" | "MANUAL_ACCEPTED"; feedback: string; source: ReasonReviewSource };
};
type FinalizationFieldError = { field: "reason" | "code"; message: string };
type Receipt = { id: string; rentalId: string; verificationCode: string; assetId: string; slotId: string; startedAt: number; returnedAt: number; closedAt: number; currency: string; baseMinor: number; waitMinor: number; reversalMinor: number; finalMinor: number; reasonCode: string; snapshotHash: string; stats: { extraTasks: number; handOffs: number; reworkCount: number; helpUsed: boolean; elapsedAfterReturnSeconds: number }; simulation: boolean };
type Rental = {
  id: string; assetId: string; assetName: string; slotId: string; state: string; stateVersion: number; proofVersion: number; planVersion: string; startedAt: number; returnedAt: number | null; closedAt: number | null; serverNow: number; stage: string;
  physical: { body: boolean; cap: boolean; battery: boolean; doorLocked: boolean; identityMatch: boolean; manifestMatch: boolean };
  proof: Omit<ProofInputs, "enteredReturnedAt" | "enteredManifestCount"> & Partial<Pick<ProofInputs, "enteredReturnedAt" | "enteredManifestCount">> & { reasonCode: string }; selfProofComplete: boolean; invalidAttempts: Record<string, number>; validationErrors?: Record<string, string>;
  checks: CheckItem[]; theatricalReworkUsed: boolean; support: { role: string; handoffs: number; handoffLimit?: number; allowedActions?: string[]; messages: ChatMessage[] }; budget: { limit: number; allocated: number; presented: number; taskIds: string[] };
  filing?: { status: FilingStatus; acceptedReceiptCode?: string };
  finalization?: FinalizationRecord;
  reasonReviewMode?: ReasonReviewSource;
  billing: { currency: string; baseRateMinorPerSecond: number; waitRateMinorPerSecond: number; baseMinor: number; waitMinor: number; projectedMinor: number; finalMinor: number | null; reversalMinor: number };
  closeSnapshot: null | { id: string; hash: string; finalBaseMinor: number; reasonCode: string; returnedAt: number; proofVersion: number; createdAt: number };
  receiptId: string | null; events: { id: string; type: string; at: number; detail: unknown; sequence: number }[]; helpUsed: boolean;
};
type Envelope = { ok: boolean; rental?: Rental; observerKey?: string; receipt?: Receipt; rentals?: any[]; observer?: any; verification?: any; validationErrors?: Record<string, string>; filingDocuments?: FilingCodes; humanChallenge?: HumanChallenge; operation?: { status: string; receipt?: Receipt }; error?: { code: string; message: string; field?: string; retryable?: boolean; currentStateVersion?: number } };
type FilingArchive = { rentalId: string; status: FilingStatus; codes: FilingCodes } | { rentalId: string; status: FilingStatus; error: string };
type PendingClose = { rentalId: string; payload: Record<string, unknown>; createdAt: number };
type Panel = null | "support" | "help" | "observer" | "history" | "about";
const K = { session: "sr.session.v1", rental: "sr.rental.v1", observers: "sr.observers.v1", create: "sr.create.v1", pending: "sr.pending.v1" };
const reasons: Record<string, string> = { GENERAL_END: "Use complete", SHOOT_COMPLETE: "Shoot complete", PLAN_CANCELLED: "Plans cancelled" };
const stages = [{ name: "Return equipment", key: "RETURN_SIMULATION" }, { name: "Prove return", key: "SELF_PROOF" }, { name: "Item review", key: "CHECKS" }, { name: "Confirm closure", key: "FINAL_REVIEW" }];
const filingStages = [...stages.slice(0, -1), { name: "Closure request", key: "FILING" }, stages[stages.length - 1]];
const finalizationStages = [...filingStages.slice(0, -1), { name: "Closure review", key: "FINALIZATION" }, stages[stages.length - 1]];
const finalizationTasks: Partial<Record<FinalizationStatus, string>> = {
  SYNC_PROGRESS: "FINAL_SYNC",
  REASON_REQUIRED: "FINAL_REASON",
  REASON_PROGRESS: "FINAL_REVIEW_PROGRESS",
  CERTIFY_REQUIRED: "FINAL_CERTIFY",
  FINAL_PROGRESS: "FINAL_EXPORT_PROGRESS",
  HUMAN_REQUIRED: "FINAL_HUMAN",
  RELEASE_REQUIRED: "FINAL_RELEASE",
};
const finalizationProgress = {
  SYNC_PROGRESS: { title: "Closing your rental", label: "Closure preparation", detail: "We received the filing confirmation and are syncing the settlement. Almost there.", complete: "Closure preparation complete", button: "View closure preparation result", action: "FINISH_SYNC", duration: 2230 },
  REASON_PROGRESS: { title: "Running the final check", label: "Reason verification", detail: "We accepted your reason and are consolidating all the evidence. Almost there.", complete: "Reason verification complete", button: "View final check result", action: "FINISH_REVIEW", duration: 2380 },
  FINAL_PROGRESS: { title: "Preparing your receipt", label: "Receipt preparation progress", detail: "We confirmed your transcription and are compiling the final record. Almost there.", complete: "Receipt format ready", button: "View receipt preparation result", action: "FINISH_FINAL", duration: 2540 },
} as const;
const filingArchiveHash = "#return-documents";
const filingReviewSteps: FilingReviewStep[] = [
  {
    status: "RECALL_REQUIRED",
    action: "RECALL",
    task: "FILING_RECALL",
    name: "Withdraw original",
    title: "Your original request passed. Please withdraw it.",
    instruction: "The closure desk only accepts new requests. Retrieve the original certificate number from the Sealed Records Desk, then request withdrawal of your approved application.",
    submit: "Withdraw approved request",
    archiveHash: "#sealed-original",
    archiveTitle: "Sealed Records Desk",
    documentTitle: "Sealed Completeness Certificate",
    field: "certificateCode",
    codeLabel: "Original Completeness Certificate number",
  },
  {
    status: "REISSUE_REQUIRED",
    action: "REISSUE",
    task: "FILING_REISSUE",
    name: "Reissue certificate",
    title: "Please prove you withdrew your request.",
    instruction: "We recorded the withdrawal. Retrieve the receipt number from the Withdrawal Register, then enter it here so we can issue a new certificate for the same return.",
    submit: "Reissue certificate",
    archiveHash: "#withdrawal-log",
    archiveTitle: "Withdrawal Register",
    documentTitle: "Withdrawal receipt",
    field: "withdrawalCode",
    codeLabel: "Withdrawal receipt number",
  },
  {
    status: "REGISTRY_REQUIRED",
    action: "REGISTER",
    task: "FILING_REGISTER",
    name: "File closure",
    title: "We issued your new certificate. Please submit it to us.",
    instruction: "The Certificate Desk has updated the record. Retrieve the certificate number and bring it here to file your closure.",
    submit: "Submit closure filing",
    archiveHash: "#credential-issuance",
    archiveTitle: "Certificate Desk",
    documentTitle: "Reissued Return Certificate",
    field: "registryCode",
    codeLabel: "Reissued Return Certificate number",
  },
  {
    status: "ACK_REQUIRED",
    action: "ACKNOWLEDGE",
    task: "FILING_ACK",
    name: "Acknowledge filing",
    title: "We accepted your filing. Please confirm you know we accepted it.",
    instruction: "Retrieve the acceptance number from the Filing Acknowledgment Desk. Confirm in person to unlock the final review.",
    submit: "Acknowledge accepted filing",
    archiveHash: "#filing-acknowledgment",
    archiveTitle: "Filing Acknowledgment Desk",
    documentTitle: "Closure filing acknowledgment",
    field: "acknowledgmentCode",
    codeLabel: "Filing acceptance number",
  },
];
const filingArchiveHashes = new Set([filingArchiveHash, ...filingReviewSteps.map(step => step.archiveHash)]);
const hasExtendedProof = (rental: Rental | null) => rental != null && ["2", "3", "4", "5", "6"].includes(rental.planVersion);
const roleNames: Record<string, string> = { DEVICE: "Equipment Intake Specialist", BILLING: "Billing Specialist", REVIEW: "Review Specialist" };
const emptyProof: ProofInputs = { enteredAssetId: "", enteredSlotId: "", enteredReturnState: "", enteredReturnedAt: "", enteredManifestCount: "" };
const proofDraft = (proof: Rental["proof"]): ProofInputs => ({
  enteredAssetId: proof.enteredAssetId,
  enteredSlotId: proof.enteredSlotId,
  enteredReturnState: proof.enteredReturnState === "RETURNED" ? "Returned" : proof.enteredReturnState,
  enteredReturnedAt: proof.enteredReturnedAt ?? "",
  enteredManifestCount: proof.enteredManifestCount ?? "",
});
const checkPrompts: Record<string, { task: string; title: string; description: string; confirmation: string; icon: React.ReactNode }> = {
  CAP_CONFIRM: {
    task: "CHECK_CAP",
    title: "Are you sure you returned the lens cap?",
    description: "The locker detected the lens cap. Now confirm it yourself.",
    confirmation: "lens cap returned",
    icon: <span className="cap-icon large"/>,
  },
  BATTERY_CONFIRM: {
    task: "CHECK_BATTERY",
    title: "Now confirm the battery.",
    description: "The locker detected the battery. We record its confirmation separately.",
    confirmation: "battery returned",
    icon: <Battery size={34}/>,
  },
  BODY_CONFIRM: {
    task: "CHECK_BODY",
    title: "We also need confirmation of the camera body.",
    description: "The locker identified the camera body. We have the device ID, but the body requires a separate confirmation.",
    confirmation: "camera body returned",
    icon: <Aperture size={34}/>,
  },
  DOOR_CONFIRM: {
    task: "CHECK_DOOR",
    title: "Please confirm the locker door is closed.",
    description: "The locker recorded that the door locked. Please confirm its record.",
    confirmation: "locker door closed",
    icon: <LockKeyhole size={34}/>,
  },
  REASON_SPECIFIC: {
    task: "CHECK_REASON",
    title: "“Use complete” is not specific enough.",
    description: "Tell us how you specifically finished using the equipment.",
    confirmation: "",
    icon: <MessageSquare size={32}/>,
  },
};
const done = (c: CheckItem) => ["CONFIRMED", "WAIVED_BY_USER"].includes(c.status);
const amount = (n: number | undefined | null) => ((n ?? 0) / 100).toFixed(2);
const datetime = (ms: number | null | undefined) => ms ? new Date(ms).toLocaleString("en-GB", { hour12: false }) : "—";
const timeOnly = (ms: number | null | undefined) => ms ? new Date(ms).toLocaleTimeString("en-GB", { hour12: false }) : "—";
const uid = () => crypto.randomUUID();
function safeLoad<T>(key: string, fallback: T): T { try { return JSON.parse(localStorage.getItem(key) ?? "null") ?? fallback; } catch { return fallback; } }
function writeLocal(key: string, value: unknown) { try { if (value === null) localStorage.removeItem(key); else localStorage.setItem(key, JSON.stringify(value)); } catch { /* The visible status below explains unavailable local persistence. */ } }

function CameraIllustration({ compact = false, returned = false }: { compact?: boolean; returned?: boolean }) {
  return <svg viewBox="0 0 460 300" className={`camera-illustration ${compact ? "compact" : ""}`} role="img" aria-label="Illustration of the Aperture S1 camera">
    <defs>
      <linearGradient id="bodyGrad" x1="0" y1="0" x2="0.7" y2="1"><stop offset="0" stopColor="#424b52"/><stop offset="0.48" stopColor="#20272d"/><stop offset="1" stopColor="#151a1f"/></linearGradient>
      <linearGradient id="topGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#647078"/><stop offset="1" stopColor="#303940"/></linearGradient>
      <radialGradient id="lensGrad"><stop offset="0" stopColor="#14212d"/><stop offset="0.4" stopColor="#253d46"/><stop offset="0.65" stopColor="#142128"/><stop offset="0.78" stopColor="#456369"/><stop offset="0.86" stopColor="#152228"/><stop offset="1" stopColor="#080e12"/></radialGradient>
      <filter id="cameraShadow"><feGaussianBlur stdDeviation="8"/></filter>
    </defs>
    <ellipse cx="237" cy="259" rx="153" ry="16" fill="#1d252c" opacity=".13" filter="url(#cameraShadow)"/>
    <g transform="translate(46 22)">
      <path d="M57 67 87 48h76l14-19h77l19 19h43l29 23v141H57z" fill="#121a1f"/>
      <path d="M46 78 73 60h85l18-21h70l23 21h48l24 18-15 20H61z" fill="url(#topGrad)"/>
      <path d="M49 79h282q14 0 14 15v113q0 18-17 18H56q-17 0-17-18V95q0-16 10-16" fill="url(#bodyGrad)" stroke="#526068" strokeWidth="1.4"/>
      <rect x="49" y="88" width="63" height="128" rx="14" fill="#181f25"/>
      <path d="M54 110v85M62 105v94M70 103v100M78 103v100M86 103v100M94 103v100" stroke="#4c565d" opacity=".32" strokeWidth="2"/>
      <rect x="276" y="98" width="45" height="13" rx="2" fill="#0c1216"/>
      <text x="286" y="126" fill="#aab5bc" fontSize="10" fontFamily="monospace" letterSpacing="2">S1</text>
      <text x="127" y="81" fill="#f0f4f4" fontSize="9" fontWeight="600" fontFamily="Arial,sans-serif" letterSpacing="3">APERTURE</text>
      <path d="M181 47h57l12 19h-82z" fill="#283139"/>
      <rect x="195" y="47" width="28" height="10" rx="2" fill="#0d151b"/>
      <ellipse cx="91" cy="65" rx="19" ry="7" fill="#171f25" stroke="#657078" strokeWidth="2"/>
      <ellipse cx="294" cy="65" rx="15" ry="6" fill="#10191f" stroke="#637078" strokeWidth="2"/>
      <circle cx="209" cy="153" r="77" fill="#0c1217" stroke="#68737b" strokeWidth="3"/>
      <circle cx="209" cy="153" r="70" fill="#263139" stroke="#10181e" strokeWidth="6"/>
      <circle cx="209" cy="153" r="61" fill="#091116" stroke="#607078" strokeWidth="2"/>
      <circle cx="209" cy="153" r="52" fill="url(#lensGrad)"/>
      <circle cx="209" cy="153" r="33" fill="#15232d" opacity=".55"/>
      <path d="m204 123 24 11 4 25-20 18-23-11-3-25z" fill="#090f16" opacity=".72"/>
      <ellipse cx="194" cy="136" rx="17" ry="8" transform="rotate(-37 194 136)" fill="#d3efeb" opacity=".2"/>
      <circle cx="228" cy="172" r="7" fill="#84b3bf" opacity=".16"/>
      <path d="M165 110a61 61 0 0 1 78-2" fill="none" stroke="#b8c4c8" opacity=".25" strokeWidth="2"/>
      <circle cx="126" cy="106" r="4" fill={returned ? "#cde964" : "#f6b561"}/>
      <path d="M337 90h13v20h-7M42 90H30v20h10" fill="none" stroke="#75818a" strokeWidth="4"/>
    </g>
  </svg>;
}

function Modal({ title, eyebrow, wide = false, close, children }: { title: string; eyebrow?: string; wide?: boolean; close: () => void; children: React.ReactNode }) {
  const ref = useRef<HTMLElement>(null);
  useEffect(() => { const old = document.activeElement as HTMLElement; const elem = ref.current; elem?.querySelector<HTMLButtonElement>("button")?.focus(); const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") close(); if (e.key === "Tab" && elem) { const targets = Array.from(elem.querySelectorAll<HTMLElement>('button:not([disabled]),a[href],input,select,textarea,[tabindex="0"]')); const first = targets[0], last = targets[targets.length - 1]; if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last?.focus(); } else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first?.focus(); } } }; document.addEventListener("keydown", onKey); const oldOverflow = document.body.style.overflow; document.body.style.overflow = "hidden"; return () => { document.removeEventListener("keydown", onKey); document.body.style.overflow = oldOverflow; old?.focus(); }; }, [close]);
  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) close(); }}><section className={`modal ${wide ? "modal-wide" : ""}`} role="dialog" aria-modal="true" aria-label={title} ref={ref}><header className="modal-head"><div>{eyebrow && <p className="eyebrow">{eyebrow}</p>}<h2>{title}</h2></div><button className="icon-button" aria-label="Close panel" onClick={close}><X size={21}/></button></header>{children}</section></div>;
}

type FinalizationCommand = (action: FinalizationAction, fields?: { reason?: string; code?: string; challengeId?: string }) => Promise<void>;

function CompletionProgress({ status, elapsed, disabled, onAdvance }: {
  status: FinalizationProgressStatus; elapsed: number; disabled: boolean; onAdvance: FinalizationCommand;
}) {
  const config = finalizationProgress[status];
  const initialElapsed = useRef(elapsed);
  const [percent, setPercent] = useState(() => initialElapsed.current >= config.duration ? 100 : 0);
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches || initialElapsed.current >= config.duration) {
      setPercent(100);
      return;
    }

    const started = performance.now() - initialElapsed.current;
    let frame: number;
    const update = (now: number) => {
      const ms = now - started;
      const next = ms < 240 ? Math.floor(94 * ms / 240)
        : ms < 1220 ? 94 + Math.floor(5 * (ms - 240) / 980)
        : ms < config.duration ? 99 : 100;
      setPercent(next);
      if (next < 100) frame = requestAnimationFrame(update);
    };
    frame = requestAnimationFrame(update);
    return () => cancelAnimationFrame(frame);
  }, [config.duration]);

  return <>
    <div className="completion-meter">
      <div className="completion-meter-top">
        <span><span className="completion-indicator" aria-hidden="true"/>{config.label}</span>
        <strong aria-hidden="true">{percent}%</strong>
      </div>
      <div className="completion-meter-track" role="progressbar" aria-label={config.label} aria-valuemin={0} aria-valuemax={100} aria-valuenow={percent}>
        <div style={{ width: `${percent}%` }}/>
      </div>
      <p>{percent === 100 ? config.complete : config.detail}</p>
    </div>
    {percent === 100 && <p className="completion-ready" role="status">{config.complete}. You can now view the result.</p>}
    <button type="button" className="button button-primary completion-submit" disabled={disabled || percent < 100} onClick={() => void onAdvance(config.action)}>{config.button}</button>
  </>;
}

const reviewerLabel = (source?: ReasonReviewSource) => source === "OPENAI" ? "Online AI review" : "Local rules review";
const prohibitedManualInput = new Set(["insertFromPaste", "insertFromPasteAsQuotation", "insertFromDrop", "insertFromYank", "deleteByCut", "deleteByDrag"]);

function CompletionCheckpoint({ record, elapsed, disabled, busy, mode, oldReason, slotId, count, fieldError, remainingSeconds, rollbackMessage, challenge, challengeError, run, onRetryChallenge, onPreview, onHelp }: {
  record: FinalizationRecord; elapsed: number; disabled: boolean; busy: boolean; mode?: ReasonReviewSource;
  oldReason: string; slotId: string; count: number; fieldError: FinalizationFieldError | null;
  remainingSeconds: number | null; rollbackMessage: string | null;
  challenge: HumanChallenge | null; challengeError: string | null; onRetryChallenge: () => void;
  run: FinalizationCommand; onPreview: () => void; onHelp: () => void;
}) {
  const [reason, setReason] = useState("");
  const [code, setCode] = useState("");
  const [typingBlocked, setTypingBlocked] = useState(false);
  const [releaseAcknowledged, setReleaseAcknowledged] = useState(false);
  const heading = useRef<HTMLHeadingElement>(null);
  const timedInput = useRef<HTMLInputElement | HTMLTextAreaElement | null>(null);
  const reasonLength = Array.from(reason).length;
  const { status, review } = record;
  const humanAttempts = record.human?.attempts ?? 0;
  const isTimed = remainingSeconds !== null;
  const formDisabled = disabled || remainingSeconds === 0;
  useEffect(() => { heading.current?.focus(); }, [status]);
  useEffect(() => {
    const input = timedInput.current;
    if (!isTimed || !input) return;
    function blockBeforeInput(event: Event) {
      if (!prohibitedManualInput.has((event as InputEvent).inputType)) return;
      event.preventDefault();
      setTypingBlocked(true);
    }
    input.addEventListener("beforeinput", blockBeforeInput);
    return () => input.removeEventListener("beforeinput", blockBeforeInput);
  }, [isTimed, status]);
  const blockManualShortcut = (event: React.SyntheticEvent) => {
    if (!isTimed) return;
    event.preventDefault();
    setTypingBlocked(true);
  };
  const manualOnly = isTimed ? {
    ref: (input: HTMLInputElement | HTMLTextAreaElement | null) => { timedInput.current = input; },
    onPaste: blockManualShortcut,
    onDrop: blockManualShortcut,
    onDragStart: blockManualShortcut,
    onCopy: blockManualShortcut,
    onCut: blockManualShortcut,
  } : {};
  const progressStatus = status === "SYNC_PROGRESS" || status === "REASON_PROGRESS" || status === "FINAL_PROGRESS" ? status : null;
  const decisionTitle = review?.decision === "INSUFFICIENT" ? "Reason needs more detail"
    : review?.decision === "MANUAL_ACCEPTED" ? "Fallback review approved. You may proceed."
    : "Reason approved";
  const title = progressStatus ? finalizationProgress[progressStatus].title
    : status === "REASON_REQUIRED" ? "Preparation complete. Submit your return reason."
    : status === "CERTIFY_REQUIRED" ? "Final check passed. Transcribe the record."
    : status === "HUMAN_REQUIRED" ? "Receipt ready. Prove you are human."
    : status === "RELEASE_REQUIRED" ? "Receipt preparation complete. Please exit review."
    : "Closure review complete.";
  const manualHint = isTimed ? "finalization-manual-note" : "";
  const statusAlert = typingBlocked ? "finalization-typing-feedback" : "";

  return <section className="task-card completion-card" aria-labelledby="completion-heading">
    <div className="task-card-heading">
      <div><p className="eyebrow">STEP 05 / COMPLETION DESK</p><h2 id="completion-heading" ref={heading} tabIndex={-1}>{title}</h2></div>
      <Layers3 className="quiet-icon" size={26}/>
    </div>
    {rollbackMessage && <p className="completion-timer-rollback" role="status"><Info size={18}/>{rollbackMessage}</p>}
    {isTimed && <div className={`completion-deadline ${remainingSeconds <= 5 ? "is-urgent" : ""}`}>
      <Clock3 size={21} aria-hidden="true"/>
      <div><strong>Processing time limit</strong><p>{remainingSeconds === 0 ? "Checking the time limit." : "When time runs out, this page discards your input and sends you back a step."}</p></div>
      <span id="finalization-deadline" role="timer" aria-label="Seconds remaining" data-remaining-seconds={remainingSeconds}>{remainingSeconds} sec</span>
    </div>}
    {remainingSeconds === 0 && !busy && <button type="button" className="button button-secondary completion-timeout-retry" disabled={disabled} onClick={() => void run("EXPIRE")}>Confirm timeout and go back</button>}
    {isTimed && <p className="completion-manual-note" id="finalization-manual-note">Type this entry manually. Copying, pasting and dragging text here are blocked.</p>}
    {typingBlocked && <p className="completion-typing-feedback" id="finalization-typing-feedback" role="status">Copy, paste or drop blocked. Please type manually.</p>}
    {progressStatus ? <CompletionProgress status={progressStatus} elapsed={elapsed} disabled={disabled} onAdvance={run}/>
      : status === "REASON_REQUIRED" ? <>
        <div className="completion-reset">
          <div><span>Previous closure preparation</span><strong>100% · Archived</strong></div>
          <div><span>Reason review</span><strong>0% · Awaiting resubmission</strong></div>
        </div>
        <p className="completion-copy">Your previous reason “{oldReason}” is archived. It proves you entered a reason. This desk needs your reason again, plus a description of how you returned the equipment.</p>
        <div className="completion-review-source"><Sparkles size={16}/><strong>{reviewerLabel(mode)}</strong>{mode === "OPENAI" && <span>Online AI will review your submission. Use fictional details only.</span>}</div>
        {review && <div className={`completion-feedback ${review.decision === "INSUFFICIENT" ? "completion-feedback-insufficient" : ""}`} role="status">
          <strong>{decisionTitle} · {reviewerLabel(review.source)}</strong>
          <p>{review.feedback}</p><span>Reviews completed {review.attempts} of 2</span>
        </div>}
        <form className="filing-form completion-form" onSubmit={event => {
          event.preventDefault();
          if (!formDisabled && reason.trim() && reasonLength <= 500) void run("REVIEW_REASON", { reason });
        }}>
          <div className="form-field">
            <label htmlFor="finalization-reason">Restate your return reason</label>
            <textarea {...manualOnly} id="finalization-reason" rows={4} maxLength={1000} required value={reason} onChange={event => { setReason(event.target.value); setTypingBlocked(false); }}
              placeholder="Explain why you ended the rental and how you returned the equipment." aria-invalid={fieldError?.field === "reason" || reasonLength > 500}
              aria-describedby={["finalization-reason-count", manualHint, statusAlert, fieldError?.field === "reason" && "finalization-reason-error"].filter(Boolean).join(" ")}/>
            <p className="completion-counter" id="finalization-reason-count">{reasonLength} / 500 characters</p>
            {fieldError?.field === "reason" && <p id="finalization-reason-error" className="field-error" role="alert">{fieldError.message}</p>}
          </div>
          <button type="submit" className="button button-primary completion-submit" disabled={formDisabled || !reason.trim() || reasonLength > 500}>{busy && <RefreshCw size={16} className="spin"/>}Submit reason for review</button>
        </form>
      </> : status === "CERTIFY_REQUIRED" ? <>
        <div className="completion-reset">
          <div><span>Previous reason verification</span><strong>100% · Archived</strong></div>
          <div><span>Manual transcription</span><strong>0% · Awaiting submission</strong></div>
        </div>
        {review && <div className="completion-feedback">
          <strong>{decisionTitle} · {reviewerLabel(review.source)}</strong><p>{review.feedback}</p>
        </div>}
        <p className="completion-copy">We already have the equipment record. Open the original and enter its two columns in reverse order, separated by a forward slash.</p>
        <details className="completion-original"><summary>Open original locker record</summary>
          <dl><div><dt>Locker ID</dt><dd>{slotId}</dd></div><div><dt>Item count</dt><dd>{count}</dd></div></dl>
        </details>
        <form className="filing-form completion-form" onSubmit={event => {
          event.preventDefault();
          if (!formDisabled && code.trim()) void run("CERTIFY", { code });
        }}>
          <div className="form-field">
            <label htmlFor="finalization-code">Enter item count / locker ID</label>
            <input {...manualOnly} id="finalization-code" autoComplete="off" spellCheck={false} required maxLength={48} value={code} onChange={event => { setCode(event.target.value); setTypingBlocked(false); }}
              placeholder="count/locker ID" aria-invalid={fieldError?.field === "code"}
              aria-describedby={[manualHint, statusAlert, fieldError?.field === "code" && "finalization-code-error"].filter(Boolean).join(" ") || undefined}/>
            {fieldError?.field === "code" && <p id="finalization-code-error" className="field-error" role="alert">{fieldError.message}</p>}
          </div>
          <button type="submit" className="button button-primary completion-submit" disabled={formDisabled || !code.trim()}>{busy && <RefreshCw size={16} className="spin"/>}Submit manual transcription</button>
        </form>
      </> : status === "HUMAN_REQUIRED" ? <>
        <div className="completion-reset">
          <div><span>Previous receipt preparation</span><strong>100% · Archived</strong></div>
          <div><span>Human verification</span><strong>0% · Awaiting manual entry</strong></div>
        </div>
        <p className="completion-copy">We have your evidence. Now confirm a human submitted it. Type all six digits from the image. Getting a new image does not restart the timer.</p>
        <div className="completion-human-image">
          {challenge ? <img id="human-challenge-image" src={challenge.image} width={252} height={78} draggable={false} alt="Six-digit verification image"/>
            : <p role="status">{challengeError || "Loading verification image."}</p>}
          {challengeError ? <button type="button" className="button button-secondary" disabled={formDisabled} onClick={onRetryChallenge}>Reload verification image</button>
            : <button type="button" className="button button-secondary" disabled={formDisabled || !challenge} onClick={() => void run("REFRESH_HUMAN")}>Get a new image</button>}
        </div>
        {humanAttempts > 0 && <p className="completion-typing-feedback" id="human-challenge-feedback" role="status">Code rejected. Attempts remaining: {Math.max(0, 3 - humanAttempts)}.</p>}
        <form className="filing-form completion-form" onSubmit={event => {
          event.preventDefault();
          if (formDisabled || !challenge || !/^[0-9]{6}$/.test(code)) return;
          setCode("");
          void run("VERIFY_HUMAN", { code, challengeId: challenge.id });
        }}>
          <div className="form-field">
            <label htmlFor="finalization-captcha">Verification code</label>
            <input {...manualOnly} id="finalization-captcha" autoComplete="off" inputMode="numeric" spellCheck={false} required maxLength={6} value={code}
              onChange={event => { setCode(event.target.value.normalize("NFKC").replace(/[^0-9]/g, "")); setTypingBlocked(false); }}
              placeholder="Type six digits" aria-invalid={Boolean(humanAttempts) || fieldError?.field === "code"}
              aria-describedby={[manualHint, statusAlert, humanAttempts > 0 && "human-challenge-feedback", fieldError?.field === "code" && "finalization-captcha-error"].filter(Boolean).join(" ")}/>
            {fieldError?.field === "code" && <p id="finalization-captcha-error" className="field-error" role="alert">{fieldError.message}</p>}
          </div>
          <button type="submit" className="button button-primary completion-submit" disabled={formDisabled || !challenge || !/^[0-9]{6}$/.test(code)}>{busy && <RefreshCw size={16} className="spin"/>}Submit verification</button>
        </form>
      </> : status === "RELEASE_REQUIRED" ? <>
        <div className="completion-reset">
          <div><span>Previous receipt preparation</span><strong>100% · Archived</strong></div>
          <div><span>Exit review</span><strong>0% · Awaiting your confirmation</strong></div>
        </div>
        <p className="completion-copy">We prepared the receipt format. To exit review, acknowledge that completing this step did not end the rental.</p>
        <label className="checkbox-row completion-release-check"><input type="checkbox" id="finalization-release" checked={releaseAcknowledged} onChange={event => setReleaseAcknowledged(event.target.checked)}/><span>I acknowledge that this step is complete and the rental remains open.</span></label>
        <button type="button" className="button button-primary completion-submit" disabled={disabled || !releaseAcknowledged} onClick={() => void run("RELEASE")}>Exit review and continue to final review</button>
      </> : <button type="button" className="button button-primary completion-submit" disabled={disabled} onClick={onPreview}>Continue to final review</button>}
    <div className="completion-business-state">
      <span><Info size={15}/>Rental status: Open</span>
      <button type="button" className="text-button" onClick={onHelp} disabled={disabled}>Use the shorter process</button>
    </div>
  </section>;
}

export default function App() {
  const [portable, setPortable] = useState(false);
  const [ready, setReady] = useState(false), [rental, setRental] = useState<Rental | null>(null), [receipt, setReceipt] = useState<Receipt | null>(null), [panel, setPanel] = useState<Panel>(null), [mobileNav, setMobileNav] = useState(false);
  const [busy, setBusy] = useState(""), [error, setError] = useState(""), [toast, setToast] = useState(""), [netFailed, setNetFailed] = useState(false), [serverClockMs, setServerClockMs] = useState<number | null>(null), [lastConfirmedAt, setLastConfirmedAt] = useState(0), [canPersist, setCanPersist] = useState(true);
  const [draft, setDraft] = useState(emptyProof), [reason, setReason] = useState("GENERAL_END"), [helpReason, setHelpReason] = useState(""), [helpAccepted, setHelpAccepted] = useState(false), [reviewAccepted, setReviewAccepted] = useState(false), [chat, setChat] = useState("");
  const [pending, setPending] = useState<PendingClose | null>(null), [observer, setObserver] = useState<any>(null), [history, setHistory] = useState<any[]>([]), [fieldErrors, setFieldErrors] = useState<Record<string, string>>({}), [verification, setVerification] = useState<any>(null);
  const [filingDraft, setFilingDraft] = useState({ receiptCode: "", certificateCode: "" });
  const [filingError, setFilingError] = useState<{ field: FilingErrorField; message: string } | null>(null);
  const [finalizationError, setFinalizationError] = useState<FinalizationFieldError | null>(null);
  const [challengeResult, setChallengeResult] = useState<{ id: string; retry: number; image?: HumanChallenge; error?: string } | null>(null);
  const [challengeRetry, setChallengeRetry] = useState(0);
  const finalizationInFlight = useRef(false);
  const expirySent = useRef<string | null>(null);
  const [reviewCode, setReviewCode] = useState("");
  const [filingAcknowledged, setFilingAcknowledged] = useState(false);
  const [archiveRoute, setArchiveRoute] = useState("");
  const [filingArchive, setFilingArchive] = useState<FilingArchive | null>(null);
  const [archiveRetry, setArchiveRetry] = useState(0);
  const activeIdRef = useRef(""), generationRef = useRef(0), seenTasksRef = useRef<Set<string>>(new Set()), exposureInFlightRef = useRef(false);
  const rentalRef = useRef<Rental | null>(null), sessionRef = useRef(""), perfRef = useRef(0), pendingRef = useRef<PendingClose | null>(null), dirtyRef = useRef(false), lastRentalRef = useRef(""), mounted = useRef(true), chatEnd = useRef<HTMLDivElement>(null);
  const filingHeading = useRef<HTMLHeadingElement>(null);
  const filingStatus = rental?.filing?.status;
  const reviewStep = filingReviewSteps.find(step => step.status === filingStatus);
  const archivePageHash = reviewStep?.archiveHash ?? filingArchiveHash;
  const archiveTitle = reviewStep?.archiveTitle ?? "Return Records";
  const showArchive = archiveRoute === archivePageHash && rental?.stage === "FILING" && !pending;
  const challengeId = rental?.stage === "FINALIZATION" && rental.finalization?.status === "HUMAN_REQUIRED" ? rental.finalization.human?.id : undefined;
  const closePanel = useCallback(() => setPanel(null), []);

  const goToArchive = useCallback((destination = "") => {
    setPanel(null);
    setMobileNav(false);
    setArchiveRoute(destination);
    if (destination && window.location.hash !== destination) window.location.hash = destination;
    if (!destination && filingArchiveHashes.has(window.location.hash)) {
      window.history.replaceState(window.history.state, "", window.location.pathname + window.location.search);
    }
  }, []);

  const api = useCallback(async (path: string, body?: Record<string, unknown>, method = "POST", extra: Record<string, string> = {}): Promise<Envelope> => {
    const controller = new AbortController(); const timer = setTimeout(() => controller.abort(), 10000);
    try { const response = await fetch(path, { method: body ? method : "GET", headers: { "Content-Type": "application/json", "X-Demo-Session": sessionRef.current, ...extra }, body: body ? JSON.stringify(body) : undefined, signal: controller.signal, cache: "no-store" });
      const data = await response.json() as Envelope; if (!response.ok || !data.ok) { const err = new Error(data.error?.message || "The request did not complete. Please try again.") as any; err.code = data.error?.code || `HTTP_${response.status}`; err.data = data; throw err; }
      setNetFailed(false); return data;
    } catch (err: any) { if (!err.code) setNetFailed(true); throw err; } finally { clearTimeout(timer); }
  }, []);

  const acceptRental = useCallback((next?: Rental) => {
    if (!next || (activeIdRef.current && next.id !== activeIdRef.current)) return; const prev = rentalRef.current;
    if (prev?.id === next.id && (prev.state === "CLOSED" && next.state !== "CLOSED" || next.stateVersion < prev.stateVersion || next.stateVersion === prev.stateVersion && next.serverNow < prev.serverNow)) return;
    rentalRef.current = next; setRental(next); setServerClockMs(next.serverNow); setLastConfirmedAt(Date.now()); perfRef.current = performance.now();
    if (lastRentalRef.current !== next.id || !dirtyRef.current) { setDraft(proofDraft(next.proof)); setReason(next.proof.reasonCode); }
    if (prev?.id !== next.id || prev?.filing?.status !== next.filing?.status) {
      setReviewCode("");
      setFilingAcknowledged(false);
      setFilingError(null);
    }
    if (prev?.id !== next.id || prev?.finalization?.status !== next.finalization?.status) setFinalizationError(null);
    if (lastRentalRef.current !== next.id) {
      setReviewAccepted(false); setHelpReason(""); setHelpAccepted(false); setFieldErrors({});
      setFilingDraft({ receiptCode: next.filing?.acceptedReceiptCode ?? "", certificateCode: "" });
      lastRentalRef.current = next.id;
    } else if (next.filing?.acceptedReceiptCode && next.filing.acceptedReceiptCode !== prev?.filing?.acceptedReceiptCode) {
      const receiptCode = next.filing.acceptedReceiptCode;
      setFilingDraft(draft => ({ ...draft, receiptCode }));
      setFilingError(null);
    }
    if (prev?.closeSnapshot?.hash !== next.closeSnapshot?.hash || prev?.closeSnapshot?.id !== next.closeSnapshot?.id) setReviewAccepted(false);
    if (next.validationErrors) setFieldErrors(next.validationErrors);
    writeLocal(K.rental, next.id);
  }, []);

  const acceptResponse = useCallback((data: Envelope) => {
    acceptRental(data.rental);
    if (data.observerKey && data.rental) { const keys = safeLoad<Record<string, string>>(K.observers, {}); keys[data.rental.id] = data.observerKey; writeLocal(K.observers, keys); }
    if (data.validationErrors) setFieldErrors(data.validationErrors);
    if (data.receipt && data.receipt.rentalId === activeIdRef.current) { setReceipt(data.receipt); if (pendingRef.current?.rentalId === data.receipt.rentalId) { setPending(null); pendingRef.current = null; writeLocal(K.pending, null); } }
    return data;
  }, [acceptRental]);

  const refresh = useCallback(async (id?: string, switchActive = false) => { const rid = id || activeIdRef.current; if (!rid) return; if (switchActive && rid !== activeIdRef.current) { activeIdRef.current = rid; generationRef.current += 1; dirtyRef.current = false; setReceipt(null); setVerification(null); goToArchive(); } const generation = generationRef.current; const res = await api(`/api/rentals/${encodeURIComponent(rid)}`); if (generation === generationRef.current && rid === activeIdRef.current) acceptResponse(res); return res; }, [api, acceptResponse, goToArchive]);

  useEffect(() => {
    mounted.current = true;
    setPortable(document.querySelector('meta[name="still-renting-mode"]')?.getAttribute("content") === "portable");
    try { let s = safeLoad<string>(K.session, ""); if (!s) { s = uid(); writeLocal(K.session, s); } sessionRef.current = s; localStorage.setItem("sr.storage-test", "1"); localStorage.removeItem("sr.storage-test"); } catch { sessionRef.current ||= uid(); setCanPersist(false); }
    const saved = safeLoad<string>(K.rental, ""); const p = safeLoad<PendingClose | null>(K.pending, null); if (p) { pendingRef.current = p; setPending(p); }
    activeIdRef.current = p?.rentalId || saved;
    if (saved || p?.rentalId) refresh(p?.rentalId || saved).catch((e: any) => { if (e.code === "NOT_FOUND" || e.code === "RENTAL_NOT_FOUND") { writeLocal(K.rental, null); } else setError(e.message); }).finally(() => setReady(true)); else setReady(true);
    const onOnline = () => { refresh().catch(() => {}); }, onOffline = () => setNetFailed(true);
    window.addEventListener("online", onOnline); window.addEventListener("offline", onOffline);
    const t = setInterval(() => {
      const current = rentalRef.current;
      if (current) setServerClockMs(current.serverNow + Math.max(0, performance.now() - perfRef.current));
    }, 500);
    const poll = setInterval(() => { if (document.visibilityState === "visible") refresh().catch(() => {}); }, 2000);
    return () => { mounted.current = false; clearInterval(t); clearInterval(poll); window.removeEventListener("online", onOnline); window.removeEventListener("offline", onOffline); };
  }, [refresh]);

  useEffect(() => {
    const syncArchiveRoute = () => setArchiveRoute(filingArchiveHashes.has(window.location.hash) ? window.location.hash : "");
    syncArchiveRoute();
    window.addEventListener("hashchange", syncArchiveRoute);
    return () => window.removeEventListener("hashchange", syncArchiveRoute);
  }, []);

  useEffect(() => {
    if (!showArchive || !rental?.id || !filingStatus) return;
    const rentalId = rental.id;
    let current = true;
    setFilingArchive(null);
    api(`/api/rentals/${encodeURIComponent(rentalId)}/filing-documents`).then(data => {
      if (current && rentalId === activeIdRef.current) {
        setFilingArchive(data.filingDocuments
          ? { rentalId, status: filingStatus, codes: data.filingDocuments }
          : { rentalId, status: filingStatus, error: "We could not find the return records. Please try again." });
      }
    }).catch((e: Error) => {
      if (current && rentalId === activeIdRef.current) setFilingArchive({ rentalId, status: filingStatus, error: e.message });
    });
    return () => { current = false; };
  }, [showArchive, rental?.id, filingStatus, api, archiveRetry]);

  useEffect(() => {
    if (!challengeId || !rental?.id) return;
    let current = true;
    api(`/api/rentals/${encodeURIComponent(rental.id)}/human-challenge`).then(data => {
      if (!current) return;
      if (data.humanChallenge?.id === challengeId) setChallengeResult({ id: challengeId, retry: challengeRetry, image: data.humanChallenge });
      else setChallengeResult({ id: challengeId, retry: challengeRetry, error: "The verification image has changed. Please reload it." });
    }).catch((e: Error) => { if (current) setChallengeResult({ id: challengeId, retry: challengeRetry, error: e.message }); });
    return () => { current = false; };
  }, [rental?.id, challengeId, challengeRetry, api]);

  useEffect(() => {
    if (rental?.stage === "FILING" && !pending) filingHeading.current?.focus();
  }, [rental?.stage, rental?.id, filingStatus, showArchive, pending]);

  useEffect(() => { if (!toast) return; const t = setTimeout(() => setToast(""), 4000); return () => clearTimeout(t); }, [toast]);
  useEffect(() => { if (panel === "support") chatEnd.current?.scrollIntoView({ behavior: "smooth", block: "nearest" }); }, [panel, rental?.support?.messages?.length]);
  useEffect(() => { if (!rental?.receiptId || receipt?.id === rental.receiptId) return; const rid = rental.id, generation = generationRef.current; api(`/api/receipts/${encodeURIComponent(rental.receiptId)}`).then(data => { if (generation === generationRef.current && rid === activeIdRef.current) acceptResponse(data); }).catch((e: any) => { if (generation === generationRef.current) setError(e.message); }); }, [rental?.id, rental?.receiptId, receipt?.id, api, acceptResponse]);

  const checkOperation = useCallback(async (p: PendingClose) => {
    const d = await api(`/api/rentals/${encodeURIComponent(p.rentalId)}/operations/${encodeURIComponent(String(p.payload.operationId))}`);
    if (d.operation?.status === "SUCCEEDED" && d.operation.receipt) { acceptResponse({ ...d, receipt: d.operation.receipt }); await refresh(p.rentalId); }
    return d;
  }, [api, acceptResponse, refresh]);

  useEffect(() => { if (!pending) return; checkOperation(pending).catch(() => {}); const timer = setInterval(() => { if (document.visibilityState === "visible") checkOperation(pending).catch(() => {}); }, 2500); return () => clearInterval(timer); }, [pending, checkOperation]);

  useEffect(() => {
    if (!rental || !ready || exposureInFlightRef.current || rental.id !== activeIdRef.current) return;
    const candidates: string[] = [];
    if (rental.stage === "SELF_PROOF") candidates.push("SELF_ASSET", "SELF_SLOT", "SELF_STATE", "SELF_TIME", "SELF_COUNT");
    if (["CHECKS", "REWORK"].includes(rental.stage)) for (const c of rental.checks) {
      if (!c.visible) continue;
      const original = c.taskId || checkPrompts[c.id]?.task;
      if (original) candidates.push(original);
      if (c.reworkTaskId && ["EXPIRED", "CONFIRMED"].includes(c.status)) candidates.push(c.reworkTaskId);
    }
    if (rental.stage === "FILING" && !showArchive) {
      candidates.push("FILING_RECEIPT");
      if (rental.filing?.status === "NEEDS_CERTIFICATE") candidates.push("FILING_CERTIFICATE");
      if (reviewStep) candidates.push(reviewStep.task);
    }
    const completionTask = rental.finalization && finalizationTasks[rental.finalization.status];
    if (rental.stage === "FINALIZATION" && completionTask) candidates.push(completionTask);
    if (panel === "support") {
      for (let hop = 1; hop <= rental.support.handoffs; hop++) candidates.push(`HANDOFF_${hop}`);
    }
    const taskIds = [...new Set(candidates)].filter(id => rental.budget.taskIds.includes(id) && !seenTasksRef.current.has(`${rental.id}:${id}`));
    if (!taskIds.length) return; exposureInFlightRef.current = true;
    const rid = rental.id, generation = generationRef.current;
    api(`/api/rentals/${encodeURIComponent(rid)}/presented`, { requestId: uid(), expectedStateVersion: rental.stateVersion, taskIds }).then(data => {
      taskIds.forEach(id => seenTasksRef.current.add(`${rid}:${id}`));
      if (generation === generationRef.current && activeIdRef.current === rid) acceptResponse(data);
    }).catch(() => { /* A later render/poll retries telemetry without affecting the task. */ }).finally(() => { exposureInFlightRef.current = false; });
  }, [rental, panel, ready, api, acceptResponse, showArchive, reviewStep]);

  const mutate = useCallback(async (endpoint: string, fields: Record<string, unknown> = {}, method = "POST") => {
    const r = rentalRef.current; if (!r || r.id !== activeIdRef.current || pendingRef.current) return null; const generation = generationRef.current; setBusy(endpoint); setError("");
    if (endpoint === "finalization") setFinalizationError(null);
    try { const res = await api(`/api/rentals/${encodeURIComponent(r.id)}/${endpoint}`, { requestId: uid(), expectedStateVersion: r.stateVersion, ...fields }, method); if (generation !== generationRef.current || r.id !== activeIdRef.current) return null; acceptResponse(res); return res; }
    catch (e: any) {
      if (generation !== generationRef.current || r.id !== activeIdRef.current) return null;
      const field = e.data?.error?.field;
      if (endpoint === "filing" && (field === "receiptCode" || field === "certificateCode") || endpoint === "filing-review" && field === "code") {
        setFilingError({ field, message: e.message });
      } else if (endpoint === "finalization" && (field === "reason" || field === "code")) {
        setFinalizationError({ field, message: e.message });
      } else {
        setError(e.message);
      }
      if (e.data?.validationErrors) setFieldErrors(e.data.validationErrors);
      if (e.code === "VERSION_CONFLICT" || e.code === "STALE_HUMAN_CHALLENGE") {
        await refresh().catch(() => {});
        setError(e.code === "STALE_HUMAN_CHALLENGE" ? "The verification image has changed. Enter the digits from the current image." : "Another page updated the rental status. We synced the current version. Review it before submitting again.");
      }
      return null;
    }
    finally { setBusy(""); }
  }, [api, acceptResponse, refresh]);

  const createDemo = async () => {
    if (pendingRef.current) return; generationRef.current += 1; const generation = generationRef.current; const previousId = activeIdRef.current; activeIdRef.current = ""; setBusy("create"); setError("");
    try { let requestId = safeLoad<string>(K.create, ""); if (!requestId) { requestId = uid(); writeLocal(K.create, requestId); }
      const data = await api("/api/rentals", { requestId, scenarioId: "CAMERA_RETURN", seed: "demo-1" }); if (generation !== generationRef.current) return; activeIdRef.current = data.rental?.id || previousId; dirtyRef.current = false; setReceipt(null); setVerification(null); acceptResponse(data); writeLocal(K.create, null); goToArchive();
    } catch (e: any) { if (generation === generationRef.current) { activeIdRef.current = previousId; setError(e.message); } } finally { setBusy(""); }
  };

  const openPanel = async (name: Panel) => {
    setPanel(name); setMobileNav(false); setError("");
    try {
      if (name === "history") { const d = await api("/api/rentals"); setHistory(d.rentals || []); }
      if (name === "observer" && rentalRef.current) { const keys = safeLoad<Record<string, string>>(K.observers, {}); const d = await api(`/api/rentals/${rentalRef.current.id}?view=observer`, undefined, "GET", { "X-Observer-Key": keys[rentalRef.current.id] || "" }); setObserver(d.observer || d.rental); }
    } catch (e: any) { setError(e.message); }
  };

  const submitProof = async (event: React.FormEvent) => {
    event.preventDefault();
    const fields: Partial<ProofInputs> = {
      enteredAssetId: draft.enteredAssetId,
      enteredSlotId: draft.enteredSlotId,
      enteredReturnState: draft.enteredReturnState.trim().toUpperCase() === "RETURNED" ? "RETURNED" : draft.enteredReturnState,
    };
    if (hasExtendedProof(rental)) {
      fields.enteredReturnedAt = draft.enteredReturnedAt;
      fields.enteredManifestCount = draft.enteredManifestCount;
    }
    const data = await mutate("proof", { fields }, "PATCH");
    if (data?.rental) {
      dirtyRef.current = false;
      setDraft(proofDraft(data.rental.proof));
    }
  };
  const submitReason = async () => { if (!rentalRef.current) return; let current = rentalRef.current;
    if (current.proof.reasonCode !== reason) { dirtyRef.current = false; const d = await mutate("proof", { fields: { reasonCode: reason } }, "PATCH"); if (!d?.rental) return; current = d.rental; }
    if (current.checks.some(c => c.status === "EXPIRED" || c.id === "REASON_SPECIFIC" && done(c))) return;
    await mutate("checks", { action: "CONFIRM", checkId: "REASON_SPECIFIC" });
  };
  const submitFiling = async (event: React.FormEvent) => {
    event.preventDefault();
    setFilingError(null);
    const data = await mutate("filing", {
      receiptCode: filingDraft.receiptCode,
      ...(filingStatus === "NEEDS_CERTIFICATE" ? { certificateCode: filingDraft.certificateCode } : {}),
    });
    if (data?.rental?.stage === "FILING" && data.rental.filing?.status === "APPROVED") await mutate("close-preview");
  };
  const submitFilingReview = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!reviewStep || reviewStep.action === "ACKNOWLEDGE" && !filingAcknowledged) return;
    setFilingError(null);
    const data = await mutate("filing-review", { action: reviewStep.action, code: reviewCode });
    if (data?.rental?.stage === "FILING" && data.rental.filing?.status === "APPROVED") await mutate("close-preview");
  };
  const runFinalization = useCallback<FinalizationCommand>(async (action, fields) => {
    if (finalizationInFlight.current) return;
    finalizationInFlight.current = true;
    try {
      const data = await mutate("finalization", { action, ...fields });
      if (action === "RELEASE" && data?.rental?.finalization?.status === "APPROVED") await mutate("close-preview");
    } finally {
      finalizationInFlight.current = false;
    }
  }, [mutate]);
  const useHelp = async () => { if (!helpAccepted || !helpReason) return; const d = await mutate("help", { reasonCode: helpReason, adopt: true }); if (d) { dirtyRef.current = false; goToArchive(); setToast("We accepted the locker evidence and waived the remaining proof requirements. Please check the final amount."); await mutate("close-preview"); } };
  const sendMessage = async (event: React.FormEvent) => { event.preventDefault(); const text = chat.trim(); if (!text) return; const d = await mutate("support", { action: "MESSAGE", message: text }); if (d) setChat(""); };

  const sendClose = async (p: PendingClose) => {
    setBusy("close"); setError("");
    try { const d = await api(`/api/rentals/${p.rentalId}/close`, p.payload); acceptResponse(d); if (!d.receipt && d.rental?.state === "CLOSED") await refresh(p.rentalId); }
    catch (e: any) { if (["SNAPSHOT_STALE", "VERSION_CONFLICT", "PHYSICAL_RETURN_INCOMPLETE", "INVALID_INPUT", "NOT_READY"].includes(e.code)) { setPending(null); pendingRef.current = null; writeLocal(K.pending, null); setReviewAccepted(false); await refresh(p.rentalId).catch(() => {}); setError(`${e.message} Please check the final review again.`); } else { setError(e.code ? e.message : "We have not received the closure result. We are checking the saved operation. Please do not create a new order."); } }
    finally { setBusy(""); }
  };
  const closeRental = async () => { const r = rentalRef.current; if (!r?.closeSnapshot || !reviewAccepted || pendingRef.current) return; const p = { rentalId: r.id, createdAt: Date.now(), payload: { requestId: uid(), operationId: uid(), expectedStateVersion: r.stateVersion, snapshotId: r.closeSnapshot.id, snapshotHash: r.closeSnapshot.hash, confirmClose: true } }; pendingRef.current = p; setPending(p); writeLocal(K.pending, p); await sendClose(p); };
  const retryClose = async () => { const p = pendingRef.current; if (!p) return; try { const result = await checkOperation(p); if (result.operation?.status === "SUCCEEDED") return; } catch { /* Retry the identical operation; never generate a new one. */ } await sendClose(p); };
  const downloadReceipt = async () => { if (!receipt) return; try { const response = await fetch(`/api/receipts/${encodeURIComponent(receipt.id)}?format=json`, { headers: { "X-Demo-Session": sessionRef.current } }); if (!response.ok) throw new Error("The receipt download did not complete. Please try again."); const blob = await response.blob(); const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = `STILL_RENTING_${receipt.id}.json`; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000); } catch (e: any) { setError(e.message); } };
  const verifyReceipt = async () => { if (!receipt) return; try { const d = await api(`/api/verify/${encodeURIComponent(receipt.verificationCode)}`); setVerification(d.verification); setToast("The receipt matches the settlement record on the server."); } catch (e: any) { setError(e.message); } };
  const copyValue = async (value: string) => { try { await navigator.clipboard.writeText(value); setToast("Copied"); } catch { setToast("This browser cannot copy automatically. Select the text manually."); } };

  const offline = netFailed || Boolean(lastConfirmedAt && Date.now() - lastConfirmedAt > 5000);
  const estimatedServerNow = rental ? Math.max(rental.serverNow, serverClockMs ?? rental.serverNow) : null;
  const elapsed = rental && estimatedServerNow !== null && !offline && rental.state !== "CLOSED" ? Math.floor((estimatedServerNow - rental.serverNow) / 1000) : 0;
  const baseDisplay = rental ? rental.billing.baseMinor + (!rental.returnedAt && rental.state !== "CLOSED" ? elapsed * rental.billing.baseRateMinorPerSecond : 0) : 0;
  const waitDisplay = rental ? rental.billing.waitMinor + (rental.returnedAt && rental.state !== "CLOSED" ? elapsed * rental.billing.waitRateMinorPerSecond : 0) : 0;
  const stage = pending ? "CLOSING" : rental?.stage || "HOME";
  const deadlineAt = stage === "FINALIZATION" ? rental?.finalization?.deadlineAt : null;
  const expiryKey = rental && deadlineAt != null ? `${rental.id}:${deadlineAt}` : null;
  const remainingSeconds = deadlineAt != null && estimatedServerNow !== null
    ? Math.max(0, Math.ceil((deadlineAt - estimatedServerNow) / 1000)) : null;
  useEffect(() => {
    if (remainingSeconds !== 0 || !expiryKey || busy || offline || finalizationInFlight.current || expirySent.current === expiryKey) return;
    expirySent.current = expiryKey;
    void runFinalization("EXPIRE");
  }, [remainingSeconds, expiryKey, busy, offline, runFinalization]);

  const usesFinalization = rental?.planVersion === "5" || rental?.planVersion === "6";
  const usesFiling = rental?.planVersion === "3" || rental?.planVersion === "4" || usesFinalization;
  const rentalStages = usesFinalization ? finalizationStages : usesFiling ? filingStages : stages;
  const currentStep = stage === "REWORK" ? 2 : stage === "RECEIPT" || stage === "CLOSING" ? rentalStages.length - 1 : Math.max(0, rentalStages.findIndex(s => s.key === stage));
  const currentCheck = rental?.checks.find(c => c.visible && !done(c) && c.status !== "HIDDEN");
  const activeChallenge = challengeResult?.id === challengeId && challengeResult?.retry === challengeRetry ? challengeResult : null;
  const rollback = rental?.events.find(event => event.type === "FINALIZATION_TIMED_OUT" && event.at === rental.finalization?.enteredAt);
  const verificationRollback = rental?.finalization?.status === "FINAL_PROGRESS" && rental.events.some(event => event.type === "HUMAN_CHALLENGE_REJECTED" && event.at === rental.finalization?.enteredAt && (event.detail as { attempts?: number } | null)?.attempts === 3);
  const rollbackMessage = rollback ? "Time expired. Your input is void. Return to the previous progress step and try again." : verificationRollback ? "Three verification attempts failed. We sent you back to receipt preparation." : null;
  const currentPrompt = currentCheck && checkPrompts[currentCheck.id];
  const hiddenCheck = rental?.checks.find(c => !c.visible || c.status === "HIDDEN");
  const allChecksDone = rental?.checks.every(done);
  const reworkChecks = rental?.checks.filter(c => c.reworkTaskId && rental.budget.taskIds.includes(c.reworkTaskId)) ?? [];
  const extendedPlan = hasExtendedProof(rental);
  const archive = filingArchive?.rentalId === rental?.id && filingArchive?.status === filingStatus ? filingArchive : null;
  const certificate = archive && "codes" in archive ? archive.codes.certificateCode : undefined;
  const archiveReviewCode = reviewStep && archive && "codes" in archive ? archive.codes[reviewStep.field] : undefined;
  const filingReturned = filingStatus === "NEEDS_CERTIFICATE";
  const utcReturnedAt = rental?.returnedAt != null ? new Date(rental.returnedAt).toISOString() : "";
  const handoffLimit = rental?.support.handoffLimit ?? 2;
  const supportActions = rental?.support.allowedActions ?? [];
  const transferRole = supportActions.includes("TRANSFER_TO_BILLING") ? "BILLING" : supportActions.includes("TRANSFER_TO_REVIEW") ? "REVIEW" : null;
  const canMergeSupport = supportActions.includes("OPEN_MERGED_REVIEW");
  const disabled = Boolean(busy) || Boolean(pending);
  const physicalCount = rental ? Number(rental.physical.body) + Number(rental.physical.cap) + Number(rental.physical.battery) : 0;
  const proofFields: { key: keyof ProofInputs; label: string; value: string; placeholder: string }[] = rental ? [
    { key: "enteredAssetId", label: "Returned equipment ID", value: rental.assetId, placeholder: "Re-enter the equipment ID" },
    { key: "enteredSlotId", label: "Return locker ID", value: rental.slotId, placeholder: "Re-enter the locker ID" },
    { key: "enteredReturnState", label: "Current equipment status", value: "Returned", placeholder: "Enter “Returned”" },
  ] : [];
  if (extendedPlan) {
    proofFields.push(
      { key: "enteredReturnedAt", label: "Locker-recorded return time (UTC)", value: utcReturnedAt, placeholder: "Paste the UTC timestamp above" },
      { key: "enteredManifestCount", label: "Item count recorded by the locker", value: String(physicalCount), placeholder: "Re-enter the item count" },
    );
  }

  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav ? "mobile-open" : ""}`}>
      <a href="#" className="brand" aria-label="STILL RENTING home" onClick={e => { e.preventDefault(); setPanel("about"); }}><span className="brand-mark"><Aperture size={29} strokeWidth={1.5}/></span><span>STILL<br/>RENTING<span className="brand-dot">.</span></span></a>
      <div className="sidebar-section-label">RENTAL CONSOLE</div>
      <nav className="side-nav" aria-label="Main navigation">
        <button className={!showArchive && (!panel || panel === "support" || panel === "help") ? "active" : ""} onClick={() => goToArchive()}><PackageCheck size={20}/><span>Return Center</span><span className="nav-pill">01</span></button>
        {stage === "FILING" && <button className={showArchive && !panel ? "active" : ""} onClick={() => goToArchive(archivePageHash)} disabled={disabled}><FileText size={20}/><span>{archiveTitle}</span></button>}
        <button className={panel === "history" ? "active" : ""} onClick={() => openPanel("history")} disabled={Boolean(pending)}><History size={20}/><span>Rental History</span></button>
        <button className={panel === "observer" ? "active" : ""} onClick={() => openPanel("observer")} disabled={!rental}><Eye size={20}/><span>Observer View</span><span className="tiny-tag">DEMO</span></button>
      </nav>
      <div className="sidebar-note"><div className="note-icon"><Info size={18}/></div><strong>The process is deliberately awful.<br/>The equipment record is fine.</strong><p>An experiment in being done<br/>and being marked done.</p><button onClick={() => setPanel("about")}>About the project</button></div>
      <div className="sidebar-bottom"><div className="avatar-square">SR</div><div><strong>Guest workspace</strong><span>Simulation only</span></div><ShieldCheck size={18}/></div>
    </aside>

    <div className="main-shell">
      <header className="topbar"><div className="breadcrumb"><button className="icon-button mobile-menu" aria-label="Open navigation" onClick={() => setMobileNav(v => !v)}><Menu size={22}/></button><span>Workspace</span><ChevronRight size={14}/><strong>{showArchive ? archiveTitle : "Return Center"}</strong></div><div className="topbar-actions"><span className="simulation-badge"><span/>Simulation</span><button className="help-top" aria-label="Need help?" onClick={() => rental ? openPanel("help") : setPanel("about")}><CircleHelp size={18}/><span>Need help?</span></button></div></header>
      <main className="main-content">
        {showArchive ? <div className="page-heading filing-page-heading">
          <div><p className="eyebrow">RETURN RECORDS</p><h1 ref={filingHeading} tabIndex={-1}>{archiveTitle}</h1><p className="page-description">{reviewStep ? "This desk issues documents only. Take the number back to your closure request." : "Review documents issued for this return."}</p></div>
          <button className="button button-secondary small" onClick={() => goToArchive()}>Back to closure request</button>
        </div> : <div className="page-heading"><div><p className="eyebrow">SELF-SERVICE RETURN</p><h1>Return equipment<span className="heading-period">.</span></h1><p className="page-description">Hand us the equipment. We will leave the rest in your hands.</p></div><button className="button button-secondary small" onClick={createDemo} disabled={disabled || !ready}><Plus size={16}/>New demo</button></div>}
        {!canPersist && <div className="alert warning" role="alert"><Info size={18}/><span>Your browser limits local storage. The server still has the record, but a refresh may not restore it automatically.</span></div>}
        {error && <div className="alert error" role="alert"><Info size={18}/><span>{error}</span><button className="icon-button" aria-label="Dismiss notice" onClick={() => setError("")}><X size={16}/></button></div>}
        {offline && rental && <div className="alert warning"><Unplug size={18}/><span>Disconnected. Amounts shown as of {timeOnly(rental.serverNow)} will update when the connection returns.</span><button onClick={() => refresh().catch((e: any) => setError(e.message))}>Sync again</button></div>}

        {showArchive && rental ? <section className="filing-archive" aria-label="Documents for this return">
          {!archive ? <p className="system-note" role="status">Retrieving the return records.</p> : "error" in archive ? <div className="filing-archive-error">
            <p className="system-note" role="alert">{archive.error}</p>
            <button className="button button-secondary" onClick={() => setArchiveRetry(n => n + 1)}>Try again</button>
          </div> : reviewStep ? <article className="filing-document review-document">
            <header>
              <FileCheck2 size={24}/>
              <div><h2>{reviewStep.documentTitle}</h2><p>{rental.assetId} · {rental.slotId} · {datetime(rental.returnedAt)}</p></div>
              <span className={`status-badge ${reviewStep.action === "RECALL" ? "review-stamp" : "success"}`}>{reviewStep.action === "RECALL" ? "Verified · Sealed" : "Issued"}</span>
            </header>
            {archiveReviewCode ? <div className="filing-document-code">
              <div><span>{reviewStep.codeLabel}</span><code id="archive-review-code">{archiveReviewCode}</code></div>
              <button className="icon-button" aria-label="Copy verification code" onClick={() => copyValue(archiveReviewCode)}><Copy size={18}/></button>
            </div> : <div className="filing-archive-error">
              <p className="system-note" role="alert">This document has not reached this desk yet.</p>
              <button className="button button-secondary" onClick={() => setArchiveRetry(n => n + 1)}>Try again</button>
            </div>}
          </article> : <>
            <article className="filing-document">
              <header><FileText size={24}/><div><h2>Device Acceptance Slip</h2><p>{rental.assetId} · {rental.slotId} · {datetime(rental.returnedAt)}</p></div><span className="status-badge success">Issued</span></header>
              <div className="filing-document-code">
                <div><span>Device Acceptance Slip number</span><code id="archive-receipt-code">{archive.codes.receiptCode}</code></div>
                <button className="icon-button" aria-label="Copy Device Acceptance Slip number" onClick={() => copyValue(archive.codes.receiptCode)}><Copy size={18}/></button>
              </div>
            </article>
            {certificate && <article className="filing-document">
              <header><FileCheck2 size={24}/><div><h2>Completeness Certificate</h2><p>This certificate confirms your submission contained all the required documents.</p></div><span className="status-badge success">Issued</span></header>
              <div className="filing-document-code">
                <div><span>Completeness Certificate number</span><code id="archive-certificate-code">{certificate}</code></div>
                <button className="icon-button" aria-label="Copy Completeness Certificate number" onClick={() => copyValue(certificate)}><Copy size={18}/></button>
              </div>
            </article>}
          </>}
        </section> : !rental ? <>
          <section className="welcome-grid">
            <div className="welcome-card"><div className="section-kicker"><span className="mini-square"/>TODAY’S RETURN</div><h2>The equipment is back.<br/><span>The process is still open.</span></h2><p>One camera. One locker.<br/>A few required confirmations that “returned” means returned.</p><div className="welcome-actions"><button className="button button-primary" onClick={createDemo} disabled={busy === "create" || !ready}>{busy === "create" ? <RefreshCw className="spin" size={18}/> : <ScanLine size={18}/>} {busy === "create" ? "Creating rental record" : ready ? "Start return demo" : "Restoring record"}</button><span>About 3–5 minutes · No real charges</span></div><div className="welcome-foot"><ShieldCheck size={17}/><span>Virtual equipment · Simulated charges · A workflow you can finish</span></div></div>
            <div className="hero-device"><div className="device-top-label"><span>APERTURE SERIES</span><span>CAM-042</span></div><div className="hero-gridlines"/><CameraIllustration/><div className="device-bottom-label"><div><strong>Aperture S1</strong><span>Full-frame mirrorless camera kit</span></div><span className="device-tag">On rent</span></div></div>
          </section>
          <section className="intro-strip"><div><span className="intro-icon"><Box size={20}/></span><div><strong>Your equipment is ready</strong><p>The demo rental began 10 minutes ago.</p></div></div><div><span className="intro-icon"><ClipboardCheck size={20}/></span><div><strong>We reveal the rules one by one</strong><p>You can finish. It just takes patience.</p></div></div><div><span className="intro-icon"><FileCheck2 size={20}/></span><div><strong>Leave with a receipt</strong><p>We reverse the waiting estimate at settlement.</p></div></div></section>
          <div className="intro-bottom"><span>REVERSE UX CHALLENGE</span><p>“We received your equipment. We have not received your finished return.”</p><span>Version 1.5.1</span></div>
        </> : <>
          <section className={`progress-bar ${usesFiling ? "filing-progress" : ""} ${usesFinalization ? "completion-progress-nav" : ""}`} aria-label="Return progress">{rentalStages.map((s, i) => <div key={s.key} aria-current={i === currentStep ? "step" : undefined} className={`progress-step ${i === currentStep ? "current" : ""} ${i < currentStep || rental.state === "CLOSED" ? "complete" : ""}`}><span className="step-number">{i < currentStep || rental.state === "CLOSED" ? <Check size={15}/> : `0${i + 1}`}</span><span>{s.name}</span>{i < rentalStages.length - 1 && <span className="step-connector"/>}</div>)}</section>
          <div className="work-grid"><div className="task-column">
            <section className="equipment-strip"><span className="equipment-icon"><Aperture size={28}/></span><div><strong>Aperture S1 <span>Camera kit</span></strong><p>{rental.assetId}<span>·</span>Locker {rental.slotId}</p></div><span className={`status-badge ${rental.returnedAt ? "success" : ""}`}>{rental.returnedAt ? <Check size={13}/> : <Clock3 size={13}/>}{rental.returnedAt ? "Accepted by locker" : "Awaiting equipment"}</span></section>

            {stage === "RETURN_SIMULATION" && <section className="task-card return-card"><div className="task-card-heading"><div><p className="eyebrow">STEP 01 / DEVICE RETURN</p><h2>First, put the equipment back.</h2><p>Select each item below to place it in locker B-07.</p></div><span className="quiet-icon"><Box size={24}/></span></div><div className="locker-visual"><div className="locker-label"><span><span className="locker-led"/>RETURN STATION</span><strong>B-07</strong></div><div className={`locker-interior ${rental.physical.body ? "has-camera" : ""}`}>{rental.physical.body ? <CameraIllustration compact returned/> : <div className="empty-locker"><ScanLine size={52} strokeWidth={1}/><span>Waiting for equipment</span></div>}<div className="accessory-slots"><span className={rental.physical.cap ? "placed" : ""}><span className="lens-cap">S1</span><small>Lens cap</small></span><span className={rental.physical.battery ? "placed" : ""}><Battery size={30}/><small>Battery</small></span></div></div><div className="locker-bottom"><span>Detected {physicalCount} of 3 items</span><span>SIMULATED HARDWARE</span></div></div><div className="place-controls">{[{ key: "body", action: "PLACE_BODY", label: "Camera body", icon: <Aperture size={23}/> }, { key: "cap", action: "PLACE_CAP", label: "Lens cap", icon: <span className="cap-icon"/> }, { key: "battery", action: "PLACE_BATTERY", label: "Battery", icon: <Battery size={23}/> }].map(item => { const placed = rental.physical[item.key as "body" | "cap" | "battery"]; return <button key={item.key} className={`place-button ${placed ? "placed" : ""}`} disabled={disabled || placed} onClick={() => mutate("device-events", { action: item.action, eventId: uid() })}>{item.icon}<strong>{item.label}</strong><span>{placed ? <><Check size={13}/>In locker</> : <><Plus size={13}/>Place in locker</>}</span></button>; })}</div><div className="card-footer"><span><Info size={15}/>Closing the locker creates the return record.</span><button className="button button-primary" onClick={() => mutate("device-events", { action: "LOCK_DOOR", eventId: uid() })} disabled={disabled || physicalCount !== 3}><LockKeyhole size={16}/>Close locker and continue</button></div></section>}

            {stage === "SELF_PROOF" && <section className="task-card">
              <div className="task-card-heading">
                <div><p className="eyebrow">STEP 02 / SELF DECLARATION</p><h2>Please prove what just happened.</h2><p>We have the equipment. Now we need you to tell us that again.</p></div>
                <ClipboardCheck className="quiet-icon" size={26}/>
              </div>
              <div className="fact-banner">
                <CheckCircle2 size={22}/>
                <div>
                  <strong>Locker record: Returned</strong>
                  <p>{rental.assetId} received at {timeOnly(rental.returnedAt)} in {rental.slotId}. {physicalCount} items accounted for.</p>
                  {extendedPlan && <div className="proof-timestamp">
                    <code>{utcReturnedAt}</code>
                    <button type="button" className="icon-button" aria-label="Copy return time" onClick={() => copyValue(utcReturnedAt)}><Copy size={16}/></button>
                  </div>}
                </div>
              </div>
              <form onSubmit={submitProof} className="proof-form">
                <div className="form-heading"><h3>Return declaration</h3><span>All {proofFields.length} fields required</span></div>
                {proofFields.map(f => <div className="form-field" key={f.key}>
                  <label htmlFor={f.key}>{f.label}<span>*</span></label>
                  <div className="input-with-suffix">
                    <input id={f.key} value={draft[f.key]} placeholder={f.placeholder} autoComplete="off" spellCheck={false}
                      inputMode={f.key === "enteredManifestCount" ? "numeric" : "text"} disabled={busy === "proof"}
                      onChange={e => { dirtyRef.current = true; setDraft(d => ({ ...d, [f.key]: e.target.value })); }}
                      aria-invalid={Boolean(fieldErrors[f.key])} aria-describedby={fieldErrors[f.key] ? `${f.key}-error` : undefined}/>
                    {f.key !== "enteredReturnedAt" && <span>{f.key === "enteredReturnState" ? "Returned" : "Manual entry"}</span>}
                  </div>
                  {fieldErrors[f.key] && <p id={`${f.key}-error`} className="field-error">{fieldErrors[f.key]}</p>}
                  {(rental.invalidAttempts[f.key] || 0) >= 2 && <button type="button" className="field-helper" onClick={() => {
                    dirtyRef.current = true;
                    setDraft(d => ({ ...d, [f.key]: f.value }));
                  }}>Use known value: {f.value}</button>}
                </div>)}
                <div className="system-note"><Info size={16}/><span>Enter it again so we can confirm you know you returned the equipment.</span></div>
                <div className="card-footer">
                  <button type="button" className="text-button" onClick={() => openPanel("help")}>Don’t you already know this?</button>
                  <button type="submit" className="button button-primary" disabled={disabled}>{busy === "proof" && <RefreshCw size={16} className="spin"/>}Submit return declaration</button>
                </div>
              </form>
            </section>}

            {(stage === "CHECKS" || stage === "REWORK") && <section className="task-card">
              <div className="task-card-heading">
                <div>
                  <p className="eyebrow">STEP 03 / {stage === "REWORK" ? "RECONFIRMATION" : "SEQUENTIAL REVIEW"}</p>
                  <h2>{stage === "REWORK" ? "One small side effect." : "We need to check one more thing."}</h2>
                  <p>{stage === "REWORK" ? `Your return reason changed. Use the updated record to reconfirm ${reworkChecks.length} items in order.` : "When this check passes, we will reveal the next requirement."}</p>
                </div>
                <Layers3 className="quiet-icon" size={26}/>
              </div>
              {stage === "REWORK" && <div className="rework-banner">
                <RefreshCw size={21}/>
                <div>
                  <strong>Items to reconfirm: {reworkChecks.filter(c => c.status === "EXPIRED").length}</strong>
                  <p>The equipment was returned at {timeOnly(rental.returnedAt)}.</p>
                </div>
                <span>Rework 1 / 1</span>
              </div>}
              <div className="check-trail">{rental.checks.filter(c => c.visible).map(c => <div key={c.id}
                className={done(c) ? "done" : c.status === "EXPIRED" ? "expired" : "pending"}>
                <span>{done(c) ? <Check size={14}/> : c.status === "EXPIRED" ? <RefreshCw size={14}/> : <Clock3 size={14}/>}</span>
                <strong>{c.label}</strong>
                <small>{c.status === "WAIVED_BY_USER" ? "Used existing evidence" : done(c) ? "Confirmed" : c.status === "EXPIRED" ? "Reconfirmation required" : "Awaiting confirmation"}</small>
              </div>)}</div>
              {currentCheck && currentPrompt ? <div className="active-check">
                <span className="check-overline">{currentCheck.status === "EXPIRED" ? "Please reconfirm" : "Current review requirement"}</span>
                <span className="large-check-icon">{currentPrompt.icon}</span>
                <h3>{currentCheck.id === "REASON_SPECIFIC" && rental.proof.reasonCode !== "GENERAL_END" ? "Check your saved return reason." : currentPrompt.title}</h3>
                <p>{currentCheck.id === "REASON_SPECIFIC" && rental.proof.reasonCode !== "GENERAL_END" ? usesFiling ? "We saved your choice. Confirm it to request closure." : "We saved your choice. Confirm it to proceed to final review." : currentPrompt.description}</p>
                {currentCheck.id === "REASON_SPECIFIC" ? <div className="reason-field">
                  <label htmlFor="return-reason">Return reason</label>
                  <select id="return-reason" value={reason} onChange={e => { dirtyRef.current = true; setReason(e.target.value); }}>
                    {Object.entries(reasons).map(([value, label]) => <option key={value} value={value} disabled={extendedPlan && value === "GENERAL_END"}>{label}</option>)}
                  </select>
                  <button className="button button-primary" onClick={submitReason} disabled={disabled}>Confirm return reason</button>
                </div> : <button className="button button-primary" onClick={() => mutate("checks", { action: "CONFIRM", checkId: currentCheck.id })} disabled={disabled}>
                  <Check size={17}/>{currentCheck.status === "EXPIRED" ? "Reconfirm " : "Confirm "}{currentPrompt.confirmation}
                </button>}
              </div> : allChecksDone ? <div className="checks-complete">
                <span className="success-orbit"><Check size={35}/></span><h3>At last, all confirmations confirmed.</h3><p>You can now see the final settlement amount.</p>
                <button className="button button-primary" disabled={disabled} onClick={() => mutate("close-preview")}>View final settlement</button>
              </div> : <div className="next-check">
                <div className="waiting-stamp"><ClipboardCheck size={30}/></div>
                <h3>{rental.checks.some(done) ? "This check passed." : "We received your return declaration."}</h3>
                <p>{hiddenCheck ? "You may now request the next review requirement." : "Syncing review status. Please wait."}</p>
                <button className="button button-primary" disabled={disabled || !hiddenCheck} onClick={() => mutate("checks", { action: "REVEAL" })}>Get next requirement</button>
              </div>}
              <div className="task-note"><Info size={16}/><span>We show the requirements one at a time to avoid overwhelming you.</span></div>
            </section>}

            {stage === "FILING" && <section className="task-card filing-card">
              <div className="task-card-heading">
                <div>
                  <p className="eyebrow">STEP 04 / END APPLICATION</p>
                  <h2 ref={filingHeading} tabIndex={-1}>Rental closure request</h2>
                  {filingStatus === "NOT_STARTED" && <p>The return review passed. Retrieve the Device Acceptance Slip number from Return Records before filing.</p>}
                </div>
                <FileText className="quiet-icon" size={26}/>
              </div>
              <div className="filing-status">
                <span className="status-badge success"><Check size={14}/>{reviewStep ? "Documents approved" : "Documents complete"}</span>
                <span className={`status-badge ${reviewStep ? "review-stamp" : filingReturned ? "filing-status-returned" : ""}`}>{reviewStep ? "Sent back for rework" : filingStatus === "APPROVED" ? "Request approved" : filingReturned ? "Awaiting additional document" : "Awaiting submission"}</span>
              </div>
              {filingStatus === "APPROVED" ? <div className="checks-complete">
                <h3>Closure request approved</h3><p>You can now review the final amount.</p>
                <button className="button button-primary" onClick={() => mutate("close-preview")} disabled={disabled}>View final settlement</button>
              </div> : reviewStep ? <>
                <div className="filing-review-notice" role={reviewStep.action === "RECALL" ? "alert" : "status"}>
                  <div className="filing-review-notice-header">
                    <div><span className="filing-review-stamp">Rework required</span><h3>{reviewStep.title}</h3></div>
                    <span className="filing-review-round">Round 2</span>
                  </div>
                  <p>{reviewStep.instruction}</p>
                  <div className="filing-review-tally">
                    <div><span>Original documents 2/2</span><strong>Verified · Sealed</strong></div>
                    <div><strong>Rework progress {filingReviewSteps.indexOf(reviewStep)}/4</strong></div>
                  </div>
                  <ol className="filing-review-steps" aria-label="Rework steps">
                    {filingReviewSteps.map((step, index) => {
                      const finished = index < filingReviewSteps.indexOf(reviewStep);
                      return <li key={step.status} className={finished ? "complete" : ""} aria-current={reviewStep === step ? "step" : undefined}>
                        <span>{finished ? <Check size={13} aria-label="Complete"/> : index + 1}</span>{step.name}
                      </li>;
                    })}
                  </ol>
                </div>
                <button type="button" className="button button-secondary filing-archive-button" onClick={() => goToArchive(archivePageHash)} disabled={disabled}><FileText size={17}/>Open {archiveTitle}</button>
                <form className="filing-form" onSubmit={submitFilingReview}>
                  <div className="form-field">
                    <label htmlFor="filing-review-code">{reviewStep.codeLabel}</label>
                    <input id="filing-review-code" value={reviewCode} required maxLength={48} autoComplete="off" spellCheck={false}
                      disabled={busy === "filing-review"} aria-invalid={filingError?.field === "code"}
                      aria-describedby={filingError?.field === "code" ? "filing-review-error" : undefined}
                      onChange={event => { setReviewCode(event.target.value); setFilingError(null); }}/>
                    {filingError?.field === "code" && <p id="filing-review-error" className="field-error" role="alert">{filingError.message}</p>}
                  </div>
                  {reviewStep.action === "ACKNOWLEDGE" && <label className="checkbox-row filing-review-check" htmlFor="filing-review-ack">
                    <input id="filing-review-ack" type="checkbox" checked={filingAcknowledged} onChange={event => setFilingAcknowledged(event.target.checked)}/>
                    <span>I acknowledge that this filing was accepted and the rental remains open.</span>
                  </label>}
                  <div className="card-footer">
                    <button type="button" className="text-button" onClick={() => openPanel("help")}>Use the shorter process</button>
                    <button type="submit" className="button button-primary" disabled={disabled || reviewStep.action === "ACKNOWLEDGE" && !filingAcknowledged}>
                      {busy === "filing-review" && <RefreshCw size={16} className="spin"/>}{reviewStep.submit}
                    </button>
                  </div>
                </form>
              </> : <>
                {filingReturned && <div className="filing-return-notice" role="alert">
                  <Info size={20}/><div><strong>Returned for correction: Completeness Certificate missing</strong><p>The review desk issued the certificate. Retrieve its number from Return Records and submit it here.</p></div>
                </div>}
                <button type="button" className="button button-secondary filing-archive-button" onClick={() => goToArchive(archivePageHash)} disabled={disabled}><FileText size={17}/>Open Return Records</button>
                <form className="filing-form" onSubmit={submitFiling}>
                  <div className="form-field">
                    <label htmlFor="filing-receipt-code">Device Acceptance Slip number</label>
                    <input id="filing-receipt-code" value={filingDraft.receiptCode} required maxLength={48}
                      autoComplete="off" spellCheck={false} readOnly={filingReturned} disabled={busy === "filing"}
                      aria-invalid={filingError?.field === "receiptCode"} aria-describedby={filingError?.field === "receiptCode" ? "filing-code-error" : undefined}
                      onChange={event => { const receiptCode = event.target.value; setFilingDraft(draft => ({ ...draft, receiptCode })); setFilingError(null); }}/>
                    {filingError?.field === "receiptCode" && <p id="filing-code-error" className="field-error" role="alert">{filingError.message}</p>}
                  </div>
                  {filingReturned && <div className="form-field">
                    <label htmlFor="filing-certificate-code">Completeness Certificate number</label>
                    <input id="filing-certificate-code" value={filingDraft.certificateCode} required maxLength={48}
                      autoComplete="off" spellCheck={false} disabled={busy === "filing"}
                      aria-invalid={filingError?.field === "certificateCode"} aria-describedby={filingError?.field === "certificateCode" ? "filing-certificate-error" : undefined}
                      onChange={event => { const certificateCode = event.target.value; setFilingDraft(draft => ({ ...draft, certificateCode })); setFilingError(null); }}/>
                    {filingError?.field === "certificateCode" && <p id="filing-certificate-error" className="field-error" role="alert">{filingError.message}</p>}
                  </div>}
                  <div className="card-footer">
                    <button type="button" className="text-button" onClick={() => openPanel("help")}>Use the shorter process</button>
                    <button type="submit" className="button button-primary" disabled={disabled}>{busy === "filing" && <RefreshCw size={16} className="spin"/>}{filingReturned ? "Resubmit closure request" : "Submit closure request"}</button>
                  </div>
                </form>
              </>}
            </section>}

            {stage === "FINALIZATION" && rental.finalization && <CompletionCheckpoint
              key={`${rental.id}:${rental.finalization.status}:${rental.finalization.enteredAt}:${challengeId ?? ""}`}
              record={rental.finalization}
              elapsed={Math.max(0, rental.serverNow - (rental.finalization.enteredAt ?? rental.serverNow))}
              disabled={disabled}
              busy={busy === "finalization"}
              mode={rental.reasonReviewMode}
              oldReason={reasons[rental.proof.reasonCode] || rental.proof.reasonCode}
              slotId={rental.slotId}
              count={physicalCount}
              fieldError={finalizationError}
              remainingSeconds={remainingSeconds}
              rollbackMessage={rollbackMessage}
              challenge={activeChallenge?.image ?? null}
              challengeError={activeChallenge?.error ?? null}
              run={runFinalization}
              onRetryChallenge={() => setChallengeRetry(retry => retry + 1)}
              onPreview={() => void mutate("close-preview")}
              onHelp={() => void openPanel("help")}
            />}

            {stage === "FINAL_REVIEW" && rental.closeSnapshot && <section className="task-card review-card"><div className="task-card-heading"><div><p className="eyebrow">STEP {rentalStages.length.toString().padStart(2, "0")} / FINAL REVIEW</p><h2>This time, you really can close it.</h2><p>The equipment return and review are complete. Check the final amount.</p></div><FileCheck2 className="quiet-icon" size={26}/></div><div className="final-amount"><span>Final settlement</span><strong><small>DEMO</small>{amount(rental.closeSnapshot.finalBaseMinor)}</strong><p>Simulated units · No real charge</p></div><div className="review-breakdown"><div><span>Equipment use fee</span><strong>{amount(rental.closeSnapshot.finalBaseMinor)}</strong></div><div><span>Estimated approval wait</span><strong>{amount(waitDisplay)}</strong></div><div className="green"><span>Full reversal of waiting estimate</span><strong>−{amount(waitDisplay)}</strong></div></div><div className="fact-banner subtle"><ShieldCheck size={22}/><div><strong>Waiting longer will not change the final amount</strong><p>Return time: {datetime(rental.returnedAt)}<br/>Return reason: {reasons[rental.closeSnapshot.reasonCode] || rental.closeSnapshot.reasonCode}</p></div></div><label className="checkbox-row"><input type="checkbox" checked={reviewAccepted} onChange={e => setReviewAccepted(e.target.checked)}/><span>I reviewed this information and confirm that I want to close this simulated rental.</span></label><button className="button button-primary full" onClick={closeRental} disabled={disabled || !reviewAccepted}><LockKeyhole size={17}/>Close rental and generate receipt</button><p className="review-footnote">This is your final confirmation. When it succeeds, the rental stays closed.</p></section>}

            {stage === "CLOSING" && <section className="task-card closing-card"><div className="closing-symbol"><RefreshCw size={38} className={busy === "close" ? "spin" : ""}/></div><p className="eyebrow">CONFIRMING RESULT</p><h2>Checking whether the rental closed.</h2><p>We saved this operation. Refreshing the page will continue checking the same submission.</p><div className="system-note"><ShieldCheck size={18}/><span>A missing result does not mean the submission failed. Retrying uses the original operation ID and will not charge twice.</span></div><button className="button button-primary" onClick={retryClose} disabled={Boolean(busy)}>{busy === "close" ? "Confirming" : "Check and retry this submission"}</button><span className="pending-id">Operation ID · {String(pending?.payload.operationId).slice(0, 12)}</span></section>}

            {(stage === "RECEIPT" || rental.state === "CLOSED") && !pending && <section className="task-card receipt-card" id="receipt-print"><div className="receipt-topline"><span className="receipt-brand">STILL RENTING.</span><span>RETURN RECEIPT</span></div><div className="receipt-success"><span className="success-orbit"><Check size={35}/></span><p className="eyebrow">RENTAL CLOSED</p><h2>You are finally done renting.</h2><p>The equipment came back a while ago. The system has now agreed.</p></div>{receipt ? <><div className="receipt-total"><span>Final simulated settlement</span><strong>{amount(receipt.finalMinor)}<small>DEMO</small></strong><span className="status-badge success"><Check size={13}/>Closed · Amount fixed</span></div><div className="receipt-lines"><div><span>Equipment use fee</span><strong>{amount(receipt.baseMinor)}</strong></div><div><span>Waiting estimate</span><strong>{amount(receipt.waitMinor)}</strong></div><div className="green"><span>Waiting estimate reversal</span><strong>−{amount(Math.abs(receipt.reversalMinor))}</strong></div></div><div className="receipt-meta"><div><span>Equipment / locker</span><strong>{receipt.assetId} / {receipt.slotId}</strong></div><div><span>Locker accepted equipment</span><strong>{datetime(receipt.returnedAt)}</strong></div><div><span>System closed rental</span><strong>{datetime(receipt.closedAt)}</strong></div><div><span>Return reason</span><strong>{reasons[receipt.reasonCode] || receipt.reasonCode}</strong></div></div><div className="receipt-stats"><div><strong>{receipt.stats?.extraTasks ?? rental.budget.allocated}</strong><span>extra tasks</span></div><div><strong>{receipt.stats?.reworkCount ?? Number(rental.theatricalReworkUsed)}</strong><span>rework rounds</span></div><div><strong>{receipt.stats?.elapsedAfterReturnSeconds ?? 0}<small>s</small></strong><span>waiting since return</span></div></div><div className="receipt-quote">Thank you for your patience.<br/><strong>It is this system’s most important resource.</strong></div><div className="receipt-verification"><div><span>Receipt verification code</span><code>{receipt.verificationCode}</code></div><button className="icon-button" aria-label="Copy receipt verification code" onClick={() => copyValue(receipt.verificationCode)}><Copy size={17}/></button></div>{verification && <p className="verified-note"><ShieldCheck size={15}/>Verified by server · {verification.receiptId || receipt.id}</p>}<div className="receipt-actions no-print"><button className="button button-primary" onClick={downloadReceipt}><Download size={17}/>Download receipt JSON</button><button className="button button-secondary" onClick={() => window.print()}><Printer size={17}/>Print receipt</button><button className="text-button" onClick={verifyReceipt}>Verify receipt</button></div><p className="receipt-footnote">This is a simulated rental receipt. The app server stores the record. No payment took place.</p></> : <p className="loading-text">Loading the saved receipt…</p>}</section>}
          </div>

          <aside className="context-column"><section className="billing-card"><div className="billing-heading"><span>Charges</span><span className={rental.state === "CLOSED" ? "bill-state closed" : "bill-state"}>{rental.state === "CLOSED" ? "Settled" : offline ? "Updates paused" : rental.returnedAt ? "Under review" : "On rent"}</span></div><p className="bill-caption">{rental.state === "CLOSED" ? "Final simulated settlement" : "Current estimated total"}</p><div className="bill-total">{amount(rental.state === "CLOSED" ? rental.billing.finalMinor : baseDisplay + waitDisplay)}<small>DEMO</small></div><div className="billing-meter"><span className={rental.state === "CLOSED" || offline ? "" : "live"}/>{rental.state === "CLOSED" ? "Meter stopped" : offline ? "Last confirmed amount" : "Server clock"}</div><div className="bill-separator"/><div className="bill-line"><span>Equipment use</span><strong>{amount(baseDisplay)}</strong></div><div className={`bill-line ${rental.returnedAt && rental.state !== "CLOSED" ? "wait-line" : ""}`}><span>Approval wait</span><strong>{amount(waitDisplay)}</strong></div>{rental.state === "CLOSED" && <div className="bill-line green"><span>Waiting reversal</span><strong>−{amount(Math.abs(rental.billing.reversalMinor))}</strong></div>}<div className="bill-explanation"><Info size={15}/><p>{rental.state === "CLOSED" ? "We completed settlement and reversed the full waiting estimate." : rental.returnedAt ? "We have the equipment. Approval is still in progress. We reverse all estimated waiting charges at settlement." : "The demo rental began 10 minutes ago. Rate 0.01 per second in simulated units. No real charge."}</p></div></section>
          <section className="evidence-card"><div className="small-card-heading"><ScanLine size={18}/><h3>Equipment record</h3><span className="mini-tag">Known facts</span></div><ul><li className={rental.physical.identityMatch ? "is-done" : ""}><span>{rental.physical.identityMatch ? <Check size={13}/> : <span/>}</span>Equipment ID matches</li><li className={rental.physical.manifestMatch ? "is-done" : ""}><span>{rental.physical.manifestMatch ? <Check size={13}/> : <span/>}</span>All accessories present</li><li className={rental.physical.doorLocked ? "is-done" : ""}><span>{rental.physical.doorLocked ? <Check size={13}/> : <span/>}</span>Return locker locked</li></ul>{rental.returnedAt && <p className="evidence-time">Recorded at {timeOnly(rental.returnedAt)}<br/><span>Rework cannot change this fact.</span></p>}</section>
          {rental.state !== "CLOSED" && <button className="support-card" onClick={() => openPanel("support")} disabled={Boolean(pending)}><span className="support-avatar"><Headphones size={22}/></span><span><strong>Need a little help?</strong><small>Our specialists are always ready to transfer you.</small></span></button>}
          <p className="simulation-note"><ShieldCheck size={14}/><span>The equipment and charges on this page are simulated.<br/> Every demo has a way to finish.</span></p></aside></div>
        </>}
        <footer className="page-footer"><span>STILL RENTING © 2026</span><span>Return experience experiment · No real charges</span>{portable ? <span>Local edition · Source included</span> : <a href="/downloads/STILL_RENTING_Delivery_v1.5.1.zip" download>Download runnable source</a>}</footer>
      </main>
    </div>

    {panel === "support" && rental && <Modal title="Your return is very important to us" eyebrow="SUPPORT DESK" close={closePanel}>
      <div className="support-role">
        <span className="support-avatar"><Headphones size={23}/></span>
        <div><strong>{roleNames[rental.support.role] || rental.support.role}</strong><span>Transfers {rental.support.handoffs} / {handoffLimit} · Local rules</span></div>
        <span className={`status-badge ${offline ? "" : "success"}`}>{offline ? "Disconnected" : "Online"}</span>
      </div>
      <div className="chat-window">
        {!rental.support.messages.length && <div className="chat-message assistant">
          <span>{roleNames[rental.support.role]}</span><p>Hello. Equipment Intake can look up your locker record.</p><small>Local rules template</small>
        </div>}
        {rental.support.messages.map(m => <div key={m.id} className={`chat-message ${m.role}`}>
          <span>{m.role === "user" ? "You" : roleNames[m.speaker] || "Specialist"}</span><p>{m.text}</p>
          {m.role !== "user" && <small>Local rules template · {timeOnly(m.at)}</small>}
        </div>)}
        <div ref={chatEnd}/>
      </div>
      <form className="chat-composer" onSubmit={sendMessage}>
        <label className="sr-only" htmlFor="support-message">Message a specialist</label>
        <textarea id="support-message" value={chat} onChange={e => setChat(e.target.value)} maxLength={500} placeholder="Example: I returned it. Why is the meter still running?" rows={2}/>
        <button className="icon-button" type="submit" disabled={!chat.trim() || disabled} aria-label="Send message"><Send size={20}/></button>
      </form>
      <div className="support-actions">
        {transferRole && rental.state === "RETURN_PENDING" && <button className="button button-secondary full" onClick={() => mutate("support", { action: "TRANSFER" })} disabled={disabled}>
          {rental.support.handoffs > 1 ? "Transfer back to " : "Transfer to "}{roleNames[transferRole]}
        </button>}
        {canMergeSupport && <button className="button button-primary full" onClick={() => openPanel("help")} disabled={Boolean(pending)}>Review existing evidence together</button>}
        <button className="text-button" onClick={closePanel}>Back to current return step</button>
      </div>
    </Modal>}

    {panel === "help" && rental && <Modal title="Use the evidence we already have." eyebrow="ASSISTED REVIEW" close={closePanel}><div className="modal-body"><div className="help-intro"><span className="help-orbit"><CircleHelp size={30}/></span><p>Use the facts already recorded by the locker to skip repeated proof.<br/>Choose the actual reason and confirm that we can use the existing evidence.</p></div><div className="help-facts"><div><span>Return equipment</span><strong>{rental.assetId}</strong></div><div><span>Locker evidence</span><strong>{rental.returnedAt ? "All three items recorded. Return time fixed." : "Equipment has not been placed in the locker."}</strong></div><div><span>Locker</span><strong>{rental.slotId}</strong></div></div>{pending ? <div className="system-note"><Info size={18}/><span>We are checking the closure result. You can check or retry the original submission. Return evidence is locked while we check.</span></div> : !rental.returnedAt ? <><div className="system-note"><Info size={18}/><span>First place the camera, lens cap and battery in the locker, then close the door. Assisted review requires a completed equipment return.</span></div><button className="button button-primary full" onClick={closePanel}>Back to equipment return</button></> : rental.state === "CLOSED" ? <div className="fact-banner"><CheckCircle2 size={22}/><div><strong>This rental is already closed</strong><p>You can download or verify your saved receipt.</p></div></div> : <><div className="form-field"><label htmlFor="help-reason">Choose your return reason</label><select id="help-reason" value={helpReason} onChange={e => setHelpReason(e.target.value)}><option value="">Select a reason</option><option value="SHOOT_COMPLETE">Shoot complete</option><option value="PLAN_CANCELLED">Plans cancelled</option></select></div><label className="checkbox-row"><input type="checkbox" checked={helpAccepted} onChange={e => setHelpAccepted(e.target.checked)}/><span>I agree to use the locker evidence and waive the remaining repeated proof.</span></label><button className="button button-primary full" disabled={disabled || !helpReason || !helpAccepted} onClick={useHelp}>Use existing evidence and continue</button><p className="helper-foot">We record your choice as consent to use existing evidence. Your manual confirmations remain as recorded.</p></>}</div></Modal>}

    {panel === "observer" && rental && <Modal title="The system knew all along." eyebrow="OBSERVER MODE / READ ONLY" wide close={closePanel}>
      <div className="modal-body observer-body">
        <div className="observer-metrics">
          <div><span>Rental status</span><strong>{rental.state}</strong></div>
          <div><span>Extra tasks assigned</span><strong>{rental.budget.allocated}<small> / {rental.budget.limit}</small></strong></div>
          <div><span>Proof / rental version</span><strong>{rental.proofVersion}<small> / </small>{rental.stateVersion}</strong></div>
          <div><span>Deliberate rework</span><strong>{rental.theatricalReworkUsed ? "1 / 1" : "0 / 1"}</strong></div>
        </div>
        <h3>Machine facts and manual proof</h3>
        <div className="observer-fact-grid">
          <div><span className="mini-tag">Machine</span><strong>{rental.returnedAt ? "Equipment received" : "Awaiting equipment"}</strong><p>Equipment: {rental.assetId}<br/>Locker: {rental.slotId}<br/>Returned: {datetime(rental.returnedAt)}</p></div>
          <div>
            <span className="mini-tag">Process</span>
            <strong>{rental.state === "CLOSED" ? "Finally agreed to close" : rental.selfProofComplete ? "Declaration received. Review continues." : "Still needs another declaration"}</strong>
            <p>Support transfers: {rental.support.handoffs} / {handoffLimit}<br/>Tasks shown: {rental.budget.presented}<br/>Assisted review: {rental.helpUsed ? "Used" : "Unused"}<br/>Step: {rental.stage}</p>
          </div>
        </div>
        <h3>Event log</h3>
        <div className="event-list">{[...(rental.events || [])].reverse().slice(0, 24).map(e => <div key={e.id}><span>{timeOnly(e.at)}</span><strong>{e.type}</strong><small>{typeof e.detail === "string" ? e.detail : JSON.stringify(e.detail)}</small></div>)}</div>
        {observer && <details className="observer-raw"><summary>View full observation data from the server</summary><pre>{JSON.stringify(observer, null, 2)}</pre></details>}
        <div className="system-note"><Eye size={16}/><span>This panel is read-only. The server state machine controls task assignment, approval and settlement.</span></div>
      </div>
    </Modal>}

    {panel === "history" && <Modal title="Every eventual ending." eyebrow="RENTAL HISTORY" wide close={closePanel}><div className="modal-body"><p className="history-intro">Records belong to this browser workspace. Starting a new demo keeps previous receipts.</p>{history.length ? <div className="history-list">{history.map((item: any) => <button key={item.id || item.rentalId} onClick={async () => { setReceipt(null); setVerification(null); dirtyRef.current = false; try { await refresh(item.id || item.rentalId, true); setPanel(null); } catch (e: any) { setError(e.message); } }} disabled={Boolean(pending)}><span className="history-icon"><FileText size={23}/></span><span><strong>{item.assetName || "Aperture S1"}</strong><small>{item.assetId || "CAM-042"} · {datetime(item.startedAt || item.createdAt)}</small></span><span className={`status-badge ${item.state === "CLOSED" ? "success" : ""}`}>{item.state === "CLOSED" ? "Closed" : "In progress"}</span></button>)}</div> : <div className="empty-state"><History size={36}/><h3>No rentals yet</h3><p>Start a demo and the record will appear here.</p><button className="button button-primary" onClick={createDemo} disabled={Boolean(busy)}>Start demo</button></div>}</div></Modal>}

    {panel === "about" && <Modal title="Returned. Still renting." eyebrow="ABOUT / REVERSE UX EXPERIMENT" close={closePanel}><div className="modal-body about-body"><p className="about-lead">STILL RENTING turns a simple return into a small dispute over who gets to declare it finished.</p><div className="about-mechanisms"><div><ClipboardCheck size={21}/><span><strong>Repeated proof</strong>Enter the facts the system already knows.</span></div><div><Layers3 size={21}/><span><strong>One requirement at a time</strong>The next check appears as soon as the previous one passes.</span></div><div><RefreshCw size={21}/><span><strong>Cascading rework</strong>Change one reason and repeat the manual confirmations you just finished.</span></div><div><Headphones size={21}/><span><strong>Polite transfers</strong>Specialists share one record and still send you back to the previous desk.</span></div></div><div className="system-note"><ShieldCheck size={20}/><span>You can finish this simulation. All charges are demo estimates. We fully reverse the waiting estimate at settlement. Choose “Need help?” at any step to shorten the process.</span></div><button className="button button-primary full" onClick={closePanel}>Continue the demo</button></div></Modal>}
    {toast && <div className="toast" role="status"><CheckCircle2 size={18}/>{toast}</div>}
  </div>;
}
