import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "STILL RENTING · Return Experience",
  description: "The equipment is back. The process is still open. A reverse UX experiment with simulated charges and verifiable receipts.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
