# STILL RENTING engineering handoff

## Current snapshot

This is the English edition of the V1.5 reverse-UX prototype. It contains the runnable portable frontend and the complete source for a local Node.js/SQLite runtime and a hosted Worker/D1 runtime. The original application baseline was commit `f612ce6f46dd7068bad130af390d934183ba9e77`. Local demo rules have since evolved through six plan versions. The original hosted project is a separate deployment.

The server accepts the simulated physical return, fixes the return time, and deliberately asks the user to prove a sequence of facts already known. The current path adds four support transfers as an optional detour, a returned application, four reprocessing steps, and the three timed gates. See the [product requirements](docs/requirements/PRODUCT_REQUIREMENTS.md) for the current flow.

## Source entry points

| Path | Responsibility |
| --- | --- |
| `app/page.tsx` | React pages, workflow, recovery, and overlays |
| `app/globals.css` | Visual presentation, keyboard focus, print and responsive styles |
| `app/layout.tsx` | Hosted React metadata and document shell |
| `server/domain.mjs` | Workflow rules, charge calculations, budgets, closure snapshots, and receipts |
| `server/service.mjs` | HTTP contract, authorization, idempotency, storage admission, and CAS retries |
| `server/repository.mjs` | Common D1/SQLite persistence queries and the local schema |
| `server/reason-review.mjs` | Local review and optional OpenAI provider |
| `server/human-check.mjs` | Server-side CAPTCHA issuance and image rendering |
| `portable/server.mjs` | Loopback HTTP server, default port 8787 |
| `portable/sqlite.mjs` | Node SQLite adapter with D1-compatible operations |
| `portable/entry.tsx`, `portable/vite.config.ts` | Portable frontend entry and configuration |
| `portable/public/` | Generated static assets included in the runnable build |
| `worker/index.ts` | Hosted API entry and platform authentication |
| `db/schema.ts`, `drizzle/` | Hosted schema and migrations |
| `tests/acceptance.test.mjs`, `tests/bounds.test.mjs` | Domain and capacity cases |
| `tests/runtime-smoke.mjs` | Portable startup, real HTTP, and restart recovery probe |

The browser stores pointers for recovery. The server owns physical facts, task allocation, billing, and receipts. One conditional update commits the rental aggregate and receipt indexes atomically. [Read the architecture](docs/ARCHITECTURE.md) for details.

## Development commands

For portable work:

```sh
npm ci
npm test
npm run typecheck
npm run portable:build
node portable/server.mjs --open
```

The database is `data/still-renting.sqlite`. Rebuild and refresh after a frontend change. Restart the server after modifying backend files. Use the prebuilt frontend when no source work is needed.

For hot reload with a fresh local D1 database:

```sh
npm ci
npm run build
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_stiff_shatterstar.sql
npm run dev
```

The default development port is 5173. The D1 environment stores data under `.wrangler/state`. Apply the first migration only to a fresh database. Existing databases should apply their pending migrations. A clean directory selects the portable execution profile by default. Leave machine-specific `.sites-runtime` data outside the package.

`npm start` starts the built production Worker and requires its platform identity configuration. Use the portable service for a standalone demo.

## Guarantees to preserve

- Return evidence fixes `returnedAt` and the base amount. Later rework and timers affect the workflow, while the receipt reverses all waiting estimates.
- Authorization and shape validation precede replay. A successful replay precedes a stale business-version check.
- Preserve an unknown closure operation and requery or retry the same operation ID and payload. A new operation cannot generate another receipt.
- Stale rental or receipt responses must leave the selected rental and its pending operation intact. A new final snapshot invalidates the old confirmation.
- Support uses local templates. Local rules review reasons by default, with optional configured OpenAI review. Keep the actual review source visible.
- A CAPTCHA timeout or failure returns to its preceding bar. A help waiver still requires physical return evidence, a reason, and an explicit close.

## Capabilities and remaining work

The application simulates the cabinet and all billing. It exports JSON receipts and supports browser printing. A dedicated signed-PDF service, automatic 24-hour retention, production billing, physical cabinet integration, and organizer-specific poster production are outside the implemented scope.

The earlier engineering backlog includes explicit record-list loading/error states, a unified monotonic clock for network freshness, and automated regression coverage for stale responses. Confirm the current source before taking any backlog item. See [next steps](docs/NEXT_STEPS.md).

Use the [implementation contract](docs/IMPLEMENTATION_CONTRACT.md) for API details and [acceptance checks](docs/ACCEPTANCE.md) for release verification. The [optimization log](docs/OPTIMIZATION_LOG.md) records prior results. Test again after changing code, and use a fresh extracted copy for the portable HTTP smoke probe.
