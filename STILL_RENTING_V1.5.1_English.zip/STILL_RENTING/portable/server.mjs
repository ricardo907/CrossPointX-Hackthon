#!/usr/bin/env node
/** Local delivery server. Node 24+, no npm install, API key, or internet required. */
import { createServer } from "node:http";
import { readFile, mkdir, stat } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";

const major = Number(process.versions.node.split(".")[0]);
if (major < 24) { console.error("STILL RENTING requires Node.js 24 or newer. Install Node.js 24, then run Start_Windows.bat again."); process.exit(1); }

const root = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(root, "public");
const dataDir = path.join(root, "..", "data");
const port = Number(process.env.STILL_RENTING_PORT || 8787);
if (!Number.isInteger(port) || port < 1024 || port > 65535) { console.error("STILL_RENTING_PORT must be 1024–65535."); process.exit(1); }
try { await stat(path.join(publicDir, "index.html")); }
catch { console.error("Missing portable/public/index.html. Use the delivery ZIP or run npm run portable:build in the source checkout."); process.exit(1); }
await mkdir(dataDir, { recursive: true });
const { createDatabase } = await import("./sqlite.mjs");
const { handleApi } = await import("../server/service.mjs");
const { configuredReasonReviewMode, createReasonReviewer } = await import("../server/reason-review.mjs");
const db = createDatabase(path.join(dataDir, "still-renting.sqlite"));
const reasonReview = createReasonReviewer(process.env);
const reasonReviewMode = configuredReasonReviewMode(process.env);
const localOrigin = `http://127.0.0.1:${port}`;
const hostnames = new Set([`127.0.0.1:${port}`, `localhost:${port}`]);
const mime = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".svg": "image/svg+xml", ".png": "image/png", ".json": "application/json; charset=utf-8", ".zip": "application/zip", ".md": "text/plain; charset=utf-8" };

const server = createServer(async (req, res) => {
  const finish = (status, body, type = "text/plain; charset=utf-8") => {
    res.writeHead(status, { "Content-Type": type, "X-Content-Type-Options": "nosniff", "Cache-Control": "no-store" });
    res.end(body);
  };
  try {
    if (!hostnames.has(req.headers.host)) return finish(403, "Unsupported host. Open the loopback URL printed in the terminal.");
    const url = new URL(req.url || "/", localOrigin);
    if (url.pathname.startsWith("/api/")) {
      if (req.headers.origin && ![localOrigin, `http://localhost:${port}`].includes(req.headers.origin)) return finish(403, "Cross-origin requests are disabled.");
      const chunks = []; let bytes = 0;
      for await (const chunk of req) {
        bytes += chunk.length;
        if (bytes > 16384) return finish(413, JSON.stringify({ ok: false, error: { code: "PAYLOAD_TOO_LARGE", message: "The request is too large.", retryable: false } }), "application/json");
        chunks.push(chunk);
      }
      const body = Buffer.concat(chunks);
      const request = new Request(url, { method: req.method, headers: req.headers, ...(body.length ? { body } : {}) });
      const result = await handleApi(request, { db, owner: "local", reasonReview, reasonReviewMode });
      res.writeHead(result.status, { ...Object.fromEntries(result.headers), "X-Content-Type-Options": "nosniff" });
      return res.end(Buffer.from(await result.arrayBuffer()));
    }
    if (!["GET", "HEAD"].includes(req.method)) return finish(405, "Method not allowed");
    const relative = decodeURIComponent(url.pathname).replace(/^\/+/, "");
    let target = path.resolve(publicDir, relative || "index.html");
    if (!target.startsWith(publicDir + path.sep) || relative.includes("\0") || relative.includes("\\")) return finish(400, "Invalid path");
    let data;
    try { data = await readFile(target); }
    catch {
      if (path.extname(relative)) return finish(404, "File not found");
      target = path.join(publicDir, "index.html"); data = await readFile(target);
    }
    res.writeHead(200, { "Content-Type": mime[path.extname(target)] || "application/octet-stream", "X-Content-Type-Options": "nosniff", "Cache-Control": "no-cache" });
    res.end(req.method === "HEAD" ? undefined : data);
  } catch (error) {
    console.error("Request failed:", error?.message || "Unknown error");
    if (!res.headersSent) finish(500, JSON.stringify({ ok: false, error: { code: "SERVICE_UNAVAILABLE", message: "The service is temporarily unavailable. Retry the same operation.", retryable: true } }), "application/json");
    else res.end();
  }
});
server.on("error", error => { console.error(error.code === "EADDRINUSE" ? `Port ${port} is already used. Close the old window, or set STILL_RENTING_PORT=8788.` : error.message); db.close(); process.exit(1); });
server.listen(port, "127.0.0.1", () => {
  console.log(`\n  STILL RENTING — local delivery 1.5.1\n  Open ${localOrigin}\n  All money and hardware are simulated.\n  Data: ${path.join(dataDir, "still-renting.sqlite")}\n  Press Ctrl+C to stop.\n`);
  if (process.argv.includes("--open")) {
    const command = process.platform === "win32" ? ["cmd", ["/c", "start", "", localOrigin]] : process.platform === "darwin" ? ["open", [localOrigin]] : ["xdg-open", [localOrigin]];
    try { const child = spawn(command[0], command[1], { detached: true, stdio: "ignore" }); child.on("error", () => {}); child.unref(); } catch {}
  }
});
function shutdown() { server.close(() => { db.close(); process.exit(0); }); }
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
