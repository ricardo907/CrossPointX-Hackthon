"""Build a clean, offline-runnable ZIP; never copy runtime databases or secrets."""
from pathlib import Path
import json
import zipfile
import hashlib

root = Path(__file__).resolve().parent.parent
output = root / "public" / "downloads" / "STILL_RENTING_Delivery_v1.5.1.zip"
output.parent.mkdir(parents=True, exist_ok=True)

folders = ["app", "server", "portable", "docs", "tests", "db", "drizzle", "worker", "lib", "scripts", "vendor"]
files = ["README.md", "Start_Windows.bat", "Start_Mac.command", "Start_Linux.sh", "package.json", "package-lock.json", "tsconfig.json", "vite.config.ts", "drizzle.config.ts", "postcss.config.mjs", "next.config.ts", "cloudflare-env.d.ts", ".gitignore", "public/favicon.svg"]
historical_exports = set(['STILL_RENTING_PRD_revision_v1.1.docx', 'STILL_RENTING_PRD_text.txt', 'STILL_RENTING_PRD_v1.0.docx', 'STILL_RENTING_PRD_v1.0.pdf', 'handoff-build-check.json', 'handoff-runtime-smoke.json', 'handoff-tests.tap', 'runtime-smoke.json', 'test-results.tap'])
selected = []
for folder in folders:
    selected.extend(p for p in (root / folder).rglob("*") if p.is_file())
selected.extend(root / name for name in files if (root / name).is_file())
for required in ["portable/public/index.html", "server/service.mjs", "docs/VALIDATION_REPORT.md"]:
    if not (root / required).is_file():
        raise SystemExit(f"Missing required delivery file: {required}")

with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(set(selected)):
        relative = p.relative_to(root)
        if relative.parts[0] == 'docs' and p.name in historical_exports:
            continue
        if any(part in {"__pycache__", "node_modules", ".git", ".sites-runtime", ".wrangler", "data"} for part in relative.parts):
            continue
        if p.name.startswith(".env") or p.name.startswith(".dev.vars") or p.suffix in {".sqlite", ".sqlite-wal", ".sqlite-shm", ".pem", ".pyc"}:
            continue
        z.write(p, "STILL_RENTING/" + relative.as_posix())
    # The copy is independent of the owner's hosted Site identity.
    z.writestr("STILL_RENTING/.openai/hosting.json", json.dumps({"d1": "DB", "r2": None}, indent=2) + "\n")

with zipfile.ZipFile(output) as z:
    invalid = z.testzip()
    if invalid:
        raise SystemExit(f"Corrupt ZIP member: {invalid}")
print(json.dumps({"file": str(output), "bytes": output.stat().st_size, "sha256": hashlib.sha256(output.read_bytes()).hexdigest(), "files": len(zipfile.ZipFile(output).namelist())}))
