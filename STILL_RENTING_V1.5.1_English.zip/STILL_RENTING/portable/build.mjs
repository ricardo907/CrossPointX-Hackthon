import { build } from "vite";
import { copyFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";

await build({ configFile: fileURLToPath(new URL("./vite.config.ts", import.meta.url)) });
await copyFile(new URL("../public/favicon.svg", import.meta.url), new URL("./public/favicon.svg", import.meta.url));
console.log("Portable frontend built. Run node portable/server.mjs to start.");
