/** The same D1 interface used by the hosted Worker, backed by local SQLite. */
import { DatabaseSync } from "node:sqlite";
import { SCHEMA_SQL } from "../server/repository.mjs";

export function createDatabase(filename = ":memory:") {
  const connection = new DatabaseSync(filename);
  connection.exec("PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;");
  if (filename !== ":memory:") connection.exec("PRAGMA journal_mode=WAL;");
  connection.exec(SCHEMA_SQL);
  function prepared(sql, values = []) {
    return {
      bind(...args) { return prepared(sql, args); },
      async first(column) {
        const row = connection.prepare(sql).get(...values);
        if (!row) return null;
        return column ? row[column] : { ...row };
      },
      async all() {
        return { success: true, results: connection.prepare(sql).all(...values).map(row => ({ ...row })), meta: {} };
      },
      async run() {
        const result = connection.prepare(sql).run(...values);
        return { success: true, meta: { changes: Number(result.changes), last_row_id: Number(result.lastInsertRowid) } };
      },
    };
  }
  return {
    prepare: sql => prepared(sql),
    async exec(sql) { connection.exec(sql); return { count: 0, duration: 0 }; },
    async batch(statements) {
      connection.exec("BEGIN IMMEDIATE");
      try {
        const results = [];
        for (const statement of statements) results.push(await statement.run());
        connection.exec("COMMIT");
        return results;
      } catch (error) { connection.exec("ROLLBACK"); throw error; }
    },
    close() { connection.close(); },
  };
}
