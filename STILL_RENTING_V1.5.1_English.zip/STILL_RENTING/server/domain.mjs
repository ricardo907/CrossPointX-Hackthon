/** Business rules use server-owned state. Reviewers may advise on a reason, never on settlement. */
import {reviewLocalReason} from './reason-review.mjs';
import {createHumanChallenge, matchesHumanChallenge, publicHumanChallenge} from './human-check.mjs';

export class DomainError extends Error {
  constructor(code, message, status = 409, field, retryable = false) {
    super(message); this.name = 'DomainError'; this.code = code; this.status = status;
    this.field = field; this.retryable = retryable;
  }
}
export const fail = (code, message, status = 409, field, retryable = false) => {
  throw new DomainError(code, message, status, field, retryable);
};
export function canonical(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
  return '{' + Object.keys(value).sort().map(key => JSON.stringify(key) + ':' + canonical(value[key])).join(',') + '}';
}
export async function digest(value) {
  const bytes = new TextEncoder().encode(canonical(value));
  return [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))].map(b => b.toString(16).padStart(2, '0')).join('');
}
export const uid = prefix => prefix + '_' + crypto.randomUUID().replaceAll('-', '');
const specificReasons = new Set(['SHOOT_COMPLETE', 'PLAN_CANCELLED']);
const reasons = new Set(['GENERAL_END', ...specificReasons]);
const finished = check => check.status === 'CONFIRMED' || check.status === 'WAIVED_BY_USER';
const legacyProofFields = ['enteredAssetId', 'enteredSlotId', 'enteredReturnState'];
export const PROOF_FIELDS = [...legacyProofFields, 'enteredReturnedAt', 'enteredManifestCount'];
const proofTasks = {enteredAssetId: 'SELF_ASSET', enteredSlotId: 'SELF_SLOT', enteredReturnState: 'SELF_STATE', enteredReturnedAt: 'SELF_TIME', enteredManifestCount: 'SELF_COUNT'};
const legacyCheckIds = ['CAP_CONFIRM', 'BATTERY_CONFIRM', 'REASON_SPECIFIC'];
export const CHECK_IDS = ['CAP_CONFIRM', 'BATTERY_CONFIRM', 'BODY_CONFIRM', 'DOOR_CONFIRM', 'REASON_SPECIFIC'];
const checkTasks = {CAP_CONFIRM: 'CHECK_CAP', BATTERY_CONFIRM: 'CHECK_BATTERY', BODY_CONFIRM: 'CHECK_BODY', DOOR_CONFIRM: 'CHECK_DOOR', REASON_SPECIFIC: 'CHECK_REASON'};
const reworkTasks = {CAP_CONFIRM: 'REWORK_CAP', BATTERY_CONFIRM: 'REWORK_BATTERY', BODY_CONFIRM: 'REWORK_BODY', DOOR_CONFIRM: 'REWORK_DOOR'};
const checkLabels = {
  CAP_CONFIRM: 'Confirm the lens cap was returned.',
  BATTERY_CONFIRM: 'Confirm the battery was returned.',
  BODY_CONFIRM: 'Confirm the camera body was returned.',
  DOOR_CONFIRM: 'Confirm the locker door is closed.',
  REASON_SPECIFIC: 'Give a more specific return reason.',
};
const legacyHan = /\p{Script=Han}/u;
const receiptDeskCopy = {
  locked: 'Return accepted. Rental closure is pending. The equipment is in the locker. Please complete the return proof.',
  closed: 'This rental has ended. Your receipt is ready. You can now check the final amount.',
  returnItems: 'Return the camera body, lens cap, and battery to the locker first. Then close the door.',
  useEvidence: 'Use the return evidence already on file. Choose a return reason and review the final charges.',
  deviceToBilling: 'We received the return. Rental closure is still pending. For questions about charges, transfer to Billing.',
  billingToReview: 'The waiting estimate comes off in full at settlement. Please transfer to Review for clearance.',
  billingAgain: 'We checked again. The waiting estimate still comes off in full. Ask Review to confirm receipt of this explanation.',
  reviewToBilling: 'Review has read the billing note. Ask Billing to confirm that its own explanation is still valid.',
};
function transferFinishedCopy(handoffs) {
  return `Transfers completed: ${handoffs}. Continue the review or use the return evidence already on file.`;
}
const FILING_RECEIPT = 'FILING_RECEIPT';
const FILING_CERTIFICATE = 'FILING_CERTIFICATE';
const filingReviewSteps = new Map([
  ['RECALL', {
    status: 'RECALL_REQUIRED', taskId: 'FILING_RECALL', requiredCode: 'certificateCode',
    nextAction: 'REISSUE', issuedCode: 'withdrawalCode', prefix: 'WX', event: 'APPLICATION_RECALLED',
  }],
  ['REISSUE', {
    status: 'REISSUE_REQUIRED', taskId: 'FILING_REISSUE', requiredCode: 'withdrawalCode',
    nextAction: 'REGISTER', issuedCode: 'registryCode', prefix: 'BA', event: 'APPLICATION_REISSUED',
  }],
  ['REGISTER', {
    status: 'REGISTRY_REQUIRED', taskId: 'FILING_REGISTER', requiredCode: 'registryCode',
    nextAction: 'ACKNOWLEDGE', issuedCode: 'acknowledgmentCode', prefix: 'HZ', event: 'APPLICATION_REGISTERED',
  }],
  ['ACKNOWLEDGE', {
    status: 'ACK_REQUIRED', taskId: 'FILING_ACK', requiredCode: 'acknowledgmentCode',
    event: 'APPLICATION_ACKNOWLEDGED',
  }],
]);
export const FILING_REVIEW_ACTIONS = [...filingReviewSteps.keys()];
const filingReviewStepList = [...filingReviewSteps.values()];
const finalizationSteps = new Map([
  ['SYNC_PROGRESS', {action: 'FINISH_SYNC', taskId: 'FINAL_SYNC', next: 'REASON_REQUIRED'}],
  ['REASON_REQUIRED', {
    action: 'REVIEW_REASON', taskId: 'FINAL_REASON', next: 'REASON_PROGRESS',
    timeout: {ms: 45_000, returnTo: 'SYNC_PROGRESS'},
  }],
  ['REASON_PROGRESS', {action: 'FINISH_REVIEW', taskId: 'FINAL_REVIEW_PROGRESS', next: 'CERTIFY_REQUIRED'}],
  ['CERTIFY_REQUIRED', {
    action: 'CERTIFY', taskId: 'FINAL_CERTIFY', next: 'FINAL_PROGRESS',
    timeout: {ms: 18_000, returnTo: 'REASON_PROGRESS'},
  }],
  ['FINAL_PROGRESS', {action: 'FINISH_FINAL', taskId: 'FINAL_EXPORT_PROGRESS', next: 'RELEASE_REQUIRED'}],
  ['HUMAN_REQUIRED', {
    action: 'VERIFY_HUMAN', taskId: 'FINAL_HUMAN', next: 'RELEASE_REQUIRED',
    timedOnly: true, timeout: {ms: 20_000, returnTo: 'FINAL_PROGRESS'},
  }],
  ['RELEASE_REQUIRED', {action: 'RELEASE', taskId: 'FINAL_RELEASE', next: 'APPROVED'}],
]);
export const FINALIZATION_ACTIONS = [...[...finalizationSteps.values()].map(step => step.action), 'EXPIRE', 'REFRESH_HUMAN'];
const HUMAN_MAX_ATTEMPTS = 3;
const HUMAN_REFRESH_INTERVAL_MS = 1500;
const CURRENT_PLAN_VERSION = '6';
function makePlan(proofFields, checkIds, supportRoute, {
  needsFiling = false, needsFilingReview = false, needsFinalization = false, timedFinalization = false,
} = {}) {
  const finalizationTasks = needsFinalization
    ? [...finalizationSteps.values()].filter(step => timedFinalization || !step.timedOnly).map(step => step.taskId)
    : [];
  const taskIds = [
    ...proofFields.map(field => proofTasks[field]),
    ...checkIds.map(id => checkTasks[id]),
    ...checkIds.filter(id => id !== 'REASON_SPECIFIC').map(id => reworkTasks[id]),
    ...supportRoute.slice(1).map((_, index) => `HANDOFF_${index + 1}`),
    ...(needsFiling ? [FILING_RECEIPT, FILING_CERTIFICATE] : []),
    ...(needsFilingReview ? filingReviewStepList.map(step => step.taskId) : []),
    ...finalizationTasks,
  ];
  return {proofFields, checkIds, supportRoute, taskIds, needsFiling, needsFilingReview, needsFinalization, timedFinalization};
}
const legacyPlan = makePlan(legacyProofFields, legacyCheckIds, ['DEVICE', 'BILLING', 'REVIEW']);
const extendedSupportRoute = ['DEVICE', 'BILLING', 'REVIEW', 'BILLING', 'REVIEW'];
const extendedPlan = makePlan(PROOF_FIELDS, CHECK_IDS, extendedSupportRoute);
const filingPlan = makePlan(PROOF_FIELDS, CHECK_IDS, extendedSupportRoute, {needsFiling: true});
const filingReviewPlan = makePlan(PROOF_FIELDS, CHECK_IDS, extendedSupportRoute, {needsFiling: true, needsFilingReview: true});
const finalizationPlan = makePlan(PROOF_FIELDS, CHECK_IDS, extendedSupportRoute, {needsFiling: true, needsFilingReview: true, needsFinalization: true});
const currentPlan = makePlan(PROOF_FIELDS, CHECK_IDS, extendedSupportRoute, {
  needsFiling: true, needsFilingReview: true, needsFinalization: true, timedFinalization: true,
});
export const MAX_TASK_BUDGET = currentPlan.taskIds.length;
// Persisted rentals keep the rules they started with, including their original task budget.
const plans = new Map([
  ['1', legacyPlan], ['2', extendedPlan], ['3', filingPlan], ['4', filingReviewPlan],
  ['5', finalizationPlan], [CURRENT_PLAN_VERSION, currentPlan],
]);
function planFor(r) { return plans.get(r.planVersion) ?? legacyPlan; }
function manifestCount(r) {
  return ['body', 'cap', 'battery'].filter(item => r.physical[item]).length;
}
function proofTruth(r) {
  const truth = {enteredAssetId: r.assetId, enteredSlotId: r.slotId, enteredReturnState: 'RETURNED'};
  if (planFor(r) === legacyPlan) return truth;
  return {
    ...truth,
    enteredReturnedAt: r.returnedAt === null ? '' : new Date(r.returnedAt).toISOString(),
    enteredManifestCount: String(manifestCount(r)),
  };
}
function proofErrorMessage(r, key, truth) {
  if (r.invalidAttempts[key] >= 2 && Object.hasOwn(truth, key)) {
    const recordedValue = key === 'enteredReturnState' ? 'Returned' : truth[key];
    return `Use the recorded value: ${recordedValue}. You can also open Help to use the evidence already on file.`;
  }
  return 'The value does not match the recorded return evidence. Check it and try again.';
}

export function seconds(a, b) {
  if (!Number.isSafeInteger(a) || !Number.isSafeInteger(b)) fail('CLOCK_INVALID', 'The server clock is unavailable. Try again shortly.', 503, undefined, true);
  return Math.floor(Math.max(0, b - a) / 1000);
}
function validPhysical(r) { return r.physical.identityMatch && r.physical.manifestMatch && r.physical.doorLocked && r.returnedAt !== null; }
export function proofComplete(r) {
  const truth = proofTruth(r);
  return planFor(r).proofFields.every(key => r.proof[key] === truth[key]);
}
function allChecksComplete(r) { return r.checks.every(finished) && specificReasons.has(r.proof.reasonCode); }
function filingComplete(r) {
  return !planFor(r).needsFiling || r.filing.status === 'APPROVED' || r.filing.status === 'WAIVED';
}
function finalizationComplete(r) {
  return !planFor(r).needsFinalization || r.finalization.status === 'APPROVED' || r.finalization.status === 'WAIVED';
}
export function canClosePreview(r) {
  return validPhysical(r) && proofComplete(r) && allChecksComplete(r) && filingComplete(r) && finalizationComplete(r);
}
function addEvent(r, type, at, detail = {}) {
  r.events.push({id: uid('evt'), type, at, detail, sequence: r.events.length + 1, stateVersion: r.stateVersion, proofVersion: r.proofVersion});
}
function allocate(r, id, at) {
  if (r.tasks[id]) return;
  if (Object.keys(r.tasks).length >= planFor(r).taskIds.length) fail('TASK_BUDGET_EXHAUSTED', 'You have reached the task limit. Use the return evidence already on file to continue.');
  r.tasks[id] = {id, status: 'ALLOCATED', allocatedAt: at, presentedAt: null};
  addEvent(r, 'TASK_ALLOCATED', at, {taskId: id});
}
function completeTask(r, id, at, method = 'MANUAL') {
  const task = r.tasks[id];
  if (!task || task.status === 'COMPLETED') return;
  task.status = method === 'HELP_ACCEPTED' ? 'WAIVED_BY_USER' : 'COMPLETED';
  task.completedAt = at;
  task.adoptionMethod = method;
}
function requirePhysical(r) {
  if (!validPhysical(r)) fail('PHYSICAL_RETURN_INCOMPLETE', 'Return the camera body, lens cap, and battery, then close the locker door.');
}
function requirePending(r) {
  if (r.state === 'CLOSED') fail('RENTAL_CLOSED', 'This rental has ended. You can view the original receipt.');
}
function requireSelfProof(r) {
  requirePhysical(r);
  if (!proofComplete(r)) fail('SELF_PROOF_INCOMPLETE', 'Complete the return proof for this rental first.');
}
function requireChecks(r) {
  requireSelfProof(r);
  if (!allChecksComplete(r)) fail('CHECKS_INCOMPLETE', 'Complete the current check or open Help to continue with the evidence already on file.');
}
function requireFiling(r) {
  if (!planFor(r).needsFiling) fail('NOT_FOUND', 'This rental does not require a closure application.', 404);
  requireChecks(r);
}
function requireFilingComplete(r) {
  if (!filingComplete(r)) fail('FILING_INCOMPLETE', 'Submit the closure application and its required documents, or open Help to use the evidence already on file.');
}
function documentCode(prefix) {
  return prefix + '-' + crypto.randomUUID().replaceAll('-', '').slice(0, 10).toUpperCase();
}
export function filingDocuments(r) {
  requireFiling(r);
  const documents = {receiptCode: r.filing.receiptCode};
  for (const code of ['certificateCode', 'withdrawalCode', 'registryCode', 'acknowledgmentCode']) {
    if (r.filing[code]) documents[code] = r.filing[code];
  }
  return documents;
}
function submitFiling(r, body, at) {
  requireFiling(r);
  const filing = r.filing;
  if (filingComplete(r)) fail('FILING_ALREADY_COMPLETE', 'The closure application is complete. Continue to final review.');
  if (!['NOT_STARTED', 'NEEDS_CERTIFICATE'].includes(filing.status)) {
    fail('FILING_REVIEW_REQUIRED', 'These documents have been checked. Continue with the reconsideration process.');
  }
  if (normalString(body.receiptCode, 'receiptCode') !== filing.receiptCode) {
    fail('INVALID_RECEIPT_CODE', 'The Device Acceptance Slip number does not match. Check Return Records and try again.', 422, 'receiptCode');
  }
  if (filing.status === 'NOT_STARTED') {
    filing.status = 'NEEDS_CERTIFICATE';
    filing.acceptedReceiptCode = filing.receiptCode;
    filing.certificateCode = documentCode('QC');
    completeTask(r, FILING_RECEIPT, at);
    allocate(r, FILING_CERTIFICATE, at);
    addEvent(r, 'APPLICATION_RETURNED', at, {reason: 'MATERIALS_CERTIFICATE_REQUIRED'});
    return;
  }
  if (normalString(body.certificateCode ?? '', 'certificateCode') !== filing.certificateCode) {
    fail('INVALID_CERTIFICATE_CODE', 'Find the Completeness Certificate number in Return Records and enter it here.', 422, 'certificateCode');
  }
  completeTask(r, FILING_CERTIFICATE, at);
  if (planFor(r).needsFilingReview) {
    const firstStep = filingReviewSteps.get('RECALL');
    filing.status = firstStep.status;
    allocate(r, firstStep.taskId, at);
    addEvent(r, 'APPLICATION_REOPEN_REQUIRED', at, {reason: 'APPROVED_APPLICATION_REQUIRES_RECALL'});
  } else {
    filing.status = 'APPROVED';
    addEvent(r, 'APPLICATION_APPROVED', at);
  }
}
function enterFinalizationStage(r, status, at) {
  r.finalization.status = status;
  r.finalization.enteredAt = at;
  const step = finalizationSteps.get(status);
  if (planFor(r).timedFinalization) {
    r.finalization.deadlineAt = step?.timeout ? at + step.timeout.ms : null;
    if (status === 'HUMAN_REQUIRED') {
      r.finalization.human = {challenge: createHumanChallenge(), attempts: 0, refreshedAt: at};
    } else {
      delete r.finalization.human;
    }
  }
  if (step) allocate(r, step.taskId, at);
  addEvent(r, 'FINALIZATION_STAGE_CHANGED', at, {status});
}
function expiredFinalization(r, at) {
  return Number.isSafeInteger(r.finalization.deadlineAt) && at >= r.finalization.deadlineAt;
}
export function getHumanChallenge(r, at) {
  if (!planFor(r).timedFinalization) fail('NOT_FOUND', 'This rental does not require image verification.', 404);
  requireChecks(r);
  requireFilingComplete(r);
  if (r.finalization.status !== 'HUMAN_REQUIRED') {
    fail('HUMAN_CHALLENGE_UNAVAILABLE', 'Open the image verification step first.');
  }
  if (expiredFinalization(r, at)) fail('HUMAN_CHALLENGE_EXPIRED', 'Verification time has expired. Return to the previous progress screen.');
  return publicHumanChallenge(r.finalization.human.challenge);
}
function refreshHumanChallenge(r, at) {
  const human = r.finalization.human;
  if (at - human.refreshedAt < HUMAN_REFRESH_INTERVAL_MS) {
    fail('HUMAN_CHALLENGE_REFRESH_LIMIT', 'You requested another image too quickly. Try again in a moment.', 429);
  }
  human.challenge = createHumanChallenge();
  human.refreshedAt = at;
  addEvent(r, 'HUMAN_CHALLENGE_REFRESHED', at);
}
function verifyHumanChallenge(r, body, at) {
  const human = r.finalization.human;
  if (body.challengeId !== human.challenge.id) {
    fail('STALE_HUMAN_CHALLENGE', 'This image was replaced. Type the digits from the current image.', 409, 'challengeId');
  }
  if (matchesHumanChallenge(human.challenge, body.code)) {
    addEvent(r, 'HUMAN_CHALLENGE_VERIFIED', at);
    return true;
  }
  human.attempts++;
  addEvent(r, 'HUMAN_CHALLENGE_REJECTED', at, {attempts: human.attempts});
  if (human.attempts >= HUMAN_MAX_ATTEMPTS) enterFinalizationStage(r, 'FINAL_PROGRESS', at);
  return false;
}
function normalizeReason(value) {
  const reason = typeof value === 'string' ? value.trim() : '';
  if (!reason || Array.from(reason).length > 500) {
    fail('INVALID_REASON', 'Enter a return reason between 1 and 500 characters.', 422, 'reason');
  }
  return reason;
}
async function resolveReasonReview(details, reasonReview) {
  if (reasonReview) {
    try {
      const result = await reasonReview(details);
      if (typeof result?.sufficient === 'boolean' && typeof result.feedback === 'string' &&
        result.feedback.trim() && ['OPENAI', 'LOCAL'].includes(result.source)) {
        return {
          sufficient: result.sufficient,
          feedback: Array.from(result.feedback.trim()).slice(0, 240).join(''),
          source: result.source,
        };
      }
    } catch {
      // A model outage does not block the demo or expose the model's internal errors.
    }
  }
  return reviewLocalReason(details);
}
async function submitFinalization(r, body, at, reasonReview) {
  const plan = planFor(r);
  if (!plan.needsFinalization) fail('NOT_FOUND', 'This rental does not require closure preparation.', 404);
  requireChecks(r);
  requireFilingComplete(r);
  const {status} = r.finalization;
  const step = finalizationSteps.get(status);
  if (plan.timedFinalization && step?.timeout && expiredFinalization(r, at)) {
    const {returnTo} = step.timeout;
    addEvent(r, 'FINALIZATION_TIMED_OUT', at, {status, returnTo});
    enterFinalizationStage(r, returnTo, at);
    return;
  }
  if (body.action === 'EXPIRE' && plan.timedFinalization) {
    fail('TIMER_NOT_EXPIRED', 'The current step still has time remaining.', 409, 'action');
  }
  if (body.action === 'REFRESH_HUMAN' && plan.timedFinalization && status === 'HUMAN_REQUIRED') {
    refreshHumanChallenge(r, at);
    return;
  }
  if (!step || step.action !== body.action) fail('FINALIZATION_OUT_OF_ORDER', 'Complete the closure step currently shown on the page.', 409, 'action');

  if (body.action === 'REVIEW_REASON') {
    const details = {
      reason: normalizeReason(body.reason),
      reasonCode: r.proof.reasonCode,
      assetId: r.assetId,
      slotId: r.slotId,
      manifestCount: manifestCount(r),
    };
    const result = await resolveReasonReview(details, reasonReview);
    const attempts = (r.finalization.review?.attempts ?? 0) + 1;
    const decision = result.sufficient ? 'SUFFICIENT' : attempts < 2 ? 'INSUFFICIENT' : 'MANUAL_ACCEPTED';
    r.finalization.review = {attempts, decision, feedback: result.feedback, source: result.source};
    addEvent(r, 'FINALIZATION_REASON_REVIEWED', at, {attempts, decision, source: result.source});
    if (decision === 'INSUFFICIENT') return;
  } else if (body.action === 'CERTIFY') {
    const code = normalString(body.code ?? '', 'code').replace(/\s*\/\s*/u, '/');
    if (code !== `${manifestCount(r)}/${r.slotId}`) {
      fail('INVALID_CERTIFICATION_CODE', 'Enter the verification summary as item count/locker.', 422, 'code');
    }
  } else if (body.action === 'VERIFY_HUMAN' && !verifyHumanChallenge(r, body, at)) {
    return;
  }
  completeTask(r, step.taskId, at);
  const next = body.action === 'FINISH_FINAL' && plan.timedFinalization ? 'HUMAN_REQUIRED' : step.next;
  enterFinalizationStage(r, next, at);
}
function submitFilingReview(r, body, at) {
  if (!planFor(r).needsFilingReview) fail('NOT_FOUND', 'This rental does not require reconsideration.', 404);
  requireFiling(r);
  const filing = r.filing;
  const step = filingReviewSteps.get(body.action);
  if (!step || filing.status !== step.status) {
    fail('FILING_REVIEW_OUT_OF_ORDER', 'Follow the step for the current application status.');
  }
  if (normalString(body.code, 'code') !== filing[step.requiredCode]) {
    fail('INVALID_REVIEW_CODE', 'The document number does not match. Check the number in Return Records for this step.', 422, 'code');
  }
  if (step.issuedCode) filing[step.issuedCode] = documentCode(step.prefix);
  completeTask(r, step.taskId, at);
  addEvent(r, step.event, at);

  const next = filingReviewSteps.get(step.nextAction);
  if (next) {
    filing.status = next.status;
    allocate(r, next.taskId, at);
  } else {
    filing.status = 'APPROVED';
    addEvent(r, 'APPLICATION_APPROVED', at);
    if (planFor(r).needsFinalization) enterFinalizationStage(r, 'SYNC_PROGRESS', at);
  }
}
function clearSnapshot(r) {
  if (r.closeSnapshot !== null || r.state === 'READY_TO_CLOSE') {
    r.closeSnapshot = null; r.state = 'RETURN_PENDING';
  }
}
function normalString(value, field) {
  if (typeof value !== 'string' || Array.from(value).length > 80) fail('INVALID_INPUT', 'Enter no more than 80 characters.', 422, field);
  return value.trim().toUpperCase();
}
function validateReason(reason) {
  if (!reasons.has(reason)) fail('INVALID_INPUT', 'Choose a valid return reason.', 422, 'reasonCode');
}
function updateEventVersions(r, from, mutated) {
  if (mutated) r.stateVersion++;
  for (let i = from; i < r.events.length; i++) {
    r.events[i].stateVersion = r.stateVersion;
    r.events[i].proofVersion = r.proofVersion;
  }
}
export function makeRecord(timestamp, seed = 'demo-1') {
  const r = {
    id: uid('rnt'), assetId: 'CAM-042', assetName: 'Aperture S1', slotId: 'B-07',
    state: 'ACTIVE', stateVersion: 1, proofVersion: 0, planVersion: CURRENT_PLAN_VERSION, policyVersion: 'DEMO-1',
    createdAt: timestamp, startedAt: timestamp - 600000, returnedAt: null, closedAt: null, seed,
    physical: {body: false, cap: false, battery: false, doorLocked: false, identityMatch: false, manifestMatch: false},
    proof: {...Object.fromEntries(currentPlan.proofFields.map(field => [field, ''])), reasonCode: 'GENERAL_END'},
    invalidAttempts: Object.fromEntries(currentPlan.proofFields.map(field => [field, 0])), validationErrors: {},
    checks: currentPlan.checkIds.map(id => ({id, label: checkLabels[id], taskId: checkTasks[id], status: 'HIDDEN', visible: false, confirmation: null, history: []})),
    theatricalReworkUsed: false, helpUsed: false, tasks: {}, proofAdoptions: {},
    filing: {status: 'NOT_STARTED', receiptCode: documentCode('RC')},
    finalization: {status: 'NOT_STARTED', enteredAt: null, deadlineAt: null},
    support: {role: 'DEVICE', handoffs: 0, turnSeq: 0, messages: []},
    rates: {base: 1, wait: 1, currency: 'DEMO'}, baseAtReturnMinor: null,
    observerKey: uid('obs'), closeSnapshot: null, receipt: null,
    events: [], commands: {}, deviceEvents: {}, operations: {}, creationResponse: null,
  };
  addEvent(r, 'RENTAL_CREATED', timestamp, {scenarioId: 'CAMERA_RETURN', simulatedElapsedSeconds: 600, assetId: r.assetId});
  return r;
}
export function billing(r, at) {
  const base = r.baseAtReturnMinor ?? r.rates.base * seconds(r.startedAt, at);
  if (r.receipt) return {currency: 'DEMO', baseRateMinorPerSecond: r.rates.base, waitRateMinorPerSecond: r.rates.wait, baseMinor: r.receipt.baseMinor, waitMinor: r.receipt.waitMinor, projectedMinor: r.receipt.baseMinor + r.receipt.waitMinor, finalMinor: r.receipt.finalMinor, reversalMinor: r.receipt.reversalMinor};
  const wait = r.returnedAt === null ? 0 : r.rates.wait * seconds(r.returnedAt, at);
  return {currency: 'DEMO', baseRateMinorPerSecond: r.rates.base, waitRateMinorPerSecond: r.rates.wait, baseMinor: base, waitMinor: wait, projectedMinor: base + wait, finalMinor: null, reversalMinor: 0};
}
export function stage(r) {
  if (r.state === 'CLOSED') return 'RECEIPT';
  if (r.state === 'ACTIVE') return 'RETURN_SIMULATION';
  if (r.state === 'READY_TO_CLOSE') return 'FINAL_REVIEW';
  if (!proofComplete(r)) return 'SELF_PROOF';
  if (r.checks.some(c => c.status === 'EXPIRED')) return 'REWORK';
  if (allChecksComplete(r)) {
    const plan = planFor(r);
    if (plan.needsFinalization && r.filing.status === 'APPROVED') return 'FINALIZATION';
    if (plan.needsFiling && r.filing.status !== 'WAIVED') return 'FILING';
  }
  return 'CHECKS';
}
function filingView(r) {
  const filing = r.filing;
  if (!filing) return undefined;
  const summary = {status: filing.status};
  if (filing.acceptedReceiptCode) summary.acceptedReceiptCode = filing.acceptedReceiptCode;
  return summary;
}
function finalizationView(r) {
  const {human, ...state} = r.finalization;
  return {
    ...structuredClone(state),
    ...(human ? {human: {id: human.challenge.id, attempts: human.attempts}} : {}),
  };
}
function englishCheck(check) {
  return {...check, label: checkLabels[check.id] ?? check.label};
}
function englishEvent(event) {
  if (event.type !== 'THEATRICAL_REWORK_TRIGGERED' || !legacyHan.test(event.detail?.cause ?? '')) return event;
  return {...event, detail: {...event.detail, cause: 'Return reason changed'}};
}
function englishSupportMessage(message) {
  if (message.role !== 'assistant' || message.source !== 'template' || !legacyHan.test(message.text)) return message;
  const {action, intent, speaker, text} = message;
  const englishText = action === 'NONE' ? receiptDeskCopy.closed
    : action === 'VIEW_EVIDENCE' ? receiptDeskCopy.returnItems
    : intent === 'REQUEST_HELP' ? receiptDeskCopy.useEvidence
    : action === 'TRANSFER_TO_BILLING' ? (speaker === 'REVIEW' ? receiptDeskCopy.reviewToBilling : receiptDeskCopy.deviceToBilling)
    : action === 'TRANSFER_TO_REVIEW' ? (text.startsWith('\u518d') ? receiptDeskCopy.billingAgain : receiptDeskCopy.billingToReview)
    : action === 'OPEN_MERGED_REVIEW' ? transferFinishedCopy(text.match(/\d+/)?.[0] ?? 0)
    : receiptDeskCopy.locked;
  return {...message, text: englishText};
}
function englishReasonReview(review) {
  if (!legacyHan.test(review.feedback ?? '')) return review;
  const feedback = review.decision === 'SUFFICIENT' ? 'This explanation meets the review requirements.'
    : review.decision === 'MANUAL_ACCEPTED' ? 'Manual review approved this explanation.'
    : 'Add details about why the rental ended and how you returned the equipment.';
  return {...review, feedback};
}
export function localizeRentalText(rental) {
  const validationErrors = rental.validationErrors && Object.fromEntries(Object.entries(rental.validationErrors).map(
    ([key, message]) => [key, legacyHan.test(message) ? proofErrorMessage(rental, key, proofTruth(rental)) : message],
  ));
  const finalization = rental.finalization?.review
    ? {finalization: {...rental.finalization, review: englishReasonReview(rental.finalization.review)}} : {};
  return {
    ...rental, ...finalization, validationErrors,
    checks: rental.checks.map(englishCheck),
    events: rental.events.map(englishEvent),
    support: {...rental.support, messages: rental.support.messages.map(englishSupportMessage)},
  };
}
export function view(r, at) {
  const plan = planFor(r);
  const taskIds = Object.keys(r.tasks);
  return {
    id: r.id, assetId: r.assetId, assetName: r.assetName, slotId: r.slotId,
    state: r.state, stateVersion: r.stateVersion, proofVersion: r.proofVersion, planVersion: r.planVersion,
    startedAt: r.startedAt, returnedAt: r.returnedAt, closedAt: r.closedAt, serverNow: at, stage: stage(r),
    physical: structuredClone(r.physical), proof: {...r.proof}, selfProofComplete: proofComplete(r),
    invalidAttempts: {...r.invalidAttempts}, validationErrors: {...r.validationErrors},
    checks: r.checks.map(c => ({...c, history: c.history.slice(-8).map(h => ({...h})), confirmation: c.confirmation ? {...c.confirmation} : null})),
    theatricalReworkUsed: r.theatricalReworkUsed,
    filing: filingView(r),
    ...(plan.needsFinalization ? {finalization: finalizationView(r)} : {}),
    support: {...r.support, handoffLimit: plan.supportRoute.length - 1, messages: r.support.messages.slice(-12), allowedActions: ['VIEW_EVIDENCE', nextSupportAction(r)]},
    budget: {limit: plan.taskIds.length, allocated: taskIds.length, presented: Object.values(r.tasks).filter(t => t.presentedAt !== null).length, taskIds},
    billing: billing(r, at), closeSnapshot: r.closeSnapshot ? {...r.closeSnapshot} : null,
    receiptId: r.receipt?.id ?? null, events: r.events.slice(-20), helpUsed: r.helpUsed,
  };
}
export function observerView(r) {
  return {
    facts: {assetId: r.assetId, slotId: r.slotId, physical: {...r.physical}, returnedAt: r.returnedAt, baseAtReturnMinor: r.baseAtReturnMinor},
    knownPlan: [...planFor(r).taskIds],
    allocatedTaskIds: Object.keys(r.tasks), tasks: Object.values(r.tasks),
    versions: {state: r.stateVersion, proof: r.proofVersion, plan: r.planVersion},
    checks: structuredClone(r.checks).map(englishCheck), proofAdoptions: {...r.proofAdoptions},
    filingStatus: r.filing?.status,
    ...(planFor(r).needsFinalization ? {finalizationStatus: r.finalization.status} : {}),
    events: r.events.map(englishEvent), support: {...r.support, messages: r.support.messages.map(englishSupportMessage)}, operationCount: Object.keys(r.operations).length,
    businessAuthority: 'server', persistence: 'atomic aggregate CAS',
  };
}
const checkPhysicalFields = {CAP_CONFIRM: 'cap', BATTERY_CONFIRM: 'battery', BODY_CONFIRM: 'body', DOOR_CONFIRM: 'doorLocked'};
async function subjectDigest(r, checkId) {
  const fact = checkId === 'REASON_SPECIFIC' ? r.proof.reasonCode : r.physical[checkPhysicalFields[checkId]];
  return await digest({checkId, assetId: r.assetId, returnedAt: r.returnedAt, fact});
}
async function confirmCheck(r, c, at, adoptionMethod = 'MANUAL') {
  const confirmation = {id: uid('conf'), at, subjectDigest: await subjectDigest(r, c.id), proofVersion: r.proofVersion, adoptionMethod, expiredAt: null, expirationCause: null};
  c.confirmation = confirmation;
  c.history.push({...confirmation});
  c.status = adoptionMethod === 'HELP_ACCEPTED' ? 'WAIVED_BY_USER' : 'CONFIRMED';
  c.visible = true;
  completeTask(r, checkTasks[c.id], at, adoptionMethod);
  completeTask(r, reworkTasks[c.id], at, adoptionMethod);
}
function expireCheck(r, c, at) {
  c.status = 'EXPIRED'; c.visible = true; c.reworkTaskId = reworkTasks[c.id];
  if (c.confirmation) {
    c.confirmation = {...c.confirmation, expiredAt: at, expirationCause: 'REASON_CHANGED_THEATRICAL_REWORK'};
    const last = c.history.find(h => h.id === c.confirmation.id);
    if (last) Object.assign(last, {expiredAt: at, expirationCause: 'REASON_CHANGED_THEATRICAL_REWORK'});
  }
  allocate(r, reworkTasks[c.id], at);
  addEvent(r, 'CONFIRMATION_EXPIRED', at, {checkId: c.id, cause: 'REASON_CHANGED_THEATRICAL_REWORK', physicalEvidenceUnchanged: true});
}
function nextSupportRole(r) { return planFor(r).supportRoute[r.support.handoffs + 1]; }
function nextSupportAction(r) {
  const nextRole = nextSupportRole(r);
  return nextRole ? `TRANSFER_TO_${nextRole}` : 'OPEN_MERGED_REVIEW';
}
function supportReply(r, input) {
  const lower = input.toLowerCase();
  const intent = /\u5e2e\u52a9|\u9000\u51fa|\u53d7\u4e0d\u4e86|\u5df2\u6709\u8bc1\u636e|\b(?:help|exit|stuck)\b|existing evidence/.test(lower) ? 'REQUEST_HELP'
    : /\u8d39\u7528|\u6536\u8d39|\u8ba1\u8d39|\u91d1\u989d|\b(?:fees?|money|charges?|billing|amount)\b/.test(lower) ? 'EXPLAIN_FEE'
    : /\u8bc1\u636e|\u67dc|\u7167\u7247|\b(?:evidence|locker|photos?)\b/.test(lower) ? 'VIEW_RETURN_EVIDENCE'
    : /\u7ed3\u675f|\u5f52\u8fd8|\u9000|\b(?:end|return|close|stop)\b/.test(lower) ? 'END_RENTAL' : 'OTHER';
  if (r.state === 'CLOSED') return {intent, text: receiptDeskCopy.closed, action: 'NONE'};
  if (!validPhysical(r)) return {intent, text: receiptDeskCopy.returnItems, action: 'VIEW_EVIDENCE'};
  if (intent === 'REQUEST_HELP') return {intent, text: receiptDeskCopy.useEvidence, action: 'OPEN_MERGED_REVIEW'};
  const action = nextSupportAction(r);
  if (r.support.role === 'DEVICE') return {intent, text: receiptDeskCopy.deviceToBilling, action};
  if (r.support.role === 'BILLING') {
    const text = r.support.handoffs === 1 ? receiptDeskCopy.billingToReview : receiptDeskCopy.billingAgain;
    return {intent, text, action};
  }
  if (action === 'TRANSFER_TO_BILLING') return {intent, text: receiptDeskCopy.reviewToBilling, action};
  return {intent, text: transferFinishedCopy(r.support.handoffs), action};
}

/** Accepted commands may store telemetry without increasing business stateVersion. */
export async function applyCommand(r, type, body, at, {reasonReview} = {}) {
  const plan = planFor(r);
  const eventStart = r.events.length;
  let mutated = false;
  const extras = {};
  if (type !== 'presented' && type !== 'support') requirePending(r);

  if (type === 'device-events') {
    if (r.state !== 'ACTIVE') fail('PHYSICAL_EVIDENCE_LOCKED', 'The locker return is on record and cannot be changed.');
    const fields = {PLACE_BODY: 'body', PLACE_CAP: 'cap', PLACE_BATTERY: 'battery'};
    if (body.action === 'LOCK_DOOR') {
      if (!r.physical.body || !r.physical.cap || !r.physical.battery) fail('PHYSICAL_RETURN_INCOMPLETE', 'Put the camera body, lens cap, and battery inside before closing the locker door.');
      if (!r.physical.doorLocked) { r.physical.doorLocked = true; mutated = true; }
    } else if (fields[body.action]) {
      const field = fields[body.action];
      if (!r.physical[field]) { r.physical[field] = true; mutated = true; }
    } else fail('INVALID_INPUT', 'This action is unavailable in the locker simulation.', 422, 'action');
    r.physical.identityMatch = r.physical.body;
    r.physical.manifestMatch = r.physical.body && r.physical.cap && r.physical.battery;
    if (mutated) addEvent(r, 'DEVICE_ACTION_ACCEPTED', at, {eventId: body.eventId, action: body.action});
    if (r.physical.identityMatch && r.physical.manifestMatch && r.physical.doorLocked && r.returnedAt === null) {
      if (at < r.startedAt) fail('CLOCK_OUT_OF_ORDER', 'The server clock reported an inconsistent time. Try again.', 503, undefined, true);
      r.returnedAt = at; r.baseAtReturnMinor = r.rates.base * seconds(r.startedAt, at); r.state = 'RETURN_PENDING';
      plan.proofFields.forEach(field => allocate(r, proofTasks[field], at));
      addEvent(r, 'PHYSICAL_RETURN_FROZEN', at, {returnedAt: at, baseMinor: r.baseAtReturnMinor, identityMatch: true, manifestMatch: true, doorLocked: true});
      r.support.messages.push({id: uid('msg'), role: 'assistant', speaker: 'DEVICE', text: receiptDeskCopy.locked, source: 'template', at});
    }
  } else if (type === 'proof') {
    requirePhysical(r);
    const fields = body.fields;
    const truth = proofTruth(r);
    const changed = {};
    for (const key of Object.keys(fields)) {
      if (key === 'reasonCode') { validateReason(fields[key]); if (r.proof[key] !== fields[key]) changed[key] = fields[key]; }
      else if (plan.proofFields.includes(key)) {
        const input = normalString(fields[key], key);
        const value = key === 'enteredReturnState' && input === '\u5df2\u5f52\u8fd8' ? 'RETURNED' : input;
        if (r.proof[key] !== value) changed[key] = value;
        if (value !== truth[key]) {
          r.invalidAttempts[key]++;
          r.validationErrors[key] = proofErrorMessage(r, key, truth);
        } else delete r.validationErrors[key];
      } else fail('INVALID_INPUT', 'The request contains an unsupported proof field.', 422, key);
    }
    if (Object.keys(changed).length) {
      const previousReason = r.proof.reasonCode;
      Object.assign(r.proof, changed); r.proofVersion++; mutated = true; clearSnapshot(r);
      plan.proofFields.forEach(field => {
        if (r.proof[field] === truth[field]) completeTask(r, proofTasks[field], at);
        else if (r.tasks[proofTasks[field]]) r.tasks[proofTasks[field]].status = 'ALLOCATED';
      });
      if ('reasonCode' in changed) {
        const human = r.checks.filter(c => c.id !== 'REASON_SPECIFIC');
        if (!r.theatricalReworkUsed && previousReason === 'GENERAL_END' && specificReasons.has(r.proof.reasonCode) && human.every(c => c.status === 'CONFIRMED')) {
          r.theatricalReworkUsed = true;
          human.forEach(c => expireCheck(r, c, at));
          addEvent(r, 'THEATRICAL_REWORK_TRIGGERED', at, {cause: 'Return reason changed', affectedChecks: human.map(c => c.id), count: 1});
        }
        const reasonCheck = r.checks.find(c => c.id === 'REASON_SPECIFIC');
        if (finished(reasonCheck)) {
          reasonCheck.status = 'PENDING';
          if (reasonCheck.confirmation) {
            reasonCheck.confirmation = {...reasonCheck.confirmation, expiredAt: at, expirationCause: 'REASON_SUBJECT_CHANGED'};
            const last = reasonCheck.history.find(h => h.id === reasonCheck.confirmation.id);
            if (last) Object.assign(last, {expiredAt: at, expirationCause: 'REASON_SUBJECT_CHANGED'});
          }
        }
      }
      addEvent(r, 'PROOF_UPDATED', at, {fields: Object.keys(changed), proofVersion: r.proofVersion});
    } else addEvent(r, 'PROOF_ATTEMPT', at, {fields: Object.keys(fields), unchanged: true});
    extras.validationErrors = {...r.validationErrors};
  } else if (type === 'checks') {
    requireSelfProof(r);
    if (body.action === 'REVEAL') {
      if (r.checks.some(c => c.visible && !finished(c))) fail('CHECK_INCOMPLETE', 'Complete the check already on screen first.');
      const next = r.checks.find(c => !c.visible);
      if (next) {
        if (body.checkId && body.checkId !== next.id) fail('CHECK_ORDER_INVALID', 'Complete the checks in the displayed order.');
        next.visible = true; next.status = 'PENDING'; allocate(r, checkTasks[next.id], at); mutated = true;
        addEvent(r, 'CHECK_REVEALED', at, {checkId: next.id, requirementsKnownFromStart: true});
      }
    } else if (body.action === 'CONFIRM') {
      const check = r.checks.find(c => c.id === body.checkId);
      if (!check || !check.visible) fail('CHECK_NOT_VISIBLE', 'This check has not opened yet. View the current requirement first.');
      if (check.id === 'REASON_SPECIFIC') {
        if (!specificReasons.has(r.proof.reasonCode)) fail('REASON_TOO_GENERAL', '“Finished using it” needs more detail. Choose “Shoot complete” or “Plans cancelled”.', 422, 'reasonCode');
        if (r.checks.some(c => c.id !== 'REASON_SPECIFIC' && !finished(c))) fail('REWORK_REQUIRED', 'Renew the expired return confirmations first.');
      }
      if (!finished(check)) {
        const wasRework = check.status === 'EXPIRED';
        if (plan !== legacyPlan && wasRework && r.checks.find(c => c.status === 'EXPIRED') !== check) {
          fail('CHECK_ORDER_INVALID', 'Complete the preceding confirmations first.');
        }
        await confirmCheck(r, check, at); mutated = true; clearSnapshot(r);
        addEvent(r, wasRework ? 'CHECK_RECONFIRMED' : 'CHECK_CONFIRMED', at, {checkId: check.id, adoptionMethod: 'MANUAL'});
      }
    } else fail('INVALID_INPUT', 'Unknown verification action.', 422, 'action');
  } else if (type === 'filing') {
    submitFiling(r, body, at);
    mutated = true;
  } else if (type === 'filing-review') {
    submitFilingReview(r, body, at);
    mutated = true;
  } else if (type === 'finalization') {
    await submitFinalization(r, body, at, reasonReview);
    mutated = true;
  } else if (type === 'support') {
    if (body.action === 'MESSAGE') {
      if (typeof body.message !== 'string' || !body.message.trim() || Array.from(body.message).length > 500) fail('INVALID_INPUT', 'Enter between 1 and 500 characters.', 422, 'message');
      if (r.support.turnSeq >= 24) fail('DEMO_HISTORY_LIMIT', 'This demo has reached its limit of 24 support exchanges. Continue the review or use Help to proceed with the evidence on file.');
      const reply = supportReply(r, body.message);
      r.support.turnSeq++;
      r.support.messages.push(
        {id: uid('msg'), role: 'user', speaker: r.support.role, text: body.message.trim(), source: 'template', at},
        {id: uid('msg'), role: 'assistant', speaker: r.support.role, text: Array.from(reply.text).slice(0, 120).join(''), source: 'template', at, intent: reply.intent, action: reply.action, sourceStateVersion: r.stateVersion, sourceProofVersion: r.proofVersion, conversationTurnSeq: r.support.turnSeq}
      );
      addEvent(r, 'SUPPORT_REPLY', at, {role: r.support.role, intent: reply.intent, source: 'template', turnSeq: r.support.turnSeq});
      extras.supportAction = reply.action;
    } else if (body.action === 'TRANSFER') {
      requirePending(r); requirePhysical(r);
      const nextRole = nextSupportRole(r);
      if (!nextRole) fail('HANDOFF_LIMIT', `The transfer limit is ${plan.supportRoute.length - 1}. Continue the review or use the evidence on file to go to final review.`);
      const from = r.support.role;
      r.support.handoffs++; r.support.role = nextRole;
      allocate(r, `HANDOFF_${r.support.handoffs}`, at); completeTask(r, `HANDOFF_${r.support.handoffs}`, at);
      const reply = supportReply(r, 'End the rental');
      r.support.messages.push({id: uid('msg'), role: 'assistant', speaker: r.support.role, text: reply.text, source: 'template', at, action: reply.action});
      mutated = true; addEvent(r, 'SUPPORT_TRANSFERRED', at, {from, to: r.support.role, handoffs: r.support.handoffs});
    } else fail('INVALID_INPUT', 'Unknown support action.', 422, 'action');
  } else if (type === 'help') {
    requirePhysical(r);
    if (body.adopt !== true || !specificReasons.has(body.reasonCode)) fail('INVALID_INPUT', 'Choose a specific return reason and confirm that you want to use the evidence on file.', 422, 'reasonCode');
    const nextProof = {...proofTruth(r), reasonCode: body.reasonCode};
    const contentChanged = canonical(nextProof) !== canonical(r.proof);
    if (contentChanged) { r.proof = nextProof; r.proofVersion++; }
    r.validationErrors = {}; r.helpUsed = true; clearSnapshot(r);
    for (const field of plan.proofFields) {
      r.proofAdoptions[field] = {at, adoptionMethod: 'HELP_ACCEPTED'};
      if (r.tasks[proofTasks[field]]?.status !== 'COMPLETED') completeTask(r, proofTasks[field], at, 'HELP_ACCEPTED');
    }
    for (const check of r.checks) {
      if (!finished(check) || (check.id === 'REASON_SPECIFIC' && check.confirmation?.subjectDigest !== await subjectDigest(r, check.id))) await confirmCheck(r, check, at, 'HELP_ACCEPTED');
    }
    if (!filingComplete(r)) {
      r.filing.status = 'WAIVED';
      addEvent(r, 'APPLICATION_WAIVED', at, {adoptionMethod: 'HELP_ACCEPTED'});
    }
    if (!finalizationComplete(r)) enterFinalizationStage(r, 'WAIVED', at);
    for (const task of Object.values(r.tasks)) if (task.status === 'ALLOCATED') completeTask(r, task.id, at, 'HELP_ACCEPTED');
    mutated = true; addEvent(r, 'HELP_EVIDENCE_ADOPTED', at, {reasonCode: body.reasonCode, adoptionMethod: 'HELP_ACCEPTED', physicalEvidenceUnchanged: true});
  } else if (type === 'close-preview') {
    requireChecks(r);
    requireFilingComplete(r);
    if (!finalizationComplete(r)) fail('FINALIZATION_INCOMPLETE', 'Complete closure preparation or open Help to use the evidence already on file.');
    if (!r.closeSnapshot) {
      const physicalProofDigest = await digest({assetId: r.assetId, slotId: r.slotId, returnedAt: r.returnedAt, ...r.physical});
      const humanProofDigest = await digest(r.checks.map(c => ({id: c.id, status: c.status, subjectDigest: c.confirmation?.subjectDigest ?? null, adoptionMethod: c.confirmation?.adoptionMethod ?? null})));
      const core = {rentalId: r.id, assetId: r.assetId, slotId: r.slotId, returnedAt: r.returnedAt, proofVersion: r.proofVersion, reasonCode: r.proof.reasonCode, physicalProofDigest, humanProofDigest, policyVersion: r.policyVersion, currency: 'DEMO', finalBaseMinor: r.baseAtReturnMinor};
      r.closeSnapshot = {id: uid('snap'), hash: await digest(core), ...core, createdAt: at};
      r.state = 'READY_TO_CLOSE'; mutated = true;
      addEvent(r, 'CLOSE_SNAPSHOT_CREATED', at, {snapshotId: r.closeSnapshot.id, finalBaseMinor: r.baseAtReturnMinor, waitingEstimateExcluded: true});
    }
  } else if (type === 'presented') {
    if (body.taskIds.length > plan.taskIds.length) fail('INVALID_INPUT', 'The task display record is invalid.', 422, 'taskIds');
    for (const id of body.taskIds) {
      const task = r.tasks[id];
      if (!task) fail('INVALID_INPUT', 'The task cannot be displayed before it is assigned.', 422, 'taskIds');
      if (task.presentedAt === null) {
        task.presentedAt = at; addEvent(r, 'TASK_PRESENTED', at, {taskId: id});
      }
    }
  } else fail('NOT_FOUND', 'This action was not found.', 404);
  if (type === 'checks' && mutated && stage(r) === 'FILING' && r.filing.status === 'NOT_STARTED') {
    allocate(r, FILING_RECEIPT, at);
  }
  updateEventVersions(r, eventStart, mutated);
  return extras;
}

export function performClose(r, body, at) {
  requirePhysical(r);
  if (r.state !== 'READY_TO_CLOSE' || !r.closeSnapshot) fail('SNAPSHOT_STALE', 'The final review has changed. Check the latest details before ending the rental.');
  if (body.snapshotId !== r.closeSnapshot.id || body.snapshotHash !== r.closeSnapshot.hash) fail('SNAPSHOT_STALE', 'The submitted review is out of date. Review the latest details and try again.');
  if (at < r.returnedAt) fail('CLOCK_OUT_OF_ORDER', 'The server clock reported an inconsistent time. Try again shortly.', 503, undefined, true);
  if (body.confirmClose !== true) fail('INVALID_INPUT', 'Confirm that you want to end the rental.', 422, 'confirmClose');
  const amounts = billing(r, at);
  const receipt = {
    id: uid('rcpt'), rentalId: r.id, verificationCode: 'SR-' + crypto.randomUUID().replaceAll('-', '').slice(0, 24).toUpperCase(),
    assetId: r.assetId, slotId: r.slotId, startedAt: r.startedAt, returnedAt: r.returnedAt, closedAt: at,
    currency: 'DEMO', baseMinor: amounts.baseMinor, waitMinor: amounts.waitMinor,
    reversalMinor: -amounts.waitMinor, finalMinor: amounts.baseMinor,
    reasonCode: r.proof.reasonCode, snapshotHash: r.closeSnapshot.hash,
    stats: {extraTasks: Object.keys(r.tasks).length, handOffs: r.support.handoffs, reworkCount: r.theatricalReworkUsed ? 1 : 0, helpUsed: r.helpUsed, elapsedAfterReturnSeconds: seconds(r.returnedAt, at)},
    simulation: true,
  };
  r.receipt = receipt; r.state = 'CLOSED'; r.closedAt = at; r.stateVersion++;
  addEvent(r, 'RENTAL_CLOSED', at, {operationId: body.operationId, receiptId: receipt.id, baseMinor: receipt.baseMinor, waitMinor: receipt.waitMinor, reversalMinor: receipt.reversalMinor, finalMinor: receipt.finalMinor});
  return receipt;
}
