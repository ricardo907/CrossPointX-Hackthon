/** Shared schema: migrations own hosted DDL; only local setup/tests execute this string. */
export const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS rentals (
  id TEXT PRIMARY KEY NOT NULL,
  owner_key TEXT NOT NULL,
  create_request_id TEXT NOT NULL,
  creation_digest TEXT NOT NULL,
  revision INTEGER NOT NULL DEFAULT 0,
  record_json TEXT NOT NULL,
  receipt_id TEXT,
  verification_code TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS rentals_owner_create_unique ON rentals(owner_key, create_request_id);
CREATE UNIQUE INDEX IF NOT EXISTS rentals_receipt_unique ON rentals(receipt_id);
CREATE UNIQUE INDEX IF NOT EXISTS rentals_verify_unique ON rentals(verification_code);
CREATE INDEX IF NOT EXISTS rentals_owner_created ON rentals(owner_key, created_at);
`;

export async function findRental(db, id) {
  return await db.prepare('SELECT * FROM rentals WHERE id = ?').bind(id).first();
}
export async function findCreation(db, ownerKey, requestId) {
  return await db.prepare('SELECT * FROM rentals WHERE owner_key = ? AND create_request_id = ?').bind(ownerKey, requestId).first();
}
export async function findReceipt(db, receiptId) {
  return await db.prepare('SELECT * FROM rentals WHERE receipt_id = ?').bind(receiptId).first();
}
export async function findVerification(db, code) {
  return await db.prepare('SELECT * FROM rentals WHERE verification_code = ?').bind(code).first();
}
export async function listRentals(db, ownerKey) {
  const result = await db.prepare('SELECT * FROM rentals WHERE owner_key = ? ORDER BY created_at DESC, id DESC LIMIT 50').bind(ownerKey).all();
  return result.results ?? [];
}
export async function insertRental(db, record, ownerKey, requestId, digest) {
  return await db.prepare('INSERT INTO rentals (id, owner_key, create_request_id, creation_digest, revision, record_json, receipt_id, verification_code, created_at, updated_at) VALUES (?, ?, ?, ?, 0, ?, NULL, NULL, ?, ?)')
    .bind(record.id, ownerKey, requestId, digest, JSON.stringify(record), record.createdAt, record.createdAt).run();
}
/** One atomic UPDATE commits every domain field, audit event, receipt and retry result. */
export async function compareAndSwap(db, row, record, timestamp) {
  const result = await db.prepare('UPDATE rentals SET revision = revision + 1, record_json = ?, receipt_id = ?, verification_code = ?, updated_at = ? WHERE id = ? AND revision = ?')
    .bind(JSON.stringify(record), record.receipt?.id ?? null, record.receipt?.verificationCode ?? null, timestamp, row.id, row.revision).run();
  return Number(result.meta?.changes ?? result.changes ?? 0) === 1;
}
