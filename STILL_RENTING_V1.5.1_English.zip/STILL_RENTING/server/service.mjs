import {
  DomainError, fail, digest, makeRecord, view, observerView, applyCommand, performClose,
  canClosePreview, filingDocuments, getHumanChallenge, PROOF_FIELDS, CHECK_IDS, FILING_REVIEW_ACTIONS,
  FINALIZATION_ACTIONS, MAX_TASK_BUDGET, localizeRentalText,
} from './domain.mjs';
import {findRental, findCreation, findReceipt, findVerification, listRentals, insertRental, compareAndSwap} from './repository.mjs';

const JSON_HEADERS = {'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff'};
const SESSION_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const ID_RE = /^[A-Za-z0-9_.:-]{1,120}$/;
const common = ['requestId', 'expectedStateVersion'];
const schemas = {
  'device-events': [...common, 'eventId', 'action'],
  proof: [...common, 'fields'], checks: [...common, 'action', 'checkId'],
  filing: [...common, 'receiptCode', 'certificateCode'],
  'filing-review': [...common, 'action', 'code'],
  finalization: [...common, 'action', 'reason', 'code', 'challengeId'],
  support: [...common, 'action', 'message'], help: [...common, 'reasonCode', 'adopt'],
  'close-preview': common, close: [...common, 'operationId', 'snapshotId', 'snapshotHash', 'confirmClose'],
  presented: [...common, 'taskIds'],
};
export function jsonResponse(value, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(value), {status, headers: {...JSON_HEADERS, ...extraHeaders}});
}
function id(value, field) {
  if (typeof value !== 'string' || !ID_RE.test(value)) fail('INVALID_INPUT', 'The identifier format is invalid.', 422, field);
  return value;
}
function onlyFields(body, allowed) {
  for (const key of Object.keys(body)) if (!allowed.includes(key)) fail('INVALID_INPUT', 'The request contains an unsupported field.', 422, key);
}
function nowValue(now) {
  const value = typeof now === 'function' ? now() : Date.now();
  if (!Number.isSafeInteger(value) || value < 0 || !Number.isFinite(new Date(value).getTime())) fail('CLOCK_INVALID', 'The server clock is unavailable.', 503, undefined, true);
  return value;
}
async function readJson(request) {
  const declared = Number(request.headers.get('content-length') || 0);
  if (declared > 16384) fail('BODY_TOO_LARGE', 'The request cannot exceed 16 KiB.', 413);
  if (!request.body) fail('INVALID_JSON', 'The request is missing a JSON body.', 422);
  const reader = request.body.getReader();
  let size = 0;
  const chunks = [];
  try {
    while (true) {
      const {done, value} = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > 16384) { await reader.cancel(); fail('BODY_TOO_LARGE', 'The request cannot exceed 16 KiB.', 413); }
      chunks.push(value);
    }
  } finally { reader.releaseLock(); }
  const bytes = new Uint8Array(size);
  let offset = 0;
  chunks.forEach(chunk => { bytes.set(chunk, offset); offset += chunk.byteLength; });
  let body;
  try { body = JSON.parse(new TextDecoder('utf-8', {fatal: true}).decode(bytes)); }
  catch { fail('INVALID_JSON', 'The request does not contain valid JSON.', 422); }
  if (!body || typeof body !== 'object' || Array.isArray(body)) fail('INVALID_JSON', 'The request body must be a JSON object.', 422);
  return body;
}
function authorize(row, ownerKey) {
  // The same response covers absent and another session's resources.
  if (!row || row.owner_key !== ownerKey) fail('NOT_FOUND', 'This rental or receipt could not be found.', 404);
}
function parseRecord(row) {
  try { return JSON.parse(row.record_json); }
  catch { fail('STORAGE_UNAVAILABLE', 'The record is temporarily unavailable. Keep this page open and try again.', 503, undefined, true); }
}
function checkVersion(record, expected) {
  if (record.stateVersion !== expected) {
    const e = new DomainError('VERSION_CONFLICT', 'Another page updated this rental. Refresh the current status before continuing.', 409);
    e.currentStateVersion = record.stateVersion; throw e;
  }
}
function validateCommand(type, body) {
  onlyFields(body, schemas[type]);
  id(body.requestId, 'requestId');
  if (!Number.isSafeInteger(body.expectedStateVersion) || body.expectedStateVersion < 1) fail('INVALID_INPUT', 'Provide the current rental version.', 422, 'expectedStateVersion');
  if (type === 'device-events') {
    id(body.eventId, 'eventId');
    if (!['PLACE_BODY', 'PLACE_CAP', 'PLACE_BATTERY', 'LOCK_DOOR'].includes(body.action)) fail('INVALID_INPUT', 'Choose a valid locker action.', 422, 'action');
  } else if (type === 'proof') {
    if (!body.fields || Array.isArray(body.fields) || typeof body.fields !== 'object' || !Object.keys(body.fields).length) fail('INVALID_INPUT', 'Specify the proof fields to update.', 422, 'fields');
    onlyFields(body.fields, [...PROOF_FIELDS, 'reasonCode']);
  } else if (type === 'checks') {
    if (!['REVEAL', 'CONFIRM'].includes(body.action)) fail('INVALID_INPUT', 'Choose a valid verification action.', 422, 'action');
    if (body.checkId !== undefined && !CHECK_IDS.includes(body.checkId)) fail('INVALID_INPUT', 'The check identifier is invalid.', 422, 'checkId');
    if (body.action === 'CONFIRM' && !body.checkId) fail('INVALID_INPUT', 'Choose the check you want to confirm.', 422, 'checkId');
  } else if (type === 'filing') {
    for (const field of ['receiptCode', 'certificateCode']) {
      if (field === 'certificateCode' && body[field] === undefined) continue;
      if (typeof body[field] !== 'string' || Array.from(body[field]).length > 80) {
        fail('INVALID_INPUT', 'Enter a document number no longer than 80 characters.', 422, field);
      }
    }
  } else if (type === 'filing-review') {
    if (!FILING_REVIEW_ACTIONS.includes(body.action)) fail('INVALID_INPUT', 'Choose a valid reconsideration action.', 422, 'action');
    if (typeof body.code !== 'string' || !body.code.trim() || Array.from(body.code).length > 80) {
      fail('INVALID_INPUT', 'Enter a document number between 1 and 80 characters.', 422, 'code');
    }
  } else if (type === 'finalization') {
    if (!FINALIZATION_ACTIONS.includes(body.action)) fail('INVALID_INPUT', 'Choose a valid closure preparation action.', 422, 'action');
    const fields = [...common, 'action'];
    if (body.action === 'REVIEW_REASON') fields.push('reason');
    if (body.action === 'CERTIFY') fields.push('code');
    if (body.action === 'VERIFY_HUMAN') {
      fields.push('code', 'challengeId');
      id(body.challengeId, 'challengeId');
    }
    onlyFields(body, fields);
  } else if (type === 'support') {
    if (!['MESSAGE', 'TRANSFER'].includes(body.action)) fail('INVALID_INPUT', 'Choose a valid support action.', 422, 'action');
  } else if (type === 'close') {
    id(body.operationId, 'operationId'); id(body.snapshotId, 'snapshotId');
    if (typeof body.snapshotHash !== 'string' || !/^[a-f0-9]{64}$/.test(body.snapshotHash)) fail('INVALID_INPUT', 'The settlement snapshot checksum is invalid.', 422, 'snapshotHash');
    if (typeof body.confirmClose !== 'boolean') fail('INVALID_INPUT', 'Specify whether you want to end the rental.', 422, 'confirmClose');
  } else if (type === 'presented') {
    if (!Array.isArray(body.taskIds) || body.taskIds.length > MAX_TASK_BUDGET || body.taskIds.some(t => typeof t !== 'string' || t.length > 50)) fail('INVALID_INPUT', 'The task display record is invalid.', 422, 'taskIds');
  }
}
function businessPayload(type, body) {
  if (type === 'close') return {snapshotId: body.snapshotId, snapshotHash: body.snapshotHash, confirmClose: body.confirmClose};
  const result = {};
  for (const key of Object.keys(body)) if (key !== 'requestId' && key !== 'expectedStateVersion') result[key] = body[key];
  return result;
}
async function createRental(db, ownerKey, body, timestamp) {
  onlyFields(body, ['requestId', 'scenarioId', 'seed']);
  id(body.requestId, 'requestId');
  if (body.scenarioId !== 'CAMERA_RETURN') fail('INVALID_INPUT', 'Only the camera return scenario is available.', 422, 'scenarioId');
  if (body.seed !== undefined && (typeof body.seed !== 'string' || body.seed.length > 80)) fail('INVALID_INPUT', 'The demo seed is too long or has an invalid format.', 422, 'seed');
  const creationDigest = await digest({scenarioId: body.scenarioId, seed: body.seed ?? 'demo-1'});
  const existing = await findCreation(db, ownerKey, body.requestId);
  if (existing) {
    if (existing.creation_digest !== creationDigest) fail('IDEMPOTENCY_CONFLICT', 'A creation request ID cannot be reused with different demo settings.');
    return parseRecord(existing).creationResponse;
  }
  const record = makeRecord(timestamp, body.seed ?? 'demo-1');
  const response = {ok: true, requestId: body.requestId, rental: view(record, timestamp), observerKey: record.observerKey};
  record.creationResponse = response;
  try { await insertRental(db, record, ownerKey, body.requestId, creationDigest); }
  catch (error) {
    // A concurrent request can win the unique create key. Only that exact key is replayed.
    const winner = await findCreation(db, ownerKey, body.requestId);
    if (!winner) throw error;
    if (winner.creation_digest !== creationDigest) fail('IDEMPOTENCY_CONFLICT', 'A creation request ID cannot be reused with different demo settings.');
    return parseRecord(winner).creationResponse;
  }
  return response;
}
export const ORDINARY_RECORD_LIMIT_BYTES = 1_000_000;
export const COMPLETION_RECORD_LIMIT_BYTES = 1_800_000;
function completionPosition(record) {
  return {
    state: record.state,
    physicalCount: ['body', 'cap', 'battery', 'doorLocked'].filter(key => record.physical[key]).length,
    readyForPreview: canClosePreview(record),
    hasSnapshot: record.closeSnapshot !== null,
  };
}
function ensureStorageCapacity(record, before, type) {
  const bytes = new TextEncoder().encode(JSON.stringify(record)).byteLength;
  if (bytes <= ORDINARY_RECORD_LIMIT_BYTES) return;
  // Every admitted exceptional write moves strictly toward a terminal receipt.
  // Repeated proof, help, preview or new closed-operation keys cannot consume
  // the reserve. Existing accepted idempotency keys are returned before here.
  const after = completionPosition(record);
  const forwardCompletion =
    (type === 'device-events' && before.state === 'ACTIVE' && after.physicalCount > before.physicalCount) ||
    (type === 'help' && !before.readyForPreview && after.readyForPreview) ||
    (type === 'close-preview' && !before.hasSnapshot && after.hasSnapshot && after.state === 'READY_TO_CLOSE') ||
    (type === 'close' && before.state !== 'CLOSED' && after.state === 'CLOSED');
  if (forwardCompletion && bytes <= COMPLETION_RECORD_LIMIT_BYTES) return;
  const message = before.state === 'CLOSED'
    ? 'The demo history limit has been reached. The rental has ended and the original receipt is available.'
    : before.state === 'READY_TO_CLOSE'
      ? 'The demo history limit has been reached. Final review is ready. End the rental to generate a receipt.'
      : before.readyForPreview
        ? 'The demo history limit has been reached. The evidence is complete. Continue to final review and settlement.'
        : 'The demo history limit has been reached. Secure the equipment in the locker, then use Help to proceed with the evidence on file.';
  fail('DEMO_HISTORY_LIMIT', message);
}
async function persistMutation(db, row, record, timestamp, before, type) {
  ensureStorageCapacity(record, before, type);
  return await compareAndSwap(db, row, record, timestamp);
}
async function mutate(db, ownerKey, rentalId, type, body, timestamp, reasonReview) {
  const payload = businessPayload(type, body);
  const commandDigest = await digest({rentalId, type, payload});
  const eventDigest = type === 'device-events' ? await digest({rentalId, action: body.action}) : null;
  let reviewResult;
  // Phase validation runs inside applyCommand before the first reviewer call.
  // Retain that one result while retrying a storage revision conflict.
  const reviewOnce = typeof reasonReview === 'function'
    ? details => reviewResult ??= Promise.resolve().then(() => reasonReview(details))
    : undefined;
  for (let attempt = 0; attempt < 12; attempt++) {
    const row = await findRental(db, rentalId);
    authorize(row, ownerKey);
    const record = parseRecord(row);
    const before = completionPosition(record);
    if (type === 'close') {
      // Authorization/shape validation precedes replay. Replay precedes version checks.
      const previous = record.operations[body.operationId];
      if (previous) {
        if (previous.digest !== commandDigest) fail('IDEMPOTENCY_CONFLICT', 'A closure operation ID cannot be reused with different review details.');
        return previous.response;
      }
      if (body.confirmClose !== true) fail('INVALID_INPUT', 'Confirm that you want to end the rental.', 422, 'confirmClose');
      if (record.state === 'CLOSED') {
        const response = {ok: true, requestId: body.requestId, rental: view(record, timestamp), receipt: record.receipt, operation: {status: 'SUCCEEDED', receipt: record.receipt}};
        record.operations[body.operationId] = {digest: commandDigest, completedAt: timestamp, response};
        if (await persistMutation(db, row, record, timestamp, before, type)) return response;
        continue;
      }
      checkVersion(record, body.expectedStateVersion);
      const receipt = performClose(record, body, timestamp);
      const response = {ok: true, requestId: body.requestId, rental: view(record, timestamp), receipt, operation: {status: 'SUCCEEDED', receipt}};
      record.operations[body.operationId] = {digest: commandDigest, completedAt: timestamp, response};
      if (await persistMutation(db, row, record, timestamp, before, type)) return response;
      continue;
    }
    const previous = record.commands[body.requestId];
    if (previous) {
      if (previous.digest !== commandDigest) fail('IDEMPOTENCY_CONFLICT', 'A request ID cannot be reused for a different operation.');
      return previous.response;
    }
    if (type === 'device-events' && record.deviceEvents[body.eventId]) {
      const previousEvent = record.deviceEvents[body.eventId];
      if (previousEvent.digest !== eventDigest) fail('IDEMPOTENCY_CONFLICT', 'A device event ID cannot be reused for a different action.');
      const response = {...previousEvent.response, requestId: body.requestId};
      record.commands[body.requestId] = {digest: commandDigest, completedAt: timestamp, response};
      if (await persistMutation(db, row, record, timestamp, before, type)) return response;
      continue;
    }
    checkVersion(record, body.expectedStateVersion);
    const extras = await applyCommand(record, type, body, timestamp, {reasonReview: reviewOnce});
    const response = {ok: true, requestId: body.requestId, rental: view(record, timestamp), ...extras};
    record.commands[body.requestId] = {digest: commandDigest, completedAt: timestamp, response};
    if (type === 'device-events') record.deviceEvents[body.eventId] = {digest: eventDigest, response};
    if (await persistMutation(db, row, record, timestamp, before, type)) return response;
  }
  fail('CONCURRENT_WRITE_RETRY', 'Another page is updating this rental. Refresh and try again.', 409, undefined, true);
}

function reviewModeForRental(rental, reviewMode) {
  const localized = localizeRentalText(rental);
  return localized.finalization ? {...localized, reasonReviewMode: reviewMode} : localized;
}
function withReviewMode(response, reviewMode) {
  if (!response.rental) return response;
  const rental = reviewModeForRental(response.rental, reviewMode);
  const validation = response.validationErrors ? {validationErrors: rental.validationErrors} : {};
  return {...response, ...validation, rental};
}

/** Platform wrappers supply an authenticated owner; local development supplies a loopback owner. */
export async function handleApi(request, {db, owner, now, reasonReview, reasonReviewMode} = {}) {
  try {
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/$/, '');
    const method = request.method.toUpperCase();
    if (path === '/api/health' && method === 'GET') return jsonResponse({ok: true, service: 'still-renting', version: '1.5.1'});
    if (!db) fail('STORAGE_UNAVAILABLE', 'The database is not configured. Complete local setup and try again.', 503, undefined, true);
    const verifyMatch = /^\/api\/verify\/([^/]+)$/.exec(path);
    if (verifyMatch && method === 'GET') {
      const code = decodeURIComponent(verifyMatch[1]);
      if (!/^SR-[A-F0-9]{24}$/.test(code)) fail('NOT_FOUND', 'This demo receipt could not be found.', 404);
      const row = await findVerification(db, code);
      if (!row) fail('NOT_FOUND', 'This demo receipt could not be found.', 404);
      const receipt = parseRecord(row).receipt;
      return jsonResponse({ok: true, verification: {valid: true, receiptId: receipt.id, rentalId: receipt.rentalId, assetId: receipt.assetId, closedAt: receipt.closedAt, finalMinor: receipt.finalMinor, currency: 'DEMO', simulation: true}});
    }
    if (typeof owner !== 'string' || !owner) fail('AUTH_REQUIRED', 'Sign in to use this demo.', 401);
    const session = request.headers.get('x-demo-session');
    if (!session || !SESSION_RE.test(session)) fail('SESSION_REQUIRED', 'The demo session is unavailable. Reopen the page.', 401);
    const ownerKey = owner + ':' + session.toLowerCase();
    const timestamp = nowValue(now);
    const reviewMode = reasonReviewMode === 'OPENAI' && typeof reasonReview === 'function' ? 'OPENAI' : 'LOCAL';
    if (path === '/api/rentals') {
      if (method === 'POST') {
        const response = await createRental(db, ownerKey, await readJson(request), timestamp);
        return jsonResponse(withReviewMode(response, reviewMode));
      }
      if (method === 'GET') {
        const rows = await listRentals(db, ownerKey);
        return jsonResponse({ok: true, rentals: rows.map(row => reviewModeForRental(view(parseRecord(row), timestamp), reviewMode))});
      }
      fail('METHOD_NOT_ALLOWED', 'This endpoint does not support that method.', 405);
    }
    const receiptMatch = /^\/api\/receipts\/([^/]+)$/.exec(path);
    if (receiptMatch && method === 'GET') {
      const receiptId = decodeURIComponent(receiptMatch[1]); id(receiptId, 'receiptId');
      const row = await findReceipt(db, receiptId); authorize(row, ownerKey);
      const record = parseRecord(row);
      const format = url.searchParams.get('format');
      if (format && format !== 'json') fail('FORMAT_NOT_SUPPORTED', 'Download the receipt as JSON or print it to PDF from your browser.', 422, 'format');
      return jsonResponse({ok: true, receipt: record.receipt}, 200, format === 'json' ? {'content-disposition': `attachment; filename="still-renting-${record.receipt.id}.json"`} : {});
    }
    const match = /^\/api\/rentals\/([^/]+)(?:\/([^/]+))?(?:\/([^/]+))?$/.exec(path);
    if (!match) fail('NOT_FOUND', 'This endpoint was not found.', 404);
    const rentalId = decodeURIComponent(match[1]); id(rentalId, 'rentalId');
    const action = match[2];
    if (!action && method === 'GET') {
      const row = await findRental(db, rentalId); authorize(row, ownerKey);
      const record = parseRecord(row);
      const response = {ok: true, rental: view(record, timestamp)};
      if (url.searchParams.get('view') === 'observer') {
        if (request.headers.get('x-observer-key') !== record.observerKey) fail('OBSERVER_ACCESS_DENIED', 'The observer panel requires a valid key for this demo.', 403);
        response.observer = observerView(record);
      }
      return jsonResponse(withReviewMode(response, reviewMode));
    }
    if (action === 'filing-documents' && !match[3] && method === 'GET') {
      const row = await findRental(db, rentalId); authorize(row, ownerKey);
      return jsonResponse({ok: true, filingDocuments: filingDocuments(parseRecord(row))});
    }
    if (action === 'human-challenge' && !match[3] && method === 'GET') {
      const row = await findRental(db, rentalId); authorize(row, ownerKey);
      return jsonResponse({ok: true, humanChallenge: getHumanChallenge(parseRecord(row), timestamp)});
    }
    if (action === 'operations' && match[3] && method === 'GET') {
      const operationId = decodeURIComponent(match[3]); id(operationId, 'operationId');
      const row = await findRental(db, rentalId); authorize(row, ownerKey);
      const record = parseRecord(row); const operation = record.operations[operationId];
      const response = {ok: true, rental: view(record, timestamp), operation: operation ? {status: 'SUCCEEDED', receipt: operation.response.receipt} : {status: 'NOT_FOUND'}};
      return jsonResponse(withReviewMode(response, reviewMode));
    }
    if (match[3] || !schemas[action]) fail('NOT_FOUND', 'This action was not found.', 404);
    if (method !== (action === 'proof' ? 'PATCH' : 'POST')) fail('METHOD_NOT_ALLOWED', 'This endpoint does not support that method.', 405);
    const body = await readJson(request); validateCommand(action, body);
    const response = await mutate(db, ownerKey, rentalId, action, body, timestamp, reasonReview);
    return jsonResponse(withReviewMode(response, reviewMode));
  } catch (error) {
    if (error instanceof DomainError) {
      return jsonResponse({ok: false, error: {code: error.code, message: error.message, ...(error.field ? {field: error.field} : {}), retryable: error.retryable, ...(error.currentStateVersion !== undefined ? {currentStateVersion: error.currentStateVersion} : {})}}, error.status);
    }
    // Never leak SQL, credentials, internal paths, or raw exception messages.
    console.error('still-renting API failure', error?.name ?? 'Error');
    return jsonResponse({ok: false, error: {code: 'SERVICE_UNAVAILABLE', message: 'The service is temporarily unavailable. Keep the operation ID and check its status or retry shortly.', retryable: true}}, 503);
  }
}
