const ANSWER_COUNT = 1_000_000;
const RANDOM_LIMIT = Math.floor(2 ** 32 / ANSWER_COUNT) * ANSWER_COUNT;
const WIDTH = 252;
const HEIGHT = 78;

// Hand-drawn glyphs. The coordinates are flattened into each issued image.
const glyphs = [
  [['M', 10, 1], ['C', -1, 1, -1, 36, 10, 36], ['C', 21, 36, 21, 1, 10, 1]],
  [['M', 3, 9], ['L', 11, 1], ['L', 11, 36], ['M', 4, 36], ['L', 18, 36]],
  [['M', 1, 9], ['C', 3, -2, 20, -2, 19, 11], ['C', 19, 19, 4, 25, 1, 36], ['L', 20, 36]],
  [['M', 2, 6], ['C', 10, -5, 24, 4, 16, 15], ['C', 14, 17, 11, 18, 7, 18], ['C', 22, 16, 24, 36, 10, 36], ['C', 6, 36, 2, 34, 1, 30]],
  [['M', 13, 1], ['L', 1, 24], ['L', 21, 24], ['M', 16, 11], ['L', 16, 36]],
  [['M', 19, 1], ['L', 4, 1], ['L', 2, 17], ['C', 19, 10, 24, 29, 14, 35], ['C', 9, 38, 3, 36, 1, 32]],
  [['M', 18, 3], ['C', 4, -5, -4, 20, 3, 32], ['C', 8, 42, 23, 35, 20, 23], ['C', 18, 13, 7, 14, 2, 22]],
  [['M', 1, 2], ['L', 20, 2], ['C', 13, 14, 9, 24, 7, 36]],
  [['M', 10, 17], ['C', -4, 12, 1, 1, 10, 1], ['C', 21, 1, 23, 12, 10, 17], ['C', -6, 23, -1, 36, 10, 36], ['C', 24, 36, 27, 23, 10, 17]],
  [['M', 19, 16], ['C', 14, 26, 0, 22, 1, 11], ['C', 1, -2, 16, -3, 19, 8], ['C', 21, 15, 21, 40, 4, 35]],
];
const ink = ['#223244', '#384034', '#253b3a'];
const noise = ['#afb9a3', '#bbcabf', '#c0c5ae'];

export function createHumanChallenge() {
  const value = new Uint32Array(1);
  do {
    crypto.getRandomValues(value);
  } while (value[0] >= RANDOM_LIMIT);
  return {
    id: crypto.randomUUID(),
    answer: String(value[0] % ANSWER_COUNT).padStart(6, '0'),
  };
}

function imageRandom(id) {
  let state = 2166136261;
  for (const character of id) state = Math.imul(state ^ character.charCodeAt(0), 16777619);
  state ||= 1;

  return (min, max) => {
    state ^= state << 13;
    state ^= state >>> 17;
    state ^= state << 5;
    return min + (max - min) * ((state >>> 0) / 2 ** 32);
  };
}

function drawGlyph(digit, index, random) {
  const baseX = 17 + index * 39 + random(-2.5, 2.5);
  const baseY = random(18, 25);
  const scaleX = random(1.05, 1.25);
  const scaleY = random(0.92, 1.08);
  const slant = random(-0.19, 0.19);
  const tilt = random(-0.17, 0.17);
  const path = glyphs[Number(digit)].map(([command, ...coords]) => {
    const points = [];
    for (let i = 0; i < coords.length; i += 2) {
      const x = coords[i];
      const y = coords[i + 1];
      points.push(
        (baseX + x * scaleX + y * slant).toFixed(1),
        (baseY + y * scaleY + x * tilt).toFixed(1),
      );
    }
    return command + points.join(' ');
  }).join(' ');
  const stroke = ink[Math.floor(random(0, ink.length))];
  return `<path d="${path}" stroke="${stroke}" stroke-width="${random(4.2, 5.3).toFixed(1)}"/>`;
}

export function publicHumanChallenge({ id, answer }) {
  const random = imageRandom(id);
  const speckles = Array.from({ length: 56 }, () => {
    const cx = random(2, WIDTH - 2).toFixed(1);
    const cy = random(3, HEIGHT - 3).toFixed(1);
    return `<circle cx="${cx}" cy="${cy}" r="${random(0.35, 0.96).toFixed(1)}"/>`;
  }).join('');
  const curves = noise.map((stroke, index) => {
    const y = 17 + index * 21;
    return `<path d="M3 ${y} Q${random(52, 119).toFixed(1)} ${random(2, 76).toFixed(1)} 140 ${random(24, 55).toFixed(1)} T249 ${random(16, 66).toFixed(1)}" stroke="${stroke}"/>`;
  }).join('');
  const digits = Array.from(answer, (digit, index) => drawGlyph(digit, index, random)).join('');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${WIDTH}" height="${HEIGHT}" viewBox="0 0 ${WIDTH} ${HEIGHT}">`
    + '<rect width="252" height="78" rx="10" fill="#f3f5e8"/>'
    + `<g fill="#aeb7a1">${speckles}</g>`
    + `<g fill="none" stroke-width="1.25">${curves}</g>`
    + `<g fill="none" stroke-linecap="round" stroke-linejoin="round">${digits}</g></svg>`;
  return { id, image: `data:image/svg+xml;base64,${btoa(svg)}` };
}

export function matchesHumanChallenge(challenge, code) {
  return typeof code === 'string' && /^\d{6}$/.test(code) && challenge?.answer === code;
}
