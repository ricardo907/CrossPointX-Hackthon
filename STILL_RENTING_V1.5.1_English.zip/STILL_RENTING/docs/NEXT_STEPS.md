# Optional follow-up work

Confirm the current implementation before picking up an item from this backlog. It records the earlier design and validation proposals.

## Reliability

| Item | Acceptance |
| --- | --- |
| Distinguish loading, error, empty and ready in history | A slow query keeps the loading state visible. A failed query offers retry. An empty state represents a successful empty result. |
| Use one monotonic freshness clock | Wall-clock changes leave the five-second disconnect freeze unaffected. Billing remains server-authoritative. |
| Extend stale-response regression coverage | A delayed response for the old rental, receipt or final snapshot leaves the current selection and unresolved close intent intact. |
| Cover interruption at closing and refresh | An operation lookup returning `NOT_FOUND` leaves the outcome unresolved. Retry uses the same ID. One receipt results. |

## Maintainability and demo

1. Extract the API client and session-recovery logic, then isolate task screens, overlays and receipts. Keep current behavior under tests during the split.
2. Derive an observer timeline from actual events showing when facts were known, when requirements appeared, and which reason change invalidated confirmed proof.
3. Reproduce failures where an ordinary mutation succeeds but its response is lost. The server deduplicates `requestId`. Decide which retries require preserving the same intent before changing the client.
4. Extend browser checks to keyboard navigation, zoom, and additional browser profiles. Include the timed fields and mobile layout.

## Optional integrations and event assets

An organizer-supplied Dify workflow or poster tool would be a separate task. The current support desk uses local role templates. Optional model-backed reason review already has a provider wrapper and local fallback. Data retention, dedicated PDF generation, physical hardware, and commerce integrations require their own scope and validation.
