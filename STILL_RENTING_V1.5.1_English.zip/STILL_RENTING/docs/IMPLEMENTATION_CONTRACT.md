# STILL RENTING implementation contract, version 1.5.1

The shared backend uses JavaScript modules. The hosted app runs on Cloudflare D1, and the portable app uses the built-in Node SQLite adapter. The server is authoritative. A conditional update atomically persists each rental’s state, receipts, command history, operation results and events in one row. The portable runtime uses Node 24 or later and its built-in libraries.

## HTTP & ownership

The worker routes `/api/` requests to `handleApi(request, {db, owner, now?})` in `server/service.mjs`. The worker supplies D1 and the platform-authenticated owner, or a development owner when configured. The portable server uses the loopback owner `local`. Owner-scoped endpoints require a UUID in `X-Demo-Session`, and the server combines the authenticated owner and session to create the owner key. The observer view also requires the `X-Observer-Key` issued when a rental is created. The frontend persists that key. Send JSON bodies under 16 KiB. Creation takes `{requestId, scenarioId:'CAMERA_RETURN', seed:'demo-1'}`. The other domain mutations take `{requestId, expectedStateVersion, ...fields}`. The backend validates JSON, IDs, fields and enums. Responses use JSON and `Cache-Control: no-store`.

## Envelope
Success responses use `{ok:true, requestId?, rental?:RentalView, observerKey?:string, receipt?:Receipt, operation?:{status:'SUCCEEDED'|'NOT_FOUND', receipt?:Receipt}, verification?:object, observer?:object}` where applicable. Errors use `{ok:false, error:{code, message, field?, retryable, currentStateVersion?}}`. GET `/api/health` returns `{ok:true, service:'still-renting', version:'1.5.1'}`. GET `/api/rentals` returns rental summaries for the session owner.

RentalView fields:
```
{
 id,assetId:'CAM-042',assetName:'Aperture S1',slotId:'B-07',
 state:'ACTIVE'|'RETURN_PENDING'|'READY_TO_CLOSE'|'CLOSED',
 stateVersion,proofVersion,planVersion:'1'|'2'|'3'|'4'|'5'|'6',startedAt,returnedAt:null|ms,closedAt:null|ms,
 serverNow:ms,stage:'RETURN_SIMULATION'|'SELF_PROOF'|'CHECKS'|'REWORK'|'FILING'|'FINALIZATION'|'FINAL_REVIEW'|'RECEIPT',
 physical:{body:false,cap:false,battery:false,doorLocked:false,identityMatch:false,manifestMatch:false},
 proof:{enteredAssetId:'',enteredSlotId:'',enteredReturnState:'',enteredReturnedAt?:string,enteredManifestCount?:string,reasonCode:'GENERAL_END'|'SHOOT_COMPLETE'|'PLAN_CANCELLED'},
 selfProofComplete:false,invalidAttempts:Record<string,number>,
 checks:[{id:'CAP_CONFIRM'|'BATTERY_CONFIRM'|'BODY_CONFIRM'|'DOOR_CONFIRM'|'REASON_SPECIFIC',label,status:'HIDDEN'|'PENDING'|'CONFIRMED'|'EXPIRED'|'WAIVED_BY_USER',visible:boolean,confirmation?:object}],
 theatricalReworkUsed:false,
 support:{role:'DEVICE'|'BILLING'|'REVIEW',handoffs:0,handoffLimit:4,allowedActions:string[],messages:[{id,role:'user'|'assistant',speaker:'DEVICE'|'BILLING'|'REVIEW',text,source:'template',at}]},
 filing?:{status:'NOT_STARTED'|'NEEDS_CERTIFICATE'|'RECALL_REQUIRED'|'REISSUE_REQUIRED'|'REGISTRY_REQUIRED'|'ACK_REQUIRED'|'APPROVED'|'WAIVED',acceptedReceiptCode?:string},
 finalization?:{status:'SYNC_PROGRESS'|'REASON_REQUIRED'|'REASON_PROGRESS'|'CERTIFY_REQUIRED'|'FINAL_PROGRESS'|'HUMAN_REQUIRED'|'RELEASE_REQUIRED'|'APPROVED'|'WAIVED',enteredAt:number,deadlineAt?:number|null,human?:{id:string,attempts:number},review?:{attempts:number,decision:'SUFFICIENT'|'INSUFFICIENT'|'MANUAL_ACCEPTED',feedback:string,source:'LOCAL'|'OPENAI'}},
 budget:{limit:31,allocated:0,presented:0,taskIds:[]},
 billing:{currency:'DEMO',baseRateMinorPerSecond:1,waitRateMinorPerSecond:1,baseMinor:0,waitMinor:0,projectedMinor:0,finalMinor:null|number,reversalMinor:0},
 closeSnapshot:null|{id,hash,finalBaseMinor,reasonCode,returnedAt,proofVersion,createdAt},
 receiptId:null|string,
 events:[{id,type,at,detail,sequence}],
 helpUsed:false
}
```
Times are UTC epoch milliseconds. One DEMO unit equals 100 minor units. The simulated rental starts 600 seconds before creation, and `startedAt` remains fixed. The server sets `returnedAt` when it accepts all three pieces and the locker is locked. That timestamp then remains fixed.

## Routes and commands

POST `/api/rentals` => RentalView + observerKey. Idempotent requestId scoped owner+session.
GET `/api/rentals/:id` => RentalView; `?view=observer` requires X-Observer-Key and adds observer known plan/facts/digests/events.
POST `.../device-events` {eventId,action:'PLACE_BODY'|'PLACE_CAP'|'PLACE_BATTERY'|'LOCK_DOOR'} => snapshot. Never accepts facts/times. Refuse lock before all pieces; after physical completion scene immutable.
PATCH `.../proof` accepts fields enteredAssetId, enteredSlotId, enteredReturnState, enteredReturnedAt, enteredManifestCount and reasonCode. The additional timestamp and count are text proof fields checked against the server's ISO UTC time and accepted item count. Invalid attempts persist field validation and draft values in the rental view. Plans '2' through '6' require five correct entries. With the four hardware items confirmed, the first switch from GENERAL_END to a specific reason expires those four confirmations once. Later reason edits preserve unrelated confirmations.

New rentals use planVersion '6' with 31 maximum tasks (27 without support). Persisted plan '5' has 30 maximum tasks (26 without support) and uses the untimed conclusion flow. Persisted plan '4' has 24 maximum tasks (20 without support) and can proceed to final review after reopened-application approval. Persisted plan '3' has 20 maximum tasks (16 without support) and approves after certificate submission. Persisted plan '2' has 18 maximum tasks (14 without support). Plan '1' has three proof fields, three checks, two rework items, two transfers and a ten-task cap. Plans '1' and '2' can proceed to final review when their original checks are complete.
POST `.../checks` {action:'REVEAL'|'CONFIRM',checkId?:string}. Plans '2' through '6' check order is CAP_CONFIRM, BATTERY_CONFIRM, BODY_CONFIRM, DOOR_CONFIRM, REASON_SPECIFIC. REVEAL reveals the earliest hidden item after the currently visible item is complete. CONFIRM requires explicit user action. Rework confirmations follow the same order. REASON_SPECIFIC requires a specific reason and completion of previous items.
POST `.../support` {action:'MESSAGE'|'TRANSFER',message?:string}. MESSAGE local deterministic template based on role and intent; stores role message and real facts; no new domain version unless transfer (chat itself does not bump domain version; storage revision separate). TRANSFER follows DEVICE → BILLING → REVIEW → BILLING → REVIEW for plans '2' through '6'. A transfer allocates one task. After four, allowedActions offers OPEN_MERGED_REVIEW. Support is optional.
POST `.../help` {reasonCode:'SHOOT_COMPLETE'|'PLAN_CANCELLED',adopt:true}. Must physically complete; drafts set adopted facts; remaining tasks marked WAIVED_BY_USER, adopted checks recorded with HELP_ACCEPTED. No need reenter. all challenges satisfied; still preview and explicit close required.
GET `.../filing-documents` is scoped to the rental owner and requires completed proof and checks for plans '3' through '6'. It returns `filingDocuments:{receiptCode,certificateCode?,withdrawalCode?,registryCode?,acknowledgmentCode?}`. Each optional document is available after issuance. Documents are read-only and looking them up does not allocate tasks.

POST `.../filing` takes `{receiptCode,certificateCode?}` and the standard command fields. The first submission with the correct receipt code records `APPLICATION_RETURNED` and needs the completeness certificate. The valid second submission approves filing for plan '3'. For plans '4' through '6', it records `APPLICATION_REOPEN_REQUIRED` and sets `RECALL_REQUIRED`. Two stable tasks are allocated once, `FILING_RECEIPT` when filing begins and `FILING_CERTIFICATE` when the application is first returned. Help adoption waives any outstanding filing tasks and allows review. Receipt and certificate copies serve as paperwork, while the physical return time and billing continue to derive from the same evidence.

POST `.../filing-review` takes `{action,code}` and the standard command fields. For plans '4' through '6', `RECALL` uses the original certificate and issues a withdrawal code. `REISSUE` uses it and issues the registry code. `REGISTER` uses that code and issues the acknowledgment code. `ACKNOWLEDGE` uses the fourth code and approves filing. The active status alone controls the permitted action. Each step allocates a stable task on entry, `FILING_RECALL`, `FILING_REISSUE`, `FILING_REGISTER`, and `FILING_ACK`. Invalid codes, stale versions, and repeated requests cannot add work or skip states.

POST `.../finalization` accepts a command for the active plan '5' or '6' stage. `FINISH_SYNC` unlocks `REVIEW_REASON` with a text reason, followed by `FINISH_REVIEW`, `CERTIFY` with the known facts in count/locker order, `FINISH_FINAL`, and `RELEASE`. Each stage allocates one stable FINAL_* task. Three animations are browser-only displays of apparent completion. Their 100% values do not update the business rental status. The reason reviewer returns a verdict, feedback and source, with at most two attempts before manual processing. The submitted reason is excluded from receipts and event payloads. Help waives remaining steps.

For plan '6', server deadlines are 45 seconds for reason, 18 seconds for transcription, and 20 seconds for the new human check. A late submission or an expired `EXPIRE` command atomically returns to that stage's preceding progress. A restarted timed stage receives a fresh deadline. Progress rollback cannot create extra task IDs or undo earlier accepted facts.

GET `.../human-challenge` returns `humanChallenge:{id,image}` for the owner of a currently active challenge. `VERIFY_HUMAN` requires the issued challenge ID and typed digits. `REFRESH_HUMAN` replaces the image but retains deadline and attempts. The third wrong answer returns to final progress. The answer is never included in the public rental or event log. The completed check opens release, while help can waive the pending steps. Clipboard and drop input restrictions are applied at the form.

POST `.../close-preview` {}. Validate self proof, all session checks, the current reason, filing eligibility and finalization eligibility, produce immutable snapshot; sets READY_TO_CLOSE/stage FINAL_REVIEW. Repeated idempotent command returns same. Preview doesn't count task or check.
POST `.../close` {operationId,snapshotId,snapshotHash,confirmClose:true}. expectedStateVersion required. operation replay BEFORE version validation. Business digest excludes requestId/expectedStateVersion. Same key changed fields409. New key already CLOSED returns same receipt and persists mapping. CAS single atomic update includes close receipt/log/operation. No CLOSING stored.
GET `.../operations/:operationId` => operation status receipt if succeeded, NOT_FOUND otherwise; absence never proves no in-flight commit.
POST `.../presented` {taskIds:string[]} (telemetry adjunct). Allocation unchanged, domain version unchanged; unique presentation metrics.
GET `/api/receipts/:receiptId` owner; ?format=json attachment; plain response {ok:true,receipt}.
GET `/api/verify/:code` => minimal {ok:true,verification:{valid:true,receiptId,rentalId,assetId,closedAt,finalMinor,currency:'DEMO'}}. No session/owner proof leakage. Unknown404.

Receipt:
```
{id,rentalId,verificationCode,assetId,slotId,startedAt,returnedAt,closedAt,currency:'DEMO',baseMinor,waitMinor,reversalMinor,finalMinor,reasonCode,snapshotHash,stats:{extraTasks,handOffs,reworkCount,helpUsed,elapsedAfterReturnSeconds},simulation:true}
```

## Frontend requirements
- `app/page.tsx` exports the React page and `app/globals.css` contains its styles. The dashboard uses a steel sidebar, a white canvas, a lime accent and a CSS/SVG equipment illustration. The layout supports a 390-pixel mobile viewport.
- The app shows the active stage and billing meter from the server alongside drawers for support, observer mode, help and receipt history. Polls preserve inputs the user is editing. The observer view is read-only.
- Local storage retains the demo session, rental ID, observer key, creation request ID and unresolved close intent. Rental history comes from the rental list endpoint. Poll every two seconds when the page is visible and the online state allows it. After five seconds without a successful refresh, freeze displayed amounts at the last server values. Stale responses cannot move a closed rental backward. For HTTP 409, refresh the current state. When the close response is lost, query the operation and retry a pending operation with the same identifier and payload. Reloading the page resumes recovery.
- The final review requires the user to check a confirmation box and select **Close rental and generate receipt**. After closure the app offers a JSON receipt download and browser printing.

## Tests
Node built-in node:test, SQLite via node:sqlite D1-compatible adapter (root creates portable/sqlite.mjs). Tests call service Request/Response + temp on-disk SQLite and fake now; test atomic close, stale versions, lost response, cross owner, finite challenges, help, fixture billing. No external test dependency.
