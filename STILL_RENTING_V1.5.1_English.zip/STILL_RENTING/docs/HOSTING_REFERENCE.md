# Original hosted deployment

STILL RENTING originally ran as a private hosted prototype. The November 21, 2026 deployment reported success. A cloud browser subsequently reached the account sign-in screen. The end-to-end interaction verification reported for that release used the development preview and portable build.

- [Original hosted project](https://still-renting-return-lab.chenghangliu9.chatgpt.site/)
- Project ID `appgprj_6b0132b6e9508191a2ab0228b188ed93`
- Source baseline `f612ce6f46dd7068bad130af390d934183ba9e77`

The handoff's `.openai/hosting.json` defines D1 binding `DB` and leaves R2 unset. The original project ID is kept here as a historical reference. Local work uses Node/SQLite or a separate local D1 environment. Hosted changes require checking the active source, project ownership, access and migration state through the supported hosting workflow.
