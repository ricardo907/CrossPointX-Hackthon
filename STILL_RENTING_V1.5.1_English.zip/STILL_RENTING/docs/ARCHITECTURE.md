# STILL RENTING architecture

## Runtime layers

The hosted and portable builds share the same React workflow and JavaScript business service.

| Layer | Hosted | Portable |
| --- | --- | --- |
| Browser | React via Vinext | Built React assets |
| HTTP | Cloudflare Worker | Node.js 24+ loopback server |
| Business logic | `server/service.mjs` and domain modules | Same modules |
| Persistence | Cloudflare D1 | Node's built-in SQLite on disk |
| Identity | Verified platform owner and demo session | Local loopback owner and demo session |
| Default support | Deterministic local role replies | Same replies |
| Default reason review | Local rules with an optional configured model | Same reviewer |

Only the frontend build requires the project toolchain. The portable server runs with Node.js alone. The browser's `localStorage` contains the demo identity, selected rental and observer token, and any unresolved close intent. The server remains authoritative for charges, evidence, limits, and receipts.

## Durable states

| State | Meaning | Next eligible actions |
| --- | --- | --- |
| `ACTIVE` | The demo rental exists and the locker return is incomplete | Put the three components in the locker and close its door |
| `RETURN_PENDING` | The physical return is complete and base charges are frozen | Complete the plan or adopt the existing facts through help |
| `READY_TO_CLOSE` | The server built a stable final-review snapshot | Explicitly close, or update proof and review again |
| `CLOSED` | Closure and the unique immutable receipt are committed | Retrieve, download, or verify the receipt |

`CLOSING` is only a client waiting or recovery view. Support, help, and the observer are auxiliary views. A browser waiting for a response may already have a committed closure on the server.

## Return evidence and staged friction

Allowed device commands are `PLACE_BODY`, `PLACE_CAP`, `PLACE_BATTERY`, and `LOCK_DOOR`. The server derives the return status and time from these commands. It freezes `returnedAt` when all three items are present and the locker door closes. Physical evidence and the base amount remain fixed through later rework.

Plan 6 treats every additional requirement as a stable task identity.

| Task source | Maximum allocations |
| --- | ---: |
| Re-enter known device facts | 5 |
| Reveal and complete checks | 5 |
| Reconfirm hardware facts once | 4 |
| Transfer to the next support desk | 4 |
| File and supplement the closure application | 2 |
| Reprocess the approved application | 4 |
| Complete the finalization sequence | 7 |
| Total | 31 |

The main route omits the support transfers and allocates 27 tasks. Attempting the same timed form again or replaying a command consumes no new task identity. A separately recorded presentation marks when the UI actually showed an allocated task.

The finalization sequence interleaves three simulated progress bars with typed reason review, reversed locker transcription, image CAPTCHA, and release. The browser estimates remaining time with a monotonic clock after synchronizing with the server. The server owns all deadlines and rejects or rolls back expired work even when the browser clock differs. The reason and transcription windows are 45 and 18 seconds. The CAPTCHA window is 20 seconds. Reloading or changing the image keeps the same deadline. Expiry discards the draft and returns to the preceding progress bar. Plan 6 also returns after three wrong CAPTCHA attempts.

Help requires remaining work, complete physical evidence, and a specific reason selected by the user. It records eligible work as `WAIVED_BY_USER` with `HELP_ACCEPTED` as the adoption method. Closing after help still requires a final review and explicit confirmation.

Existing rentals continue with their original plan versions. The historical task caps for plans 1 through 5 are 10, 18, 20, 24, and 30.

## Atomic persistence

Each rental is one aggregate. The JSON holds the business state, proof and histories, allocated tasks, remembered command responses, operation results, events, and the receipt. Lookup keys and versions sit beside the record. A compare-and-swap statement atomically commits both the JSON and receipt indexes:

```sql
UPDATE rentals
SET revision = revision + 1,
    record_json = ?, receipt_id = ?, verification_code = ?, updated_at = ?
WHERE id = ? AND revision = ?;
```

On contention, the service rereads the record and checks ownership, replay and business conditions again. Uniqueness constraints cover the owner's rental-creation key, receipt ID and verification code. Competing close operations on the same rental always point to one receipt.

- `revision` is a storage concurrency token, so presentation and chat events may advance it.
- `stateVersion` is the token for changes requiring a current business view.
- `proofVersion` changes when proof content changes. Individual confirmation validity depends on the evidence confirmed and explicit invalidation.

This aggregate suits a short local demo. Cross-rental atomic actions or unbounded histories would require a different storage design.

### Capacity and reserved completion

| Resource | Limit |
| --- | ---: |
| New support-message turns | 24 |
| Normal rental aggregate | 1,000,000 UTF-8 bytes |
| Maximum aggregate with completion reserve | 1,800,000 UTF-8 bytes |
| Ordinary response history | 12 recent chat entries, 20 events, 8 confirmations |

Within the capacity limit, the observer can read the full history. The reserved space admits actions that strictly advance completion, such as finishing required physical return, first help adoption, the first final snapshot, or closure. Duplicate help, duplicate snapshots and a fresh close ID on an already closed rental do not consume the reserve. Successfully recorded idempotent responses replay before capacity admission. A rejected change leaves no partial mutation.

## Settlement and uncertain responses

The stable final-review snapshot contains the rental and equipment identities, recorded return timestamp, reason, effective evidence, and fixed base amount. Live waiting estimates stay outside the snapshot hash.

Before sending the close command, the browser saves its `operationId` and original business payload. The service makes these checks:

1. Validate ownership and the request shape.
2. Replay a matching recorded operation, even with an older `expectedStateVersion`.
3. Reject the same operation ID with different content.
4. For a valid operation on an already closed rental, return the existing receipt.
5. Otherwise validate the current version, eligibility, and final snapshot. Commit closure, the receipt, and the operation together.

If the response is lost, query the original operation. `NOT_FOUND` means there is no stored result at that instant, so keep recovery available and retry the same intent. Ordinary state-changing commands use `requestId` for the equivalent replay protection.

## Demonstration charges

Use integer minor units with the server clock. One hundred minor units equal 1.00 DEMO. The suggested demo begins ten minutes before the current server time.

```text
seconds(a, b) = floor(max(0, b - a) / 1000)
base = baseRate * seconds(startedAt, returnedAt)
waiting = waitRate * seconds(returnedAt, serverNow)
estimate = base + waiting
waitingReversal = -waitingAtClose
final = base + waitingAtClose + waitingReversal = base
```

The default base and wait estimate rates are one minor unit per second. On loss of a connection beyond the freshness window, the browser shows the last confirmed amount and disconnect state. A settled receipt stays fixed at all later times.

## Authorization and data boundaries

Rental, action, and receipt reads are scoped to the authenticated owner and demo session. Observer diagnostics add a separate capability token and are read-only. The public verification response contains a limited receipt summary. Confirmed physical facts, model output, and CAPTCHA answers have separate scopes.

CAPTCHA images represent a randomized challenge bound to the rental. The service checks challenge identity and answer against live state. The answer stays out of the browser contract and event log. The optional reason reviewer receives only the demonstration statement and selected reason category. It returns a reason verdict and source. The original text stays out of events and receipts, and provider failure invokes the local reviewer. Support has no authority to alter evidence, billing, or closure.

The portable server starts on loopback. Hosted access follows the platform's deployment configuration. The project simulates a rental and its charges. It provides JSON receipts and browser printing. The receipt hash supports consistent content verification.
