# Handoff validation

## English release procedure

From a clean extracted project, verify the manifest, run the Node tests, check TypeScript and rebuild the portable frontend.

```sh
node scripts/verify-handoff.mjs
npm test
npm run typecheck
npm run portable:build
```

For a portable HTTP check, use a second new extraction with no `data/` directory.

```sh
node tests/runtime-smoke.mjs <absolute-path-to-fresh-extracted-project>
```

The probe uses a temporary port and cleans up its process afterward. It checks standalone Node startup, asset and MIME handling, unknown-asset responses, physical return, settlement, JSON download, public verification fields, session isolation, and recovery after server restart. The current probe also exercises the application workflow and finalization stages.

Use an actual browser to check the English flow, reason reviewer messages, timers, paste blocking, challenge renewal and rollback. Look at desktop and 390px views. Record observed results in the [optimization log](OPTIMIZATION_LOG.md).

## Historical reference

The original handoff validation took place on November 21, 2026, under Linux with Node.js v24.22.3. It recorded 39 passing business and capacity tests, a successful TypeScript check, a portable build, and nine successful HTTP and restart checks. The export included 145 tracked source files, excluding the older nested delivery archive. The export also verified original requirement files byte for byte and checked ZIP integrity, file lengths, and SHA-256 hashes.

That original handoff used temporary links to installed development dependencies. It verified direct Node startup after extraction. Previously recorded desktop and mobile-width interaction results are in the [historical validation report](VALIDATION_REPORT.md). The source baseline was commit `f612ce6f46dd7068bad130af390d934183ba9e77`; the export standardized the Node 24 metadata, added handoff notes, and detached the local project from its previous hosted site.
