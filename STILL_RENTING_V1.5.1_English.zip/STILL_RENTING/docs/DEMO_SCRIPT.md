# STILL RENTING demo script

Use a new demo rental when showing the entire flow. Confirm the DEMO marker, the `CAM-042` camera, the `B-07` locker, and the local server connection. Preserve any existing unresolved closure and recover its result before starting a separate session.

## Twenty-second clip

Start with the final simulated progress bar at 100%. Click the button to view the receipt generation result, revealing a six-digit CAPTCHA and a 20-second timer. Attempt to paste arbitrary digits and show that the field stays empty. Type a partial answer and let the timer expire. Show the message that the input was discarded and the return to the preceding progress bar.

When editing this sequence to 20 seconds, cut the middle of the countdown and disclose the edit on screen. Capture the actual stage change and rollback.

## Full walkthrough

### Introduce the return

> I just want to return a camera. The system already knows the kit is back, but it still wants proof that we agree.

Display the starting ten-minute rental and DEMO charges. Place the camera body, lens cap, and battery in the locker. Close the door. Point out the fixed return time and the estimated waiting charge.

### Prove known facts

Re-enter the device ID, locker, return status and item count. Copy the cabinet UTC timestamp into this early proof form. The later timed forms have stricter clipboard rules.

Reveal the four equipment checks one at a time, then choose the specific return reason. Show the four confirmations that expire after the first reason change. Confirm each again in the required order. The physical return time stays fixed.

### See optional support

Ask why the rental is still waiting. Transfer through Billing, Review, Billing and Review. Point out that each role can consult the same physical facts and still pass the issue on. The final handover provides a consolidated review. Return to the main flow when you are ready.

### Apply, refile, and reprocess

Open the return archive and obtain the equipment receipt number. Apply to close the rental and show the missing-completeness-certificate notice. Open the archive again, obtain the newly issued number and resubmit.

Show the simultaneous “Materials approved” and “Returned for reprocessing” messages. Retrieve the archived details, withdraw the already approved application, reissue the credential, submit the filing, and acknowledge it. Each desk issues the number the next desk asks for.

### Reach the progress bars

1. At the first 100%, type a specific reason and explain the equipment return within 45 seconds. Point to the actual review source and feedback.
2. At the next 100%, enter `3/B-07` within 18 seconds. The order reverses the information shown by the return form. If you want to show an expiry, wait for the preceding bar to reappear and then complete the step.
3. At the last 100%, type the six digits within 20 seconds. The browser rejects paste, and changing the image keeps the deadline. Acknowledge that the procedural round finished while the rental remains open.

### Settle and verify

Open the final review, read the frozen base amount and complete waiting charge reversal, and explicitly end the rental. Verify the receipt and download JSON. Open the observer to show actual allocation and presentation events, then refresh and recover the same receipt.

## Short follow-up demonstrations

- **Help.** Start separately, complete the cabinet return, choose a specific reason and adopt the known evidence. Review and close explicitly. Opening help before returning equipment shows the unmet physical prerequisite.
- **Competing tabs.** Open the same rental in two tabs. Change a proof reason in one tab and try to submit stale proof in the other. The older tab should receive a version conflict.
- **Interrupted close.** Demonstrate an unresolved close only with enough time to restore the connection and query its original operation. Show the same receipt after recovery.
- **Portable startup.** Run the extracted archive directly with Node.js 24+. Use the standalone package for a venue without network access.

Keep the demonstration language precise. The equipment and money are simulated. Support replies are local templates. An online reason reviewer uses the optional configured provider, and the default uses local rules. Receipt printing uses the browser, and verification checks the server's stored record.
