# STILL RENTING product requirements

STILL RENTING demonstrates how bureaucratic user-interface mistakes can make a simple rental return feel endless. Users should be able to recognize each procedural obstacle, choose to continue or get help, and ultimately prove that the simulated rental was closed.

## Scenario and entry points

- The demo begins with an Aperture S1 camera kit, serial `CAM-042`, assigned to locker `B-07`. The rental starts ten minutes before the server opens the scenario.
- The user returns the camera body, lens cap, and battery through the locker simulation and closes the door. The equipment return time becomes immutable once the door closes with the complete kit inside.
- A user can create a separate demo while retaining earlier rentals. History restores the corresponding stage or receipt. The same demo session cannot read another session's records.
- The service marks charges as simulated in the workflow and receipt.

## Current return plan

| Phase | Required behavior |
| --- | --- |
| Physical return | The server records the placement of all three items and door closure, then freezes the base amount. |
| Proof form | Ask the user to re-enter device ID, locker number, return status, exact cabinet UTC timestamp and item count. Validate against the facts on record. A repeated field error can reveal the correct value. |
| Sequential review | Reveal the lens cap, battery, body, and door checks one at a time. Require each answer before revealing the next. The fifth check asks for a specific reason. |
| Reason and one rework | Replace the general reason with “Shoot completed” or “Plans canceled.” The first specific reason expires the four earlier confirmations and causes one ordered repeat. The physical return and charges stay fixed. |
| Optional support | Provide deterministic Equipment, Billing, and Review role replies. Permit up to four transfers in the fixed sequence. Support can lead to consolidated review or back to the active task. |
| Closure application | Require the equipment receipt number from return records. Return the first valid application for a missing completeness certificate. The certificate issued at that moment becomes the next required number. |
| Reprocessing | After the application passes, archive it and require withdrawal, credential reissue, filing and acknowledgment in order. Each desk issues the credential needed by the next desk. |
| First progress and reason | A completed progress bar unlocks 45 seconds to type a specific return reason and describe the equipment return. Give a sufficiency verdict. After two insufficient submissions, use the fallback path. |
| Second progress and transcription | At 100%, open an 18-second form. Require the exact certified notation `3/B-07`, with the item count before the locker. |
| Third progress and human verification | At 100%, open a 20-second six-digit visual challenge. Refreshing the image keeps the timer. Three wrong answers reopen the preceding progress step. |
| Review release | Require the user's acknowledgment that the procedural round is done and the rental is still open. Unlock the final review. |
| Settlement | Show the fixed amount and waiting charge reversal. Require explicit confirmation. Commit the closure and immutable receipt together. |

The server starts each timed form, owns its deadline, and rolls back a late submission. After expiry, the preceding progress screen is visible again and text in the expired form is cleared. The timed fields accept manual typing and input methods and reject clipboard copy, cut, paste, and drag-and-drop. The timers, provider attempts, and completion stages persist across reloads.

## Task allocation and accessibility

Plan 6 limits ordinary work to 27 additional task identities or 31 with all four support transfers. Reattempting a timed step does not allocate a new identity. Supported plans 1–5 retain their original requirements and caps of 10, 18, 20, 24 and 30.

Provide a help option wherever the user can continue. After the cabinet accepts the return, let the user select a specific reason and adopt the existing evidence. Record the waived tasks and advance to final review. Keep keyboard focus visible and the main flow usable in a 390px-wide viewport. Use the same actual server clock and state across normal and help paths.

## Optional online reason review

The default review accepts specific reasons together with a description of returning equipment. The optional online source uses a configured `OPENAI_API_KEY` and model. Validate the response and apply the local reason rule on a timeout, refusal, or invalid answer. Show the real source of the verdict and keep the raw statement out of event logs and receipts. Support relies on local templates.

## Receipt and recovery

1. Explain the base amount, waiting estimate, reversal, and final charge in DEMO units. The final charge equals the frozen base charge.
2. Give every closed rental one receipt ID and verification code. Provide JSON download and browser print.
3. Keep close operations idempotent across loss of a response, concurrency, or restart. Persist the client's close intent until its result is available.
4. Let an authorized observer view physical evidence, plan versions, allocation and presentation history, and closure state without creating business state changes.

## Acceptance criteria

Run the local package with Node.js 24 or later and no optional provider. Verify a complete rental and a separate early help route. Confirm all three simulated progress gates, rollback from each timed window, rejected paste, valid and invalid CAPTCHA actions, and no duplicate tasks. Verify that a refresh and server restart preserve rental and receipt data. Check desktop, narrow view, keyboard focus, observer permissions, and file downloads. See [acceptance checks](../ACCEPTANCE.md) for the engineering test commands.
