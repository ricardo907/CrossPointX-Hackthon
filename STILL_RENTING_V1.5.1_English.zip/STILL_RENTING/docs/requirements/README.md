# Product requirements

[Product requirements](PRODUCT_REQUIREMENTS.md) is the consolidated English specification for the current STILL RENTING demo. It covers the deliberate friction, plan compatibility, recorded state, and criteria for a working return.

The historical Word, PDF, and text requirements belong to the baseline archive. The English handoff uses this maintained specification, the [implementation contract](../IMPLEMENTATION_CONTRACT.md), and [acceptance checks](../ACCEPTANCE.md).
