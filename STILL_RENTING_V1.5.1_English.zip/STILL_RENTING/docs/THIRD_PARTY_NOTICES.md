# Third-party notices

The local HTTP service uses modules built into Node.js. The built frontend includes React, React DOM and Lucide icons. Exact dependency versions appear in `package-lock.json`. Applicable license texts are under `docs/licenses/` and `vendor/`.

| Component | Purpose | License |
| --- | --- | --- |
| React and React DOM | Browser rendering | MIT |
| Lucide | Interface icons | ISC |
| Vite | Build tool | MIT |
| Vinext | Hosted React framework | MIT |
| Node.js | Separately installed local runtime | Node.js and component-specific licenses |
