# Original prototype validation report

The November 21, 2026 validation covered the runnable V1.0 prototype. The current English release has a newer plan. See [acceptance checks](ACCEPTANCE.md) and [release history](OPTIMIZATION_LOG.md) for its scope.

## Automated results

The original Node test suite passed 39 tests with zero failures. It included 34 primary cases and five help-stage subtests using SQLite and a controlled clock. Coverage included a complete return, the original friction mechanisms, prerequisite evidence, charge calculation, operation replay, parallel closures, lost responses, a failure before commit, owner isolation, and recovery after reopening the database.

The capacity test used repeated valid API writes. At the ordinary limit, help, a final snapshot, and closure still worked. Repeated help and fresh close IDs could not consume the protected completion reserve.

## Browser observations

| Scenario | Original observation |
| --- | --- |
| Desktop | Completed cabinet, proof, staged checks, reason rework, settlement and receipt. |
| Proof correction | Two device ID errors exposed the known correct value while preserving other fields. |
| Rework | Selecting the completed-shoot reason expired two original manual confirmations. Physical return time and base amount stayed fixed. |
| Support | Completed Equipment → Billing → Review, then saw the consolidated-review exit at 2/2. |
| Billing | Final review showed the base fee and waiting reversal. On the receipt, wait and reversal canceled each other. |
| Verification and refresh | Verified the receipt against the server and restored the same ID, code and amount after refresh. A later new demo preserved earlier history. |
| Observer | Inspected evidence, versions and allocation, presentation, confirmation and closure events. |
| Mobile-width view | Tested at 390 × 844 CSS pixels with no horizontal overflow on the checked paths. |
| Help | A pre-return attempt showed the unmet physical prerequisite. After return, a specific reason and explicit adoption led to separate final confirmation. |
| Keyboard | Focus stayed within the help dialog when tabbing from its close button. |
| Disconnect | Stopping the development service showed the last server time. The displayed amount remained 6.13 DEMO until reconnecting and restoring the existing rental. |

## Build and scope

TypeScript, Vinext/Worker build, local D1 migration, and the portable frontend build passed in the original environment. The ZIP ran directly under Node without project dependencies. Nine HTTP checks covered static files, full closure, JSON download, verification, owner isolation and restart recovery.

The verification recorded here was for simulated devices and charges. It included a responsive browser viewport and controlled request failures. Device-lab coverage, production load, external workflow behavior, and every browser-level failure timing require additional environments and verification.
