# Acceptance checks

The Node tests exercise the shared HTTP service using SQLite and a controlled server clock. Each main test creates a separate session and isolated records. The clock override is a test seam and is unavailable over the public API.

```sh
npm test
npm run typecheck
npm run portable:build
node tests/runtime-smoke.mjs <absolute-path-to-fresh-extracted-copy>
```

Use Node.js 24 or later. The portable smoke test starts its own server and requires a copy with no existing `data/` directory. A deliberate database-failure test can emit a service error before assertions verify that no closure was committed.

## Core API cases

| Cases | Assertions |
| --- | --- |
| 01–03 | A creation retry returns the same rental. The locker requires all equipment and the door action. The server sets the return timestamp and fixes the base amount. |
| 04–07 | Proof errors retain other inputs, count attempts and normalize known values. Checks reveal one by one. The main path completes without support. Changing the reason triggers one bounded round of reconfirmation. |
| 08–09 | Support has a bounded transfer route. Help requires a valid reason, complete physical evidence, and explicit adoption. Waived work still leads to a separate close confirmation. |
| 10–11 | The fixture amount is 600 + 120 − 120 = 600. Waiting estimates can grow without changing the final snapshot or business version. |
| 12–14 | Close replay succeeds with an old version when the intent matches. Changed content under the same key conflicts. Multiple concurrent operations produce one receipt. |
| 15–18 | A stale proof write leaves newer proof intact. A lost response is queryable and replayable. `NOT_FOUND` leaves the outcome unresolved. A failed write cannot leave a partial closure or orphaned receipt. |
| 19–23 | Task identities stay deduplicated. Help can finish from multiple stages. Closed rentals remain closed. Download and verification agree. A new demo leaves old receipts available. |
| 24–29 | Observer reads require a separate capability. Requests from other owners or sessions are rejected. Replays consume neither checks nor transfers. Presentations deduplicate without advancing business state. A reopened SQLite database keeps progress and operation results. |
| 30–34 | Proof updates invalidate stale final-review snapshots. Saving identical proof preserves its version. Invalid requests preserve evidence. Support stops after 24 message turns. Aggregate capacity leaves room for completion and replay. |

The current suite also covers application return and reprocessing, multiple simulated progress stages, timed reason review and transcription, image CAPTCHA verification, provider fallback, and compatibility with earlier plan versions. Use the test runner's full reported count, which includes stage subtests.

### Capacity

Exercise the normal write limit through real API calls with fresh request IDs. Verify that help, the first eligible final snapshot and closure can still advance using the reserved space. Repeated help, duplicate snapshots and close operations on an already closed rental must leave the completion reserve available. The exact byte total varies with the recorded payloads. The historical V1.0 stress test reached 994,561 bytes before filling ordinary capacity and 1,023,181 bytes after settlement, below the 1,800,000-byte hard limit.

## Browser acceptance

| Scenario | Visible result |
| --- | --- |
| Full desktop route | Equipment return, proof, staged review, filing, reprocessing, finalization, settlement, and receipt all work. |
| Support | Equipment, Billing and Review appear in sequence and the final permitted transfer offers consolidated review. |
| Help | Help can adopt the existing return evidence after a specific reason is selected. Final settlement still requires confirmation. |
| Timed forms | The progress bars open the 45-second reason, 18-second transcription, and 20-second CAPTCHA windows. Copy, cut, paste and drop are blocked on the timed fields. |
| Human verification | Correct six-digit input advances the case. Changing the image keeps the time and attempt limits. Expiry or three wrong answers returns to the preceding bar. |
| Narrow viewport | At 390 CSS pixels, key labels and actions fit without horizontal overflow. |
| Keyboard | Inputs and buttons have visible focus. Locker actions are keyboard-operable. |
| Refresh and disconnect | Restore the selected rental or the same receipt. Connection loss shows the last known estimate and a clear connection state. |
| Uncertain close | Query or retry the original pending operation. Preserve the intent while the result is unknown. |
| Final review | Show the fixed base amount, waiting charge reversal and an explicit close action. |
| Receipt | Show the DEMO marker, amount breakdown, timestamps, verification code and download. |
| New demo | A separate rental starts with its own progress. Earlier receipts remain retrievable. |
| Observer | Read-only diagnostics show evidence, task counts, versions and real events. |

Concurrency and failure-injection tests establish request semantics. Browser events and layouts require browser checks. A 390px viewport check documents responsive behavior at that width. Optional live model and hosted account behavior require their own environment. See [historical validation](VALIDATION_REPORT.md) and [release checks](HANDOFF_VALIDATION.md).
