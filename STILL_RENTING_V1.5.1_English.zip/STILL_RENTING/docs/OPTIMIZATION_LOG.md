# Release and verification history

## Original runnable baseline

The November 21, 2026 baseline at commit `f612ce6f46dd7068bad130af390d934183ba9e77` supported a complete main route, evidence adoption through help, simulated billing, and a stable receipt. The original environment recorded 39 business and capacity checks and nine HTTP checks, plus desktop and 390px browser observations, refresh recovery, and disconnect freeze.

The first development handoff exported the source, included built portable assets, standardized Node 24 metadata, and detached the project from its hosted binding. The runtime and UI business rules stayed at the original baseline for that export. [Historical validation](VALIDATION_REPORT.md) and [handoff checks](HANDOFF_VALIDATION.md) record the scope.

## V1.1 Expanded return procedure

Added UTC return time and item count to the repeated proof, plus body and door checks and reconfirmations. The optional support route expanded to four handovers. The main route allocated 14 tasks and the full route up to 18. Historical checks recorded 41 passing Node tests, TypeScript review, a portable build, desktop receipt recovery, and the narrow-width help path.

## V1.2 Rejected closure applications

Added the archive receipt and completeness certificate after the ordered review. The first valid application issues the missing certificate and asks the user to resubmit. Plan 3 allocates up to 20 tasks or 16 without support. Historical checks recorded 45 passing business tests and 13 local HTTP checks, including process recovery after rejection, final closure and receipt verification.

## V1.3 Approved and returned for reprocessing

After a complete application passes review, the service archives it and asks the user to withdraw it, reissue a credential, file again and acknowledge the result. Each desk creates the next credential. Plan 4 allocates up to 24 tasks or 20 without support. Historical checks recorded 51 passing service tests, a portable build, reprocessing and invalid-code coverage, refresh and receipt download, and narrow-width checks.

## V1.4 Progress bars and reason review

Added the three apparent completions before settlement, the typed reason review, reverse transcription and release acknowledgment. The review supports a configured OpenAI provider and an offline rule. It attributes the actual verdict source, applies a fallback after two insufficient attempts, and omits the raw reason from events and receipts. Plan 5 allocates up to 30 tasks or 26 without support. Historical checks recorded 63 Node tests, TypeScript and the portable build. Desktop checks covered all three apparent completions and real receipt creation. A mock verified the online adapter's response handling.

## V1.5 Countdown rollback and CAPTCHA

Plan 6 added 45 seconds for reason entry, 18 seconds for transcription and 20 seconds for the image CAPTCHA. The server stores deadlines, rollbacks and attempt counts. Timed forms block copy, cut, paste and drag-and-drop. The server issues and verifies randomized six-digit CAPTCHA images. Refresh preserves the current deadline. Three wrong answers or expiry return to the preceding progress step. The main route allocates 27 tasks and the full route up to 31. Older rentals retain their original plan rules.

Historical verification recorded 70 passing Node tests, a TypeScript check and portable build. Tests exercised deadline boundaries, server restart, accepted and rejected CAPTCHA answers, image renewal, compatibility and settlement. The English edition localizes the workflow without introducing another plan version.

## Record a new change

Record the release or commit, the scenarios changed, impact on business rules and existing data, actual checks and their results, any known gaps, and a fallback or rollback route. Keep earlier verification scoped to the version and environment that produced it.

## V1.5.1 English edition

The English edition localizes the interface, accessibility labels, browser metadata, API messages, support templates and reason feedback. The handoff includes English operating instructions, acceptance checks and a consolidated specification. The original-language exports and raw reports from historical releases remain in their earlier packages.

All 70 Node tests and the TypeScript check passed for the English edition. An additional check of legacy records confirmed that generated labels and verdict feedback display in English while user-authored content remains as entered.


The English browser demo was captured from the portable interface and edited to exactly 20 seconds. The 390-pixel progress and human-verification screens displayed English without horizontal overflow. Fifteen portable HTTP checks passed after extraction, covering the complete return and receipt flow.

