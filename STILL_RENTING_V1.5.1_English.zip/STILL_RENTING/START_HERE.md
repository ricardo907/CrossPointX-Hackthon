# Start here

This package contains the STILL RENTING English release, its complete source, a prebuilt portable frontend, the product requirements, and acceptance tests.

## Run the package

Extract the entire ZIP. On Windows, double-click `Start_Windows.bat`. On any supported platform, Node.js 24 or later can start the project from its root:

```sh
node portable/server.mjs --open
```

Open [the local demo](http://127.0.0.1:8787/) and start a new demo. Keep the terminal open while using the app. Press Ctrl+C to stop it. The portable build uses SQLite at `data/still-renting.sqlite` and can run offline without a model key.

## Work on the source

Open the extracted `STILL_RENTING` directory containing `AGENTS.md`, `package.json`, and `app/`. Use the existing source and configuration as the baseline.

```sh
npm ci
npm test
npm run typecheck
npm run portable:build
node portable/server.mjs --open
```

Project installation requires network access. The Node business tests and prebuilt runtime are standalone. After changing React or CSS, rebuild the portable frontend and refresh the browser. After changing server files, restart the process. Generated assets under `portable/public/` come from the build.

Read [the project guide](AGENTS.md), [the engineering handoff](CODEX_HANDOFF.md), [the product requirements](docs/requirements/PRODUCT_REQUIREMENTS.md), and [the implementation contract](docs/IMPLEMENTATION_CONTRACT.md). [The architecture](docs/ARCHITECTURE.md) explains atomic persistence, charges, and recovery.

## Verify or rebuild a handoff

Check a freshly extracted ZIP with:

```sh
node scripts/verify-handoff.mjs
```

The command checks the SHA-256 manifest. After editing source, an integrity difference is expected until the package is rebuilt. A manifest check and a test run serve different purposes.

Build and test before packaging. The complete handoff exporter requires Python 3:

```sh
python scripts/package-codex-handoff.py --output ../STILL_RENTING_Handoff.zip
```

The exporter rebuilds the manifest and omits runtime data, dependency caches, and environment credentials. Use a fresh extracted copy with no `data/` directory for the HTTP probe. [The acceptance guide](docs/ACCEPTANCE.md) lists the checks.
