# STILL RENTING project guide

## Project baseline

Continue from the working reverse-UX prototype in this directory. Read `START_HERE.md`, `CODEX_HANDOFF.md`, `docs/IMPLEMENTATION_CONTRACT.md`, and `docs/ARCHITECTURE.md` before changing the business flow. The current user request controls the scope.

The user returns a camera kit. The process adds redundant confirmations, returns applications for reprocessing, and shows stages that appear nearly complete. Keep the friction deliberate, clearly simulated, and possible to finish.

## Preserve these rules

1. Preserve data integrity through the simulated friction. A deliberately expired draft is part of a timed challenge. Accidental data loss, endless loops, and wrong charges are bugs.
2. Physical facts, recorded times, task allocation, billing, and receipts are authoritative on the server.
3. A plan 6 rental has at most 31 additional tasks. The three simulated progress stages lead to timed reason entry, transcription, and an image CAPTCHA. A timeout returns to the preceding progress stage, clears the timed draft, and keeps any task count or review attempt already recorded. Plans 5, 4, 3, 2, and 1 keep limits of 30, 24, 20, 18, and 10 respectively.
4. Help requires physical return evidence and the user's selection of a specific return reason. It records waived work as `HELP_ACCEPTED` or `WAIVED_BY_USER`.
5. The durable states are `ACTIVE`, `RETURN_PENDING`, `READY_TO_CLOSE`, and `CLOSED`. A valid proof edit can return a ready rental to pending. `CLOSING` is a client recovery view. A closed rental remains closed.
6. Recording the physical return fixes `returnedAt` and the base charge. Waiting estimates reverse in full at settlement. Use integer minor units.
7. Keep the same `operationId` and business payload when retrying a close. Validate authorization and request shape before replay. Replay a successful result before checking an old business version.
8. Commit the closure state, one immutable receipt, the operation result, and indexes atomically. Keep `stateVersion` separate from the storage `revision`.
9. Cap support at 24 message turns per rental, normal aggregate updates at 1,000,000 bytes, and the reserved completion path at 1,800,000 bytes. Verify that capacity limits leave users a way to close.
10. Attribute support to its local template and reason review to its actual source. The optional model supplies a review result. The server owns the state transition.

## Build and verification

- Use Node.js 24 or later and retain the lockfile.
- Run the portable version with `node portable/server.mjs --open`.
- Rebuild with `npm run portable:build` after editing the UI. The build owns files below `portable/public/assets/`.
- Run `npm test`, `npm run typecheck`, and the portable build for relevant changes. Before shipping runtime changes, run `node tests/runtime-smoke.mjs <absolute-path-to-fresh-copy>` on a copy with no `data/` directory.
- Add coverage for specific gaps. Keep regression assertions meaningful. Record actual verification in `docs/OPTIMIZATION_LOG.md`.
- Preserve the protections for stale rental responses, pending operations, and invalidated final review snapshots.

## Delivery scope

This package is for local handoff. `.openai/hosting.json` carries configuration without an active hosted project binding. Keep local databases, demo sessions, credentials, and dependency caches out of delivery archives.
