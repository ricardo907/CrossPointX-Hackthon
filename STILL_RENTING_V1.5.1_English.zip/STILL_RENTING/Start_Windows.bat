@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Please install Node.js 24 or newer from https://nodejs.org/
  echo Then double-click this file again.
  pause
  exit /b 1
)
node portable/server.mjs --open
pause
