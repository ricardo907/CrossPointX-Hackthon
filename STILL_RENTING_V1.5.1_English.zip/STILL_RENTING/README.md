# STILL RENTING

The equipment is back. The rental is still open.

STILL RENTING is a reverse-UX experiment for a hackathon. You return a camera kit to a simulated locker. The service records the return immediately, then sends you through a bureaucracy that insists on confirming what it already knows. It ends with an actual state change and a downloadable demo receipt.

## Run the demo

The portable build requires Node.js 24 or later. Its frontend is already built, and the default experience runs offline.

- On Windows, extract the whole ZIP and double-click `Start_Windows.bat`.
- On macOS or Linux, extract the ZIP and run `node portable/server.mjs --open` from the project root. The archive also includes `Start_Mac.command` and `Start_Linux.sh`.

The server opens [the local demo](http://127.0.0.1:8787/). Keep its terminal open while you play. Press Ctrl+C to stop it.

If port 8787 is busy, set a different port before starting:

```powershell
$env:STILL_RENTING_PORT="8788"
node portable/server.mjs --open
```

```sh
STILL_RENTING_PORT=8788 node portable/server.mjs --open
```

The server listens only on the local loopback interface.

## Complete a return

1. Start a new demo. It begins with a rental already ten minutes old.
2. Put the camera body, lens cap, and battery in locker `B-07`, then close the door. The server freezes the return time.
3. Re-enter the device ID `CAM-042`, locker `B-07`, return status `Returned`, the UTC timestamp displayed by the locker, and the item count `3`.
4. Request and confirm the lens cap, battery, camera body, and locker door checks one at a time. The fifth check asks for a specific return reason.
5. Change the general reason to a finished shoot or a canceled plan. Repeat the four expired confirmations in their original order and confirm the saved reason. Each rental gets one round of this rework.
6. Optionally follow support through four transfers: Equipment → Billing → Review → Billing → Review. After the last transfer, the consolidated review becomes available. You can also leave support and resume the main route.
7. Open the return records and bring the equipment receipt number back to the closure application. Its first valid submission is rejected because it lacks a completeness certificate. Find the newly issued certificate in the return records and submit its number.
8. The materials pass review, but the application is sent back for reprocessing. Retrieve the original certificate number from the archive and withdraw the approved application. Fetch each new credential at its issuing desk, reissue the credential, file the closure record, and acknowledge the filing.
9. At the first progress bar's 100% mark, you have 45 seconds to type why you ended the rental and how you returned the kit.
10. At the second bar's 100% mark, you have 18 seconds to type the item count and locker in reverse order, `3/B-07`.
11. At the third bar's 100% mark, you have 20 seconds to type a six-digit image CAPTCHA. Acknowledge that the rental remains open, then exit review.
12. Review the final amount and explicitly end the rental. Check the waiting charge reversal and verification code on the receipt. Download the JSON receipt or use the browser's print dialog to save a PDF.

The main route allocates 27 extra tasks. With all four support transfers, the maximum is 31. Each timer returns you to its preceding progress bar and discards the current draft. Copying, cutting, pasting, and dragging text into the timed fields are blocked. Reloading or refreshing the CAPTCHA keeps the active deadline. Three failed CAPTCHA attempts also return you to the preceding bar.

The help route is available whenever the user can still move the rental forward. It uses existing physical return evidence and a selected reason to waive remaining bureaucracy. Closing the rental still requires a final review and explicit confirmation.

## Optional AI reason review

The offline reviewer checks for a specific reason and an account of how the equipment was returned. For example, enter “The shoot finished and I put the camera kit back in locker B-07.” After two insufficient submissions, the application uses its fallback route.

To enable online review, set `OPENAI_API_KEY` in the server environment. Set `STILL_RENTING_AI_MODEL` to override the configured default, `gpt-4.1-mini`. The provider receives the simulated statement and selected reason category. A timeout, refusal, or invalid response falls back to the local rules. The interface shows the source that actually reviewed the submission. Support conversations use local role templates.

## Data and simulated billing

The local server stores records in `data/still-renting.sqlite`. The browser keeps its demo session, selected rental ID, observer access token, and any unsettled closure operation. A different browser profile has a separate demo identity. Start a new demo to try the workflow again while preserving past rentals.

The base charge freezes at the physical return time. Waiting charges are estimates until settlement. The receipt reverses them in full, so the final amount equals the frozen base charge. The default rates are one minor unit per second, and 100 minor units equal 1.00 DEMO. All equipment, rental records, and charges are simulated.

## Build and verify

```sh
npm ci
npm test
npm run typecheck
npm run portable:build
node portable/server.mjs --open
```

The business tests run on Node.js 24 and create temporary SQLite records. Running the prebuilt package requires neither `npm ci` nor network access. Build dependencies are needed to compile the frontend or run TypeScript checks.

| Location | Purpose |
| --- | --- |
| `app/page.tsx`, `app/globals.css` | React interface, interaction flow, and styles |
| `server/` | Shared state machine, billing, challenge budget, reviewer, and receipts |
| `portable/` | Local HTTP server, SQLite adapter, and built browser assets |
| `worker/`, `db/`, `drizzle/` | Hosted entry point and persistence schema |
| `tests/` | Acceptance tests, bounds tests, and portable HTTP smoke test |

- [Start here](START_HERE.md)
- [Product requirements](docs/requirements/PRODUCT_REQUIREMENTS.md)
- [Demo script](docs/DEMO_SCRIPT.md)
- [API and data contract](docs/IMPLEMENTATION_CONTRACT.md)
- [Architecture](docs/ARCHITECTURE.md)
- [Acceptance and release checks](docs/ACCEPTANCE.md)
