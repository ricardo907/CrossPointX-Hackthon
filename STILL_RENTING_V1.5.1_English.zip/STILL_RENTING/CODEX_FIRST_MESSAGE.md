# First task for the receiving developer

Continue from the working STILL RENTING prototype in this directory. Read `AGENTS.md`, `CODEX_HANDOFF.md`, `docs/NEXT_STEPS.md`, `docs/IMPLEMENTATION_CONTRACT.md`, and `docs/ARCHITECTURE.md`. Use the [consolidated English requirements](docs/requirements/PRODUCT_REQUIREMENTS.md) for the user flow and acceptance criteria.

This is a reverse-UX hackathon project. The server already knows that the camera kit has been returned. The app deliberately makes the user reconfirm it, navigate administrative rework, and encounter successive timed forms. Preserve those mechanics and the integrity of settlement and receipt recovery.

First, verify Node.js 24 or later, run the existing tests, type-check the project, and rebuild the portable frontend. Run `tests/runtime-smoke.mjs` in a fresh extracted copy with no `data/` directory. Record the checks actually performed.

For optional follow-on work, see [next steps](docs/NEXT_STEPS.md). Avoid broad changes to the billing and closure model unless the task requires them.
