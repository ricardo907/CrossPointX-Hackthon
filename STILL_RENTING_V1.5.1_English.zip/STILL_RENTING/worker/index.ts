import handler from "vinext/server/fetch-handler";
import { runWithConnectorBinding } from "../lib/connector-context";
import type { ConnectorBinding } from "../lib/connector-contract.mjs";
import { handleApi } from "../server/service.mjs";
import { configuredReasonReviewMode, createReasonReviewer } from "../server/reason-review.mjs";

type WorkerEnv = Cloudflare.Env & { OPENAI_API_KEY?: string; STILL_RENTING_AI_MODEL?: string };

const worker = {
  fetch(request: Request, env: WorkerEnv, ctx: ExecutionContext<{ CONNECTORS?: ConnectorBinding }>) {
    if (new URL(request.url).pathname.startsWith("/api/")) {
      const owner = request.headers.get("oai-authenticated-user-id") ||
        (import.meta.env.DEV ? "local-preview" : null);
      if (!owner) return Response.json({ ok: false, error: { code: "AUTH_REQUIRED", message: "Sign in to continue.", retryable: false } }, { status: 401 });
      if (!env.DB) return Response.json({ ok: false, error: { code: "SERVICE_UNAVAILABLE", message: "The data service is temporarily unavailable. Try again shortly.", retryable: true } }, { status: 503 });
      return handleApi(request, {
        db: env.DB,
        owner,
        reasonReview: createReasonReviewer(env),
        reasonReviewMode: configuredReasonReviewMode(env),
      });
    }
    let binding = ctx.props?.CONNECTORS;
    // Local preview emulates the same request-scoped capability. This branch and
    // the auxiliary service binding are absent from production builds.
    if (import.meta.env.DEV && !binding && env.CONNECTORS) {
      const preview = env.CONNECTORS;
      const expiresAt = Date.now() + 60_000;
      binding = {
        async getContext() {
          if (Date.now() >= expiresAt) return { status: "request_context_expired" };
          return preview.getContext?.() ?? { status: "binding_unavailable" };
        },
        async invoke(connectorId, actionName, args) {
          if (Date.now() >= expiresAt) {
            return { status: "request_context_expired", message: "This request has expired. Please try again." };
          }
          return preview.invoke(connectorId, actionName, args);
        },
      };
    }
    return runWithConnectorBinding(binding, () => handler.fetch(request, env, ctx));
  },
};

export default worker;
